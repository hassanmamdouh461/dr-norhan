import { useState } from 'react';
import { useAuth } from './context/AuthContext';
import LoginRegister from './pages/LoginRegister';
import Home from './pages/Home';
import CourseDetails from './pages/CourseDetails';
import LessonPlayer from './pages/LessonPlayer';
import { ExplainTasks } from './components/ExplainTasks';
import Loader from './components/Loader';

function App() {
  const { user, loading } = useAuth();
  
  // Navigation / View State
  const [view, setView] = useState<'dashboard' | 'course-details' | 'lesson-player'>('dashboard');
  const [selectedCourseId, setSelectedCourseId] = useState<string | null>(null);
  const [selectedLesson, setSelectedLesson] = useState<{ id: string; title: string; type: 'video' | 'pdf' } | null>(null);
  const [guestMode, setGuestMode] = useState(true);

  if (loading) {
    return <Loader text="جاري تأمين جلستك الدراسية" size="large" fullscreen={true} />;
  }

  // Not logged in and not in guest mode -> Show Login/Register Page
  if (!user && !guestMode) {
    return <LoginRegister onBrowseAsGuest={() => setGuestMode(true)} />;
  }

  // Logged in or Guest mode -> Route to appropriate page/view
  return (
    <div style={{ minHeight: '100vh', backgroundColor: 'rgb(var(--background))', color: 'rgb(var(--on-background))' }}>
      
      {view === 'dashboard' && (
        <Home
          onSelectCourse={(courseId) => {
            setSelectedCourseId(courseId);
            setView('course-details');
          }}
          onSelectLesson={(lessonId, title, type, _isFree, courseId) => {
            if (courseId) {
              setSelectedCourseId(courseId);
            }
            setSelectedLesson({ id: lessonId, title, type });
            setView('lesson-player');
          }}
          onShowAuth={() => setGuestMode(false)}
        />
      )}

      {view === 'course-details' && selectedCourseId && (
        <div className="layout-container" style={{ padding: '40px 16px' }}>
          <CourseDetails
            courseId={selectedCourseId}
            isLoggedIn={!!user}
            onBack={() => {
              setSelectedCourseId(null);
              setView('dashboard');
            }}
            onSelectLesson={(lessonId, title, type, isFree) => {
              if (!user && !isFree) {
                alert('هذا المحتوى يتطلب تسجيل الدخول والاشتراك.');
                setGuestMode(false);
                return;
              }
              setSelectedLesson({ id: lessonId, title, type });
              setView('lesson-player');
            }}
          />
        </div>
      )}

      {view === 'lesson-player' && selectedLesson && (
        <div className="layout-container" style={{ padding: '40px 16px' }}>
          <LessonPlayer
            lessonId={selectedLesson.id}
            lessonTitle={selectedLesson.title}
            onBack={() => {
              setSelectedLesson(null);
              if (selectedCourseId) {
                setView('course-details');
              } else {
                setView('dashboard');
              }
            }}
            onSelectLesson={(lessonId, title, type) => {
              setSelectedLesson({ id: lessonId, title, type });
            }}
          />
        </div>
      )}
      
      <ExplainTasks />
    </div>
  );
}

export default App;
