import React, { useEffect, useRef, useState, useCallback } from 'react';
import Hls from 'hls.js';
import { ApiService } from '../services/api';
import { useAuth } from '../context/AuthContext';
import Watermark from '../components/Watermark';
import SecurityGuard from '../components/SecurityGuard';
import Loader from '../components/Loader';

interface LessonPlayerProps {
  lessonId: string;
  lessonTitle: string;
  onBack: () => void;
  onSelectLesson?: (lessonId: string, title: string, type: 'video' | 'pdf') => void;
}

export const LessonPlayer: React.FC<LessonPlayerProps> = ({
  lessonId,
  lessonTitle,
  onBack,
  onSelectLesson,
}) => {
  const { user, profile } = useAuth();
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const hlsRef = useRef<Hls | null>(null);

  const [loading, setLoading] = useState(true);
  const [playbackData, setPlaybackData] = useState<any | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  
  // Custom video player states
  const [isPlaying, setIsPlaying] = useState(false);
  const [isTheaterMode, setIsTheaterMode] = useState(false);
  const [activeSidebarTab, setActiveSidebarTab] = useState<'playlist' | 'attachments' | 'qa' | 'quiz'>('playlist');
  const [courseLessons, setCourseLessons] = useState<any[]>([]);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [showControls, setShowControls] = useState(true);
  const [isSeeking, setIsSeeking] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [showQualityMenu, setShowQualityMenu] = useState(false);
  const [showResumePrompt, setShowResumePrompt] = useState(false);
  const [startPositionToResume] = useState(0);

  const [qualities, setQualities] = useState<any[]>([]);
  const [currentQuality, setCurrentQuality] = useState<number>(-1);

  // Rotation state
  const [rotation, setRotation] = useState(0);
  const rotateVideo = () => {
    setRotation(prev => {
      const nr = (prev + 90) % 360;
      logDebug('info', `Video rotated to ${nr} degrees`);
      return nr;
    });
  };

  // Debug Console logs states
  const [debugLogs, setDebugLogs] = useState<Array<{ time: string; level: 'info' | 'warn' | 'error'; message: string }>>([]);
  const [showDebugConsole, setShowDebugConsole] = useState(false);

  // Watermark text
  const [watermarkText, setWatermarkText] = useState('طالب مسجل');

  // Heartbeat tracking
  const heartbeatTimer = useRef<any | null>(null);
  const lastPositionSeconds = useRef<number>(0);
  const controlsTimeoutRef = useRef<any | null>(null);
  const mediaRecoveryAttempts = useRef<number>(0);

  // Lesson questions
  const [questions, setQuestions] = useState<any[]>([]);
  const [newQuestionBody, setNewQuestionBody] = useState('');
  const [submittingQuestion, setSubmittingQuestion] = useState(false);
  const [qaError, setQaError] = useState('');
  const [qaSuccess, setQaSuccess] = useState('');
  const [logsCopied, setLogsCopied] = useState(false);

  // PDF files
  const [attachments, setAttachments] = useState<any[]>([]);
  const [selectedPdfUrl, setSelectedPdfUrl] = useState<string | null>(null);
  const [pdfBlobUrl, setPdfBlobUrl] = useState<string | null>(null);
  const [pdfLoading, setPdfLoading] = useState(false);

  const [inlinePdfBlobUrl, setInlinePdfBlobUrl] = useState<string | null>(null);
  const [inlinePdfLoading, setInlinePdfLoading] = useState(false);
  const [inlinePdfTitle, setInlinePdfTitle] = useState('');

  const logDebug = useCallback((level: 'info' | 'warn' | 'error', message: string) => {
    const time = new Date().toLocaleTimeString();
    setDebugLogs(prev => [...prev.slice(-49), { time, level, message }]);
    console[level](`[Player Debug] ${message}`);
  }, []);

  const loadCourseLessons = async (courseId: string) => {
    try {
      const courseDetails = await ApiService.getCourseDetails(courseId);
      const lessonsList: any[] = [];
      if (courseDetails.units) {
        for (const unit of courseDetails.units) {
          if (unit.lessons) {
            for (const lesson of unit.lessons) {
              lessonsList.push({
                ...lesson,
                unitTitle: unit.title
              });
            }
          }
        }
      }
      setCourseLessons(lessonsList);
    } catch (err) {
      console.error('Failed to load course lessons for playlist:', err);
    }
  };

  // Student Quiz States
  const [quizLoading, setQuizLoading] = useState(false);
  const [quizData, setQuizData] = useState<any | null>(null);
  const [quizQuestionsList, setQuizQuestionsList] = useState<any[]>([]);
  const [quizAttempt, setQuizAttempt] = useState<any | null>(null);
  const [showSubmitConfirm, setShowSubmitConfirm] = useState(false);
  const [studentAnswers, setStudentAnswers] = useState<Record<string, string>>({});
  const [submittingQuiz, setSubmittingQuiz] = useState(false);
  const [quizError, setQuizError] = useState('');
  const [quizTimeLeft, setQuizTimeLeft] = useState<number | null>(null);

  const fetchLessonQuiz = async (lId: string) => {
    try {
      setQuizLoading(true);
      setQuizError('');
      setStudentAnswers({});
      const res = await ApiService.getLessonQuiz(lId);
      setQuizData(res.quiz);
      setQuizQuestionsList(res.questions || []);
      setQuizAttempt(res.attempt);
    } catch (e: any) {
      console.error(e);
      setQuizError(e.message || 'فشل تحميل الواجب الخاص بالمحاضرة');
    } finally {
      setQuizLoading(false);
    }
  };

  useEffect(() => {
    if (!quizData || !quizData.time_limit_mins || !quizAttempt || quizAttempt.is_submitted === 1) {
      setQuizTimeLeft(null);
      return;
    }

    const startTime = new Date(quizAttempt.started_at).getTime();
    const limitMs = quizData.time_limit_mins * 60 * 1000;
    
    const updateTimer = () => {
      const elapsed = Date.now() - startTime;
      const remaining = Math.max(0, Math.floor((limitMs - elapsed) / 1000));
      setQuizTimeLeft(remaining);

      if (remaining <= 0) {
        clearInterval(timerId);
        handleSubmitQuiz(true);
      }
    };

    updateTimer();
    const timerId = setInterval(updateTimer, 1000);

    return () => clearInterval(timerId);
  }, [quizData, quizAttempt, studentAnswers]);

  const formatTimeLeft = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const handleSubmitQuiz = async (isTimeout = false) => {
    if (!quizData) return;
    
    if (!isTimeout && Object.keys(studentAnswers).length === 0) {
      setQuizError('يرجى الإجابة على الأسئلة أولاً قبل التسليم');
      return;
    }

    try {
      setSubmittingQuiz(true);
      setQuizError('');
      const res = await ApiService.submitQuizAnswers(lessonId, studentAnswers);
      if (isTimeout) {
        alert(`انتهى الوقت المحدد للواجب! تم تسليم إجاباتك تلقائياً. درجتك: ${res.score} / ${res.max_score}`);
      }
      setShowSubmitConfirm(false);
      await fetchLessonQuiz(lessonId);
    } catch (e: any) {
      console.error(e);
      setQuizError(e.message || 'فشل تسليم الواجب');
    } finally {
      setSubmittingQuiz(false);
    }
  };

  const loadLessonDetails = async () => {
    logDebug('info', 'Loading lesson details (questions/attachments)...');
    
    let courseId: string | null = null;
    
    // 1. Load attachments
    try {
      const details = await ApiService.getLessonDetails(lessonId);
      const atts = details.lesson?.attachments || [];
      setAttachments(atts);
      
      if (details.lesson?.course_id) {
        courseId = details.lesson.course_id;
      }

      const firstPdf = atts.find((att: any) => att.type === 'pdf' || att.url?.toLowerCase().includes('.pdf'));
      if (firstPdf) {
        handleOpenInlinePdf(firstPdf.url, firstPdf.title);
      } else {
        setInlinePdfBlobUrl(null);
      }
    } catch (err) {
      console.error('Failed to load lesson attachments:', err);
      logDebug('warn', 'Failed to load lesson attachments');
    }
    
    // 2. Load questions
    if (user) {
      try {
        const questionsRes = await ApiService.getQuestions({ lessonId });
        setQuestions(questionsRes.questions || []);
      } catch (err) {
        console.error('Failed to load lesson Q&A questions:', err);
        logDebug('warn', 'Failed to load lesson Q&A questions');
      }
    } else {
      setQuestions([]);
    }
    
    // 3. Load Quiz
    if (user) {
      try {
        await fetchLessonQuiz(lessonId);
      } catch (err) {
        console.error('Failed to load lesson quiz:', err);
        logDebug('warn', 'Failed to load lesson quiz');
      }
    }
    
    // 4. Load playlist lessons
    if (courseId) {
      try {
        await loadCourseLessons(courseId);
      } catch (err) {
        console.error('Failed to load course lessons:', err);
      }
    }
  };

  const initializePlayer = async () => {
    setLoading(true);
    setErrorMessage(null);
    setShowResumePrompt(false);
    logDebug('info', `Initializing player for lesson ID: ${lessonId}`);
    try {
      // 1. Fetch HLS url & watermark configurations
      logDebug('info', 'Fetching playback URL and watermark configurations from backend API...');
      const data = await ApiService.getPlaybackUrl(lessonId);
      setPlaybackData(data);
      logDebug('info', `API response: provider=${data.provider}, has_playback_url=${!!data.playback_url}, last_position=${data.last_position}`);

      if (data.watermark_text) {
        setWatermarkText(data.watermark_text);
      } else {
        setWatermarkText(`${profile?.full_name || ''}\n${profile?.phone || ''}`);
      }

      // Initialize API logs & progress loading details
      await loadLessonDetails();
      setLoading(false);

      // Check localStorage first, fallback to backend last_position
      const localProgress = localStorage.getItem(`video_progress_${lessonId}`);
      const startAt = localProgress ? parseInt(localProgress) : (data.last_position || 0);

      // Log lecture open
      lastPositionSeconds.current = startAt;
      if (user) {
        await ApiService.sendPlaybackLog(lessonId, 'open', startAt).catch(() => {});
        logDebug('info', `Recorded open log in database at position: ${startAt}s`);
      }

      // Setup player (auto-resume directly for HLS/Direct videos)
      setTimeout(() => {
        setupHlsPlayer(data.playback_url || data.hls_url, startAt, data.provider, false);
      }, 100);

    } catch (err: any) {
      console.error('Playback setup failed:', err);
      logDebug('error', `Playback setup failed: ${err.message || err}`);
      setErrorMessage(err.message || 'تعذر تشغيل الفيديو. يرجى تفعيل الكورس أو المحاولة لاحقاً.');
      setLoading(false);
    }
  };

  const handleQualityChange = (levelIndex: number) => {
    setCurrentQuality(levelIndex);
    logDebug('info', `Quality changed manually to level index: ${levelIndex} (Seamless transition queued)`);
    if (hlsRef.current) {
      hlsRef.current.nextLevel = levelIndex;
    }
  };

  const setupHlsPlayer = (playbackUrl: string, startAt: number, provider: string, startPaused = false) => {
    if (provider === 'youtube') {
      logDebug('info', 'YouTube provider detected. Bypassing Hls.js initialization (handled via iframe)');
      return;
    }
    if (!videoRef.current || !playbackUrl) {
      logDebug('error', `Cannot setup player: videoRefReady=${!!videoRef.current}, playbackUrlLength=${playbackUrl?.length || 0}`);
      return;
    }

    const video = videoRef.current;
    logDebug('info', `Configuring player. Hls.js supported=${Hls.isSupported()}, startAt=${startAt}s, startPaused=${startPaused}`);

    // Clean up previous Hls instance
    if (hlsRef.current) {
      logDebug('info', 'Destroying previous Hls.js instance...');
      hlsRef.current.destroy();
      hlsRef.current = null;
    }

    // Reset player rate and volume
    video.playbackRate = playbackRate;
    video.volume = volume;
    video.muted = isMuted;

    // Error event listener for native video tag
    const onNativeError = () => {
      if (video.error) {
        logDebug('error', `Native HTML5 Video Error: code=${video.error.code}, message=${video.error.message}`);
      }
    };
    video.addEventListener('error', onNativeError);

    if (provider === 'r2' || provider === 'server' || !playbackUrl.includes('.m3u8')) {
      logDebug('info', `Direct media source playback: url=${playbackUrl}`);
      video.src = playbackUrl;
      const onLoadedMetadata = () => {
        logDebug('info', `Direct media metadata loaded. Duration: ${video.duration}s`);
        if (startAt > 0) {
          video.currentTime = startAt;
        }
        if (!startPaused) {
          video.play().catch((e) => logDebug('warn', `Direct autoplay failed: ${e.message}`));
        }
      };
      video.addEventListener('loadedmetadata', onLoadedMetadata);
      return;
    }

    if (Hls.isSupported()) {
      logDebug('info', `Loading stream source via Hls.js: url=${playbackUrl}`);
      const hls = new Hls({
        maxMaxBufferLength: 30,
        enableWorker: true,
      });
      hlsRef.current = hls;
      hls.loadSource(playbackUrl);
      hls.attachMedia(video);

      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        logDebug('info', `HLS manifest parsed. Available levels/qualities: ${hls.levels?.length || 0}`);
        setQualities(hls.levels || []);
        setCurrentQuality(hls.currentLevel);
        if (startAt > 0) {
          video.currentTime = startAt;
        }
        if (!startPaused) {
          video.play().catch((e) => logDebug('warn', `Hls.js autoplay failed: ${e.message}`));
        }
      });

      hls.on(Hls.Events.ERROR, (_event, data) => {
        if (data.fatal) {
          logDebug('error', `Fatal Hls.js error encountered: type=${data.type}, details=${data.details}`);
          
          if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
            mediaRecoveryAttempts.current++;
            if (mediaRecoveryAttempts.current <= 3) {
              logDebug('warn', `Fatal media error. Attempting recovery (Attempt ${mediaRecoveryAttempts.current}/3)...`);
              hls.recoverMediaError();
            } else {
              logDebug('error', 'Media recovery failed 3 times. Halted to prevent infinite loop.');
              setErrorMessage('فشل تشغيل بث الفيديو. يرجى تجربة إعادة تشغيل الصفحة أو الاتصال بالدعم.');
            }
            return;
          }

          switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              logDebug('warn', 'Fatal Hls network error. Retrying stream chunk load...');
              hls.startLoad();
              break;
            default:
              setErrorMessage('فشل فك تشفير بث الفيديو المحمي.');
              logDebug('error', 'Unrecoverable Hls.js fatal error. Stream halted.');
              break;
          }
        } else {
          // Log non-fatal errors as warnings instead of triggering recovery
          logDebug('warn', `Non-fatal Hls.js error: type=${data.type}, details=${data.details}`);
        }
      });
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      logDebug('info', 'Hls.js not supported. Falling back to Safari native HLS playback...');
      video.src = playbackUrl;
      video.addEventListener('loadedmetadata', () => {
        logDebug('info', `Safari native HLS metadata loaded. Duration: ${video.duration}s`);
        if (startAt > 0) {
          video.currentTime = startAt;
        }
        if (!startPaused) {
          video.play().catch((e) => logDebug('warn', `Safari autoplay failed: ${e.message}`));
        }
      });
    }
  };

  // Sync player states
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const onPlay = () => {
      setIsPlaying(true);
      mediaRecoveryAttempts.current = 0; // Reset recovery attempts on successful play
      logDebug('info', `Video status: Playing at rate ${video.playbackRate}x, time=${formatTime(video.currentTime)}`);
    };
    const onPause = () => {
      setIsPlaying(false);
      logDebug('info', `Video status: Paused, time=${formatTime(video.currentTime)}`);
    };
    const onEnded = () => {
      setIsPlaying(false);
      logDebug('info', 'Video status: Finished playback (ended)');
    };
    const onTimeUpdate = () => {
      if (!isSeeking) {
        setCurrentTime(video.currentTime);
      }
    };
    const onDurationChange = () => {
      setDuration(video.duration || 0);
    };

    video.addEventListener('play', onPlay);
    video.addEventListener('pause', onPause);
    video.addEventListener('ended', onEnded);
    video.addEventListener('timeupdate', onTimeUpdate);
    video.addEventListener('durationchange', onDurationChange);

    return () => {
      video.removeEventListener('play', onPlay);
      video.removeEventListener('pause', onPause);
      video.removeEventListener('ended', onEnded);
      video.removeEventListener('timeupdate', onTimeUpdate);
      video.removeEventListener('durationchange', onDurationChange);
    };
  }, [isSeeking, logDebug, loading, playbackData]);

  // Fullscreen change listener
  useEffect(() => {
    const handleFullscreenChange = () => {
      const isFull = !!document.fullscreenElement;
      setIsFullscreen(isFull);
      logDebug('info', `Fullscreen status: ${isFull ? 'Entered' : 'Exited'}`);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, [logDebug]);

  // Keyboard Shortcuts handler
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Avoid hotkeys when typing in Q&A inputs
      if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') {
        return;
      }

      const video = videoRef.current;
      if (!video) return;

      switch (e.key.toLowerCase()) {
        case ' ': // spacebar (play/pause)
          e.preventDefault();
          togglePlay();
          break;
        case 'arrowright': // seek forward 10s
          e.preventDefault();
          video.currentTime = Math.min(video.currentTime + 10, video.duration || 0);
          logDebug('info', `Shortcut: Seek +10s to ${formatTime(video.currentTime)}`);
          break;
        case 'arrowleft': // seek backward 10s
          e.preventDefault();
          video.currentTime = Math.max(video.currentTime - 10, 0);
          logDebug('info', `Shortcut: Seek -10s to ${formatTime(video.currentTime)}`);
          break;
        case 'arrowup': // volume up
          e.preventDefault();
          setVolume((prev) => {
            const nv = Math.min(prev + 0.05, 1);
            video.volume = nv;
            setIsMuted(nv === 0);
            return nv;
          });
          break;
        case 'arrowdown': // volume down
          e.preventDefault();
          setVolume((prev) => {
            const nv = Math.max(prev - 0.05, 0);
            video.volume = nv;
            setIsMuted(nv === 0);
            return nv;
          });
          break;
        case 'f': // toggle fullscreen
          e.preventDefault();
          toggleFullscreen();
          break;
        default:
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, isMuted, volume, logDebug]);

  // Heartbeat tracking loop
  useEffect(() => {
    if (loading || errorMessage || !playbackData || !user) return;

    const startHeartbeat = () => {
      heartbeatTimer.current = setInterval(async () => {
        let currentPos = 0;
        let playing = false;

        if (playbackData.provider === 'youtube') {
          currentPos = lastPositionSeconds.current + 15;
          playing = true; 
        } else if (videoRef.current) {
          currentPos = Math.floor(videoRef.current.currentTime);
          playing = !videoRef.current.paused && !videoRef.current.ended;
        }

        const delta = currentPos - lastPositionSeconds.current;

        if (delta > 0 && playing) {
          try {
            await ApiService.sendHeartbeat({
              lesson_id: lessonId,
              position: currentPos,
              watched_seconds: delta,
            });
            lastPositionSeconds.current = currentPos;
          } catch (err: any) {
            console.error('Heartbeat error:', err);
            logDebug('error', `Heartbeat delivery failed: ${err.message || err}`);
            if (err.status === 403 || err.code === 'ACCOUNT_BLOCKED' || err.code === 'DEVICE_NOT_TRUSTED') {
              if (videoRef.current) videoRef.current.pause();
              setIsPlaying(false);
              setErrorMessage('تم إلغاء تفعيل جلستك أو حظر حسابك لمخالفة قواعد الأمان.');
              clearInterval(heartbeatTimer.current);
            }
          }
        } else {
          lastPositionSeconds.current = currentPos;
        }
      }, 15000);
    };

    startHeartbeat();

    return () => {
      if (heartbeatTimer.current) {
        clearInterval(heartbeatTimer.current);
      }
    };
  }, [loading, errorMessage, playbackData, lessonId, logDebug, user]);

  // Open/Close Logs on mount & unmount
  useEffect(() => {
    initializePlayer();

    return () => {
      // Clean HLS instance
      if (hlsRef.current) {
        hlsRef.current.destroy();
      }
      // Revoke any created PDF Blob URLs to free memory
      if (pdfBlobUrl) {
        URL.revokeObjectURL(pdfBlobUrl);
      }
      if (inlinePdfBlobUrl) {
        URL.revokeObjectURL(inlinePdfBlobUrl);
      }

      // Send lecture close logs
      let currentPos = lastPositionSeconds.current;
      if (videoRef.current) {
        currentPos = Math.floor(videoRef.current.currentTime);
      }
      if (user) {
        ApiService.sendPlaybackLog(lessonId, 'close', currentPos).catch(() => {});
      }
    };
  }, [lessonId, user]);

  // Controls auto-hide timer
  const handleMouseMove = () => {
    setShowControls(true);
    if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
    if (isPlaying) {
      controlsTimeoutRef.current = setTimeout(() => {
        setShowControls(false);
      }, 2500);
    }
  };

  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;
    if (isPlaying) {
      video.pause();
    } else {
      video.play().catch((e) => logDebug('error', `Play failed: ${e.message}`));
    }
  };

  const toggleMute = () => {
    const video = videoRef.current;
    if (!video) return;
    const nm = !isMuted;
    setIsMuted(nm);
    video.muted = nm;
    logDebug('info', `Mute toggled to: ${nm}`);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const video = videoRef.current;
    if (!video) return;
    const nv = Number(e.target.value);
    setVolume(nv);
    video.volume = nv;
    setIsMuted(nv === 0);
  };

  const handleSeekChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const video = videoRef.current;
    if (!video || duration === 0) return;
    const pct = Number(e.target.value);
    video.currentTime = (pct / 100) * duration;
    setCurrentTime(video.currentTime);
    logDebug('info', `Scrubbed/Seeked to: ${formatTime(video.currentTime)}`);
  };

  const handleSpeedChange = (rate: number) => {
    setPlaybackRate(rate);
    logDebug('info', `Speed rate changed to: ${rate}x`);
    if (videoRef.current) {
      videoRef.current.playbackRate = rate;
    }
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch((err) => {
        console.error('Error entering fullscreen:', err);
        logDebug('error', `Fullscreen request rejected: ${err.message}`);
      });
    } else {
      document.exitFullscreen();
    }
  };

  const confirmResume = () => {
    setShowResumePrompt(false);
    logDebug('info', `Resume WATCH confirmed. Seeking to: ${startPositionToResume}s`);
    if (videoRef.current) {
      videoRef.current.currentTime = startPositionToResume;
      videoRef.current.play().catch((e) => logDebug('error', `Resume play failed: ${e.message}`));
    }
  };

  const cancelResume = () => {
    setShowResumePrompt(false);
    logDebug('info', 'Resume WATCH cancelled. Starting from 0s');
    if (videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current.play().catch((e) => logDebug('error', `Restart play failed: ${e.message}`));
    }
  };

  const formatTime = (seconds: number): string => {
    if (isNaN(seconds) || seconds < 0) return '00:00';
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    const mm = String(m).padStart(2, '0');
    const ss = String(s).padStart(2, '0');
    if (h > 0) {
      return `${h}:${mm}:${ss}`;
    }
    return `${mm}:${ss}`;
  };

  const handlePostQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newQuestionBody.trim() || newQuestionBody.trim().length < 5) {
      setQaError('يجب أن يحتوي السؤال على 5 أحرف على الأقل.');
      return;
    }

    // 30s hidden/inline rate limit check
    const lastSent = parseInt(localStorage.getItem('alhadaba_last_question_time') || '0');
    const now = Date.now();
    if (now - lastSent < 30000) {
      const remaining = Math.ceil((30000 - (now - lastSent)) / 1000);
      setQaError(`يرجى الانتظار ${remaining} ثانية قبل طرح سؤال آخر لتجنب الإرسال المتكرر.`);
      return;
    }

    setSubmittingQuestion(true);
    setQaError('');
    setQaSuccess('');
    try {
      await ApiService.askQuestion({
        body: newQuestionBody.trim(),
        lesson_id: lessonId,
      });
      setNewQuestionBody('');
      localStorage.setItem('alhadaba_last_question_time', Date.now().toString());

      const questionsRes = await ApiService.getQuestions({ lessonId });
      setQuestions(questionsRes.questions || []);
      setQaSuccess('تم إرسال سؤالك للمدرس بنجاح!');
      setTimeout(() => setQaSuccess(''), 5000);
    } catch (err: any) {
      setQaError(err.message || 'تعذر إرسال السؤال');
    } finally {
      setSubmittingQuestion(false);
    }
  };

  const handleOpenPdf = async (url: string) => {
    setPdfLoading(true);
    setSelectedPdfUrl(url);
    if (pdfBlobUrl) {
      URL.revokeObjectURL(pdfBlobUrl);
      setPdfBlobUrl(null);
    }
    try {
      const blob = await ApiService.getFileBlob(url);
      const blobUrl = URL.createObjectURL(blob);
      setPdfBlobUrl(blobUrl);
    } catch (err: any) {
      console.error(err);
    } finally {
      setPdfLoading(false);
    }
  };

  const handleOpenInlinePdf = async (url: string, title: string) => {
    setInlinePdfLoading(true);
    setInlinePdfTitle(title);
    if (inlinePdfBlobUrl) {
      URL.revokeObjectURL(inlinePdfBlobUrl);
      setInlinePdfBlobUrl(null);
    }
    try {
      const blob = await ApiService.getFileBlob(url);
      const blobUrl = URL.createObjectURL(blob);
      setInlinePdfBlobUrl(blobUrl);
    } catch (err: any) {
      console.error(err);
    } finally {
      setInlinePdfLoading(false);
    }
  };

  const handleFocusLost = (blurred: boolean) => {
    const isYoutube = 
      playbackData?.provider === 'youtube' &&
      typeof playbackData?.youtube_id === 'string' &&
      playbackData.youtube_id.trim().length > 0 &&
      typeof playbackData?.playback_url === 'string' &&
      (playbackData.playback_url.includes('youtube.com') || playbackData.playback_url.includes('youtu.be'));

    if (isYoutube) return;

    if (blurred && videoRef.current && !videoRef.current.paused) {
      videoRef.current.pause();
      setIsPlaying(false);
      logDebug('warn', 'SecurityGuard triggered: Lost focus, paused playback.');
    }
  };

  const copyDebugLogs = () => {
    const text = debugLogs.map(l => `[${l.time}] [${l.level.toUpperCase()}] ${l.message}`).join('\n');
    navigator.clipboard.writeText(text);
    setLogsCopied(true);
    setTimeout(() => setLogsCopied(false), 2000);
  };

  const renderInlinePdfViewer = () => {
    if (!inlinePdfBlobUrl) return null;
    return (
      <div 
        style={{ 
          padding: 0, 
          overflow: 'hidden', 
          display: 'flex', 
          flexDirection: 'column', 
          backgroundColor: 'rgb(var(--surface-container-low))', 
          borderRadius: '12px',
          border: '1px solid rgb(var(--outline) / 0.15)',
          height: '620px',
          width: '100%',
          marginTop: '12px'
        }}
      >
        {/* Header bar */}
        <div className="flex justify-between items-center" style={{ padding: '12px 18px', borderBottom: '1px solid rgb(var(--outline) / 0.1)', backgroundColor: 'rgb(var(--surface-dim))' }}>
          <h3 style={{ margin: 0, fontSize: '12px', fontWeight: 'bold', color: 'rgb(var(--on-surface))', display: 'flex', alignItems: 'center', gap: '6px' }}>
            <span className="icon" style={{ fontSize: '16px', color: 'rgb(var(--primary))' }}>picture_as_pdf</span>
            <span>{inlinePdfTitle || 'عارض المذكرات الآمن'}</span>
          </h3>
          <button
            className="btn btn-secondary"
            style={{ padding: '4px 8px', minWidth: 0, fontSize: '10px', borderRadius: '6px', cursor: 'pointer' }}
            onClick={() => {
              setInlinePdfBlobUrl(null);
              if (inlinePdfBlobUrl) {
                URL.revokeObjectURL(inlinePdfBlobUrl);
              }
            }}
          >
            إغلاق الكتاب
          </button>
        </div>

        {/* Document display */}
        <div style={{ flex: 1, position: 'relative', backgroundColor: 'rgb(var(--surface-dim))' }}>
          {inlinePdfLoading ? (
            <Loader text="جاري تأمين وعرض المذكرة" size="small" />
          ) : inlinePdfBlobUrl ? (
            <iframe
              src={`${inlinePdfBlobUrl}#toolbar=1&navpanes=0&scrollbar=1`}
              style={{ width: '100%', height: '100%', border: 'none' }}
            />
          ) : (
            <div className="flex items-center justify-center h-full" style={{ fontSize: '12px', color: '#888' }}>فشل تحميل الملف</div>
          )}

          {/* Diagonal Watermarks overlay across the document */}
          {!inlinePdfLoading && inlinePdfBlobUrl && (
            <div
              style={{
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%',
                height: '100%',
                pointerEvents: 'none',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-around',
                alignItems: 'center',
                opacity: 0.05,
                zIndex: 10,
                overflow: 'hidden',
              }}
            >
              {Array.from({ length: 4 }).map((_, i) => (
                <div
                  key={i}
                  style={{
                    transform: 'rotate(-25deg)',
                    fontSize: '15px',
                    fontWeight: 'bold',
                    color: '#fff',
                    fontFamily: 'Cairo, sans-serif',
                    whiteSpace: 'nowrap',
                  }}
                >
                  {profile?.full_name} - {profile?.phone}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  };

  const isYoutubeVideo = 
    playbackData?.provider === 'youtube' &&
    typeof playbackData?.youtube_id === 'string' &&
    playbackData.youtube_id.trim().length > 0 &&
    typeof playbackData?.playback_url === 'string' &&
    (playbackData.playback_url.includes('youtube.com') || playbackData.playback_url.includes('youtu.be'));

  return (
    <SecurityGuard enabled={!loading && !errorMessage && !isYoutubeVideo} onFocusLost={handleFocusLost}>
      <div style={{ direction: 'rtl' }} className="flex flex-col gap-lg">
        
        {/* Navigation back */}
        <div className="flex justify-between items-center" style={{ flexWrap: 'wrap', gap: '12px', marginBottom: '16px' }}>
          <button className="btn btn-secondary" onClick={onBack}>
            <span className="icon">arrow_back</span>
            العودة للمقرر الدراسي
          </button>
        </div>

        {/* Outer Layout Grid */}
        <div className={`player-layout-grid ${isTheaterMode ? 'theater-mode' : ''}`}>
          
          {/* Main Area: Video Player and Metadata */}
          <div className="player-layout-main" style={{ flex: '2.2' }}>
            
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '24px',
              width: '100%',
              alignItems: 'stretch'
            }}>
              
              {/* Left Column: Video player & details */}
              <div style={{ flex: 1.3, minWidth: 0, display: 'flex', flexDirection: 'column', gap: '24px' }}>
            
            {/* Video Player Card */}
            <div className="card" style={{ padding: 0, overflow: 'hidden', backgroundColor: '#000', border: 'none', boxShadow: 'var(--shadow-lg)' }}>
              
              <div 
                ref={containerRef}
                onMouseMove={handleMouseMove}
                onMouseLeave={() => isPlaying && setShowControls(false)}
                className="custom-video-container"
                style={{ 
                  position: 'relative', 
                  width: '100%', 
                  aspectRatio: '16/9',
                  backgroundColor: '#000',
                  overflow: 'hidden'
                }}
              >
                
                {loading ? (
                  <Loader text="جاري تحميل وتأمين البث" size="medium" />
                ) : errorMessage ? (
                  <div className="flex flex-col items-center justify-center h-full p-md text-center" style={{ color: '#fff' }}>
                    <span className="icon" style={{ fontSize: '48px', color: '#f87171', marginBottom: '16px' }}>warning</span>
                    <p className="body-medium" style={{ maxWidth: '400px', lineHeight: '1.6' }}>{errorMessage}</p>
                    <button className="btn btn-primary" onClick={initializePlayer} style={{ marginTop: '16px' }}>إعادة المحاولة</button>
                  </div>
                ) : playbackData?.provider === 'youtube' ? (
                  <iframe
                    src={`https://www.youtube.com/embed/${playbackData.youtube_id}?autoplay=1&rel=0&modestbranding=1&controls=1`}
                    title={lessonTitle}
                    style={{ width: '100%', height: '100%', border: 'none' }}
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                ) : (
                  <>
                    <video
                      ref={videoRef}
                      crossOrigin="anonymous"
                      controlsList="nodownload noremoteplayback"
                      disablePictureInPicture
                      onClick={togglePlay}
                      onDoubleClick={toggleFullscreen}
                      style={{ 
                        width: '100%', 
                        height: '100%', 
                        objectFit: 'contain', 
                        cursor: 'pointer',
                        transform: `rotate(${rotation}deg) ${(rotation === 90 || rotation === 270) ? 'scale(0.5625)' : ''}`,
                        transition: 'transform 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
                      }}
                    />

                    {/* ── Custom HTML5 Video Player Controls ── */}
                    <div 
                      className={`custom-player-controls ${showControls ? 'visible' : 'hidden'}`}
                      style={{
                        position: 'absolute',
                        bottom: 0,
                        left: 0,
                        right: 0,
                        background: 'linear-gradient(to top, rgba(10,12,18,0.95) 0%, rgba(10,12,18,0.5) 60%, rgba(10,12,18,0) 100%)',
                        display: 'flex',
                        flexDirection: 'column',
                        padding: '16px 20px',
                        transition: 'opacity 0.3s ease, transform 0.3s ease',
                        zIndex: 100,
                        opacity: showControls ? 1 : 0,
                        pointerEvents: showControls ? 'auto' : 'none',
                        direction: 'ltr',
                        gap: '12px'
                      }}
                    >
                      {/* Seek Bar Slider */}
                      <div style={{ display: 'flex', alignItems: 'center', width: '100%', position: 'relative' }}>
                        <input
                          type="range"
                          min={0}
                          max={100}
                          value={duration > 0 ? (currentTime / duration) * 100 : 0}
                          onChange={handleSeekChange}
                          onMouseDown={() => setIsSeeking(true)}
                          onMouseUp={() => setIsSeeking(false)}
                          className="player-seek-slider"
                          style={{
                            width: '100%',
                            cursor: 'pointer',
                            height: '5px',
                            background: `linear-gradient(to right, rgb(var(--primary)) 0%, rgb(var(--primary)) ${duration > 0 ? (currentTime / duration) * 100 : 0}%, rgba(255,255,255,0.2) ${duration > 0 ? (currentTime / duration) * 100 : 0}%, rgba(255,255,255,0.2) 100%)`,
                            appearance: 'none',
                            outline: 'none',
                            borderRadius: '3px',
                          }}
                        />
                      </div>

                      {/* Controls Row */}
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%' }}>
                        {/* Left Side: Playback State + Sound + Time */}
                        <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
                          <button 
                            onClick={togglePlay}
                            style={{ background: 'none', color: '#fff', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', padding: 0 }}
                          >
                            <span className="icon" style={{ fontSize: '28px' }}>
                              {isPlaying ? 'pause' : 'play_arrow'}
                            </span>
                          </button>

                          {/* Volume Slider & Button */}
                          <div className="player-volume-container" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                            <button 
                              onClick={toggleMute}
                              style={{ background: 'none', color: '#fff', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', padding: 0 }}
                            >
                              <span className="icon" style={{ fontSize: '22px' }}>
                                {isMuted ? 'volume_off' : volume > 0.5 ? 'volume_up' : 'volume_down'}
                              </span>
                            </button>
                            <input
                              type="range"
                              min={0}
                              max={1}
                              step={0.05}
                              value={isMuted ? 0 : volume}
                              onChange={handleVolumeChange}
                              className="player-volume-slider"
                              style={{
                                width: '70px',
                                cursor: 'pointer',
                                height: '4px',
                                appearance: 'none',
                                background: `linear-gradient(to right, #fff 0%, #fff ${(isMuted ? 0 : volume) * 100}%, rgba(255,255,255,0.2) ${(isMuted ? 0 : volume) * 100}%, rgba(255,255,255,0.2) 100%)`,
                                outline: 'none',
                                borderRadius: '2px'
                              }}
                            />
                          </div>

                          {/* Time display */}
                          <div style={{ color: '#e5e7eb', fontSize: '13px', fontFamily: 'monospace', userSelect: 'none' }}>
                            {formatTime(currentTime)} / {formatTime(duration)}
                          </div>
                        </div>

                        {/* Right Side: Options + Speed + Fullscreen */}
                        <div style={{ display: 'flex', alignItems: 'center', gap: '20px', direction: 'rtl' }}>
                          
                          {/* Playback speed */}
                          <div className="player-menu-container" style={{ position: 'relative' }}>
                            <button 
                              className="player-control-btn"
                              onClick={() => { setShowSpeedMenu(!showSpeedMenu); setShowQualityMenu(false); }}
                              style={{ background: 'none', color: '#fff', border: 'none', cursor: 'pointer', fontSize: '13px', fontWeight: 'bold', fontFamily: 'Cairo', display: 'flex', alignItems: 'center', gap: '4px' }}
                            >
                              <span>{playbackRate}x</span>
                              <span className="icon" style={{ fontSize: '18px' }}>speed</span>
                            </button>
                            {showSpeedMenu && (
                              <div className="player-dropdown-menu" style={{ position: 'absolute', bottom: '34px', right: 0, backgroundColor: 'rgba(16,18,27,0.96)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', padding: '6px 0', minWidth: '90px', display: 'flex', flexDirection: 'column', zIndex: 110, backdropFilter: 'blur(12px)', boxShadow: '0 10px 25px -5px rgba(0,0,0,0.5)' }}>
                                {[0.5, 0.75, 1, 1.25, 1.5, 2].map((rate) => (
                                  <button
                                    key={rate}
                                    onClick={() => { handleSpeedChange(rate); setShowSpeedMenu(false); }}
                                    style={{ background: 'none', border: 'none', color: playbackRate === rate ? 'rgb(var(--primary))' : '#fff', padding: '8px 16px', fontSize: '12px', cursor: 'pointer', textAlign: 'center', fontWeight: playbackRate === rate ? 'bold' : 'normal', fontFamily: 'Cairo' }}
                                  >
                                    {rate}x
                                  </button>
                                ))}
                              </div>
                            )}
                          </div>

                          {/* Quality selection */}
                          {qualities.length > 0 && (
                            <div className="player-menu-container" style={{ position: 'relative' }}>
                              <button 
                                className="player-control-btn"
                                onClick={() => { setShowQualityMenu(!showQualityMenu); setShowSpeedMenu(false); }}
                                style={{ background: 'none', color: '#fff', border: 'none', cursor: 'pointer', fontSize: '13px', fontWeight: 'bold', fontFamily: 'Cairo', display: 'flex', alignItems: 'center', gap: '4px' }}
                              >
                                <span>{currentQuality === -1 ? 'تلقائي' : `${qualities[currentQuality]?.height || qualities[currentQuality]?.name}p`}</span>
                                <span className="icon" style={{ fontSize: '18px' }}>settings</span>
                              </button>
                              {showQualityMenu && (
                                <div className="player-dropdown-menu" style={{ position: 'absolute', bottom: '34px', right: 0, backgroundColor: 'rgba(16,18,27,0.96)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', padding: '6px 0', minWidth: '120px', display: 'flex', flexDirection: 'column', zIndex: 110, backdropFilter: 'blur(12px)', boxShadow: '0 10px 25px -5px rgba(0,0,0,0.5)' }}>
                                  <button
                                    onClick={() => { handleQualityChange(-1); setShowQualityMenu(false); }}
                                    style={{ background: 'none', border: 'none', color: currentQuality === -1 ? 'rgb(var(--primary))' : '#fff', padding: '8px 16px', fontSize: '12px', cursor: 'pointer', textAlign: 'center', fontWeight: currentQuality === -1 ? 'bold' : 'normal', fontFamily: 'Cairo' }}
                                  >
                                    تلقائي (Auto)
                                  </button>
                                  {qualities.map((level, index) => (
                                    <button
                                      key={index}
                                      onClick={() => { handleQualityChange(index); setShowQualityMenu(false); }}
                                      style={{ background: 'none', border: 'none', color: currentQuality === index ? 'rgb(var(--primary))' : '#fff', padding: '8px 16px', fontSize: '12px', cursor: 'pointer', textAlign: 'center', fontWeight: currentQuality === index ? 'bold' : 'normal', fontFamily: 'Cairo' }}
                                    >
                                      {level.height ? `${level.height}p` : `جودة ${index + 1}`}
                                    </button>
                                  ))}
                                </div>
                              )}
                            </div>
                          )}

                          {/* Rotate Video */}
                          <button 
                            onClick={rotateVideo}
                            title="تدوير الفيديو"
                            style={{ background: 'none', color: '#fff', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', padding: 0 }}
                          >
                            <span className="icon" style={{ fontSize: '22px' }}>
                              screen_rotation
                            </span>
                          </button>

                          {/* Theater Mode toggle */}
                          <button 
                            onClick={() => setIsTheaterMode(!isTheaterMode)}
                            title={isTheaterMode ? "الوضع العادي" : "الوضع السينمائي"}
                            style={{ background: 'none', color: isTheaterMode ? 'rgb(var(--primary))' : '#fff', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', padding: 0 }}
                          >
                            <span className="icon" style={{ fontSize: '22px' }}>
                              {isTheaterMode ? 'splitscreen' : 'view_sidebar'}
                            </span>
                          </button>

                          {/* Fullscreen toggle */}
                          <button 
                            onClick={toggleFullscreen}
                            style={{ background: 'none', color: '#fff', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', padding: 0 }}
                          >
                            <span className="icon" style={{ fontSize: '24px' }}>
                              {isFullscreen ? 'fullscreen_exit' : 'fullscreen'}
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* ── Custom Resume Watch Overlay Prompt ── */}
                    {showResumePrompt && (
                      <div 
                        style={{
                          position: 'absolute',
                          top: 0, left: 0, right: 0, bottom: 0,
                          backgroundColor: 'rgba(10,12,18,0.85)',
                          backdropFilter: 'blur(10px)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          zIndex: 200,
                          color: '#fff',
                          fontFamily: 'Cairo, sans-serif',
                          padding: '20px',
                          direction: 'rtl'
                        }}
                      >
                        <div className="card-glass" style={{ maxWidth: '420px', width: '100%', textAlign: 'center', border: '1px solid rgb(var(--outline) / 0.2)', borderRadius: '16px', padding: '32px', boxShadow: 'var(--shadow-lg)' }}>
                          <span className="icon animate-float" style={{ fontSize: '48px', color: 'rgb(var(--primary))', marginBottom: '16px' }}>history</span>
                          <h4 className="title-small" style={{ marginBottom: '12px', color: '#fff', fontWeight: 'bold' }}>مرحباً بك مجدداً!</h4>
                          <p className="body-medium" style={{ color: 'rgba(255,255,255,0.7)', fontSize: '13px', lineHeight: '1.6', marginBottom: '24px' }}>
                            لقد شاهدت جزءاً من هذه المحاضرة سابقاً. هل ترغب في استكمال المشاهدة من حيث توقفت عند <b>{formatTime(startPositionToResume)}</b>؟
                          </p>
                          <div className="flex gap-md" style={{ justifyContent: 'center' }}>
                            <button 
                              className="btn btn-primary"
                              onClick={confirmResume}
                              style={{ padding: '10px 24px', fontSize: '13px' }}
                            >
                              نعم، استكمل المشاهدة
                            </button>
                            <button 
                              className="btn btn-secondary"
                              onClick={cancelResume}
                              style={{ padding: '10px 24px', fontSize: '13px' }}
                            >
                              البدء من البداية
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                  </>
                )}

                {/* Secure floating watermark overlay */}
                {!loading && !errorMessage && (
                  <Watermark text={watermarkText} active={isPlaying || playbackData?.provider === 'youtube'} />
                )}
              </div>
            </div>

            {/* Lesson metadata info */}
            <div className="card" style={{ padding: '24px', backgroundColor: 'rgb(var(--surface-container-low))', border: '1px solid rgb(var(--outline) / 0.15)' }}>
              <div className="flex justify-between items-start" style={{ width: '100%', gap: '16px', flexWrap: 'wrap' }}>
                <div>
                  <h2 className="title-medium" style={{ marginBottom: '8px', fontWeight: '800', color: 'rgb(var(--on-surface))' }}>{lessonTitle}</h2>
                  <div className="flex items-center gap-md" style={{ color: 'rgb(var(--on-surface-variant))', fontSize: '13px' }}>
                    <span className="flex items-center gap-xs">
                      <span className="icon" style={{ fontSize: '16px', color: 'rgb(var(--primary))' }}>security</span>
                      <span>بث فيديو محمي بالكامل</span>
                    </span>
                    {playbackData?.duration_seconds && (
                      <span>مدة المحاضرة: {Math.floor(playbackData.duration_seconds / 60)} دقيقة</span>
                    )}
                  </div>
                </div>
                
                <button
                  className="btn btn-secondary"
                  onClick={() => setShowDebugConsole(prev => !prev)}
                  style={{ padding: '8px 16px', display: 'flex', alignItems: 'center', gap: '6px', minWidth: 0, fontSize: '12px', borderRadius: '8px' }}
                >
                  <span className="icon" style={{ fontSize: '16px' }}>bug_report</span>
                  {showDebugConsole ? 'إخفاء سجل الأخطاء' : 'فحص أخطاء البث 🛠️'}
                </button>
              </div>
              <div className="badge badge-danger" style={{ marginTop: '16px', padding: '8px 12px', borderRadius: '8px', fontSize: '11px', width: '100%', justifyContent: 'center' }}>
                تنبيه أمني: تصوير أو تسجيل الشاشة يعرض حسابك للإيقاف والملاحقة القانونية فوراً.
              </div>
            </div>

            {/* Debug Console Display */}
            {showDebugConsole && (
              <div className="card" style={{ backgroundColor: 'rgb(var(--surface-dim))', border: '1px solid #ff444455', direction: 'ltr' }}>
                <div className="flex justify-between items-center" style={{ width: '100%', marginBottom: '12px', borderBottom: '1px solid #ffffff11', paddingBottom: '8px', direction: 'rtl' }}>
                  <span style={{ fontWeight: 'bold', color: '#ff4444', display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <span className="icon">bug_report</span>
                    لوحة تشخيص أخطاء البث والفيديو (Developer Logs)
                  </span>
                  <div className="flex gap-sm">
                    <button className="btn btn-secondary" onClick={copyDebugLogs} style={{ padding: '4px 10px', fontSize: '11px', minWidth: 0 }}>
                      {logsCopied ? 'تم النسخ! ✓' : 'نسخ السجلات 📋'}
                    </button>
                    <button className="btn btn-secondary" onClick={() => setDebugLogs([])} style={{ padding: '4px 10px', fontSize: '11px', minWidth: 0 }}>
                      ...
                    </button>
                  </div>
                </div>
                
                <div style={{ color: '#aaa', fontSize: '11px', fontFamily: 'monospace', marginBottom: '8px' }}>
                  <strong>Browser Agent:</strong> {navigator.userAgent} <br/>
                  <strong>WebCodecs Support:</strong> {('VideoDecoder' in window) ? 'Yes' : 'No'} | 
                  <strong> Hls.js Support:</strong> {Hls.isSupported() ? 'Yes' : 'No'} |
                  <strong> HTML5 Source:</strong> {playbackData?.playback_url ? 'Yes' : 'No'}
                </div>

                <div style={{
                  height: '180px',
                  overflowY: 'auto',
                  backgroundColor: '#0a0c12',
                  borderRadius: '6px',
                  padding: '8px 12px',
                  fontFamily: 'monospace',
                  fontSize: '11px',
                  lineHeight: '1.5'
                }}>
                  {debugLogs.length === 0 ? (
                    <div style={{ color: '#555', fontStyle: 'italic' }}>No logs recorded yet. Play the video to trigger events.</div>
                  ) : (
                    debugLogs.map((log, idx) => (
                      <div key={idx} style={{
                        color: log.level === 'error' ? '#ff6b6b' : log.level === 'warn' ? '#ffd23f' : '#e5e7eb',
                        marginBottom: '4px',
                        wordBreak: 'break-all'
                      }}>
                        [{log.time}] [{log.level.toUpperCase()}] {log.message}
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
              </div>
            </div>
          </div>

          <div 
            className="player-layout-sidebar"
            style={{
              maxWidth: inlinePdfBlobUrl ? '680px' : '380px',
              width: '100%',
              transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
            }}
          >
            <div className="card flex-col" style={{ padding: '16px', backgroundColor: 'rgb(var(--surface-container-low))', border: '1px solid rgb(var(--outline) / 0.15)', minHeight: '450px' }}>
              
              {/* Tabs Header */}
              <div className="segmented-tabs-container">
                <button
                  className={`segmented-tab-button ${activeSidebarTab === 'playlist' ? 'active' : ''}`}
                  onClick={() => setActiveSidebarTab('playlist')}
                >
                  <span className="icon" style={{ fontSize: '15px' }}>playlist_play</span>
                  <span>المحاضرات</span>
                </button>
                
                <button
                  className={`segmented-tab-button ${activeSidebarTab === 'attachments' ? 'active' : ''}`}
                  onClick={() => setActiveSidebarTab('attachments')}
                >
                  <span className="icon" style={{ fontSize: '15px' }}>description</span>
                  <span>المرفقات ({attachments.length})</span>
                </button>

                <button
                  className={`segmented-tab-button ${activeSidebarTab === 'qa' ? 'active' : ''}`}
                  onClick={() => setActiveSidebarTab('qa')}
                >
                  <span className="icon" style={{ fontSize: '15px' }}>forum</span>
                  <span>الاستفسارات</span>
                </button>

                <button
                  className={`segmented-tab-button ${activeSidebarTab === 'quiz' ? 'active' : ''}`}
                  onClick={() => setActiveSidebarTab('quiz')}
                >
                  <span className="icon" style={{ fontSize: '15px' }}>quiz</span>
                  <span>الواجبات</span>
                </button>
              </div>

              {/* Tab 1: Playlist Content */}
              {activeSidebarTab === 'playlist' && (
                <div className="flex flex-col gap-sm" style={{ overflowY: 'auto', maxHeight: '450px', paddingLeft: '4px' }}>
                  {courseLessons.length === 0 ? (
                    <p className="body-small text-center" style={{ fontStyle: 'italic', padding: '20px' }}>جاري تحميل قائمة الدروس...</p>
                  ) : (
                    courseLessons.map((les) => {
                      const isCurrent = les.id === lessonId;
                      return (
                        <div
                          key={les.id}
                          onClick={() => {
                            if (!isCurrent && onSelectLesson) {
                              onSelectLesson(les.id, les.title, les.type === 'pdf' ? 'pdf' : 'video');
                            }
                          }}
                          className="flex justify-between items-center"
                          style={{
                            padding: '10px 12px',
                            borderRadius: '8px',
                            backgroundColor: isCurrent ? 'rgba(var(--primary), 0.08)' : 'rgb(var(--surface-dim))',
                            border: isCurrent ? '1px solid rgba(var(--primary), 0.25)' : '1px solid transparent',
                            cursor: isCurrent ? 'default' : 'pointer',
                            opacity: isCurrent ? 1 : 0.85,
                            transition: 'all 0.2s'
                          }}
                        >
                          <div className="flex items-center gap-sm" style={{ minWidth: 0 }}>
                            <span className="icon" style={{ fontSize: '16px', color: isCurrent ? 'rgb(var(--primary))' : 'rgb(var(--on-surface-variant))' }}>
                              {les.type === 'pdf' ? 'picture_as_pdf' : 'play_circle'}
                            </span>
                            <div className="flex-col" style={{ minWidth: 0 }}>
                              <span style={{ fontSize: '12px', fontWeight: 'bold', color: isCurrent ? 'rgb(var(--primary))' : 'rgb(var(--on-surface))', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                {les.title}
                              </span>
                              <span style={{ fontSize: '9px', color: 'rgb(var(--on-surface-variant))' }}>
                                {les.unitTitle || 'الوحدة الدراسية'}
                              </span>
                            </div>
                          </div>
                          {isCurrent && (
                            <span className="badge badge-accent" style={{ fontSize: '8px', padding: '2px 6px' }}>قيد التشغيل</span>
                          )}
                        </div>
                      );
                    })
                  )}
                </div>
              )}

              {/* Tab 2: Attachments Content */}
              {activeSidebarTab === 'attachments' && (
                <div className="flex flex-col gap-sm" style={{ overflowY: inlinePdfBlobUrl ? 'visible' : 'auto', maxHeight: inlinePdfBlobUrl ? 'none' : '450px' }}>
                  {inlinePdfBlobUrl ? (
                    renderInlinePdfViewer()
                  ) : attachments.length === 0 ? (
                    <div className="text-center" style={{ padding: '40px 10px', color: 'rgb(var(--on-surface-variant))' }}>
                      <span className="icon" style={{ fontSize: '32px', marginBottom: '8px' }}>info</span>
                      <p className="body-small">لا توجد ملفات أو مذكرات مرفقة مع هذا الدرس.</p>
                    </div>
                  ) : (
                    attachments.map((att) => (
                      <div
                        key={att.id}
                        className="flex justify-between items-center"
                        style={{
                          padding: '12px',
                          borderRadius: '8px',
                          backgroundColor: 'rgb(var(--surface-dim))',
                          border: '1px solid rgb(var(--outline) / 0.08)'
                        }}
                      >
                        <div className="flex items-center gap-sm" style={{ minWidth: 0 }}>
                          <span className="icon" style={{ color: 'rgb(var(--primary))', fontSize: '18px' }}>picture_as_pdf</span>
                          <span style={{ fontSize: '11px', fontWeight: 'bold', color: 'rgb(var(--on-surface))', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                            {att.title}
                          </span>
                        </div>
                        <div className="flex gap-xs">
                          <button
                            className="btn btn-primary"
                            onClick={() => handleOpenInlinePdf(att.url, att.title)}
                            style={{ padding: '6px 8px', fontSize: '10px', borderRadius: '6px', minWidth: 0 }}
                          >
                            عرض بالصفحة
                          </button>
                          <button
                            className="btn btn-secondary"
                            onClick={() => handleOpenPdf(att.url)}
                            style={{ padding: '6px 8px', fontSize: '10px', borderRadius: '6px', minWidth: 0 }}
                          >
                            ملء الشاشة
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* Tab 3: Q&A Content */}
              {activeSidebarTab === 'qa' && (
                <div className="flex flex-col gap-md" style={{ overflowY: 'auto', maxHeight: '450px', paddingLeft: '4px' }}>
                  {!user ? (
                    <div className="text-center" style={{ padding: '40px 10px', color: 'rgb(var(--on-surface-variant))' }}>
                      <span className="material-symbols-outlined" style={{ fontSize: '32px', marginBottom: '8px', color: 'rgb(var(--primary))' }}>lock</span>
                      <p className="body-small" style={{ fontWeight: 'bold' }}>يجب تسجيل الدخول لطرح الأسئلة ومتابعة الاستفسارات.</p>
                    </div>
                  ) : (
                    <>
                      {/* Ask form */}
                      <form onSubmit={handlePostQuestion} style={{ borderBottom: '1px solid rgb(var(--outline) / 0.1)', paddingBottom: '12px' }}>
                        <div className="flex-col gap-xs">
                          <span style={{ fontSize: '11px', fontWeight: 'bold', color: 'rgb(var(--on-surface))' }}>اطرح سؤالاً عن الشرح:</span>
                          <div className="flex gap-sm">
                            <input
                              type="text"
                              className="input-text"
                              placeholder="اكتب سؤالك هنا للأستاذ..."
                              value={newQuestionBody}
                              onChange={e => setNewQuestionBody(e.target.value)}
                              style={{ padding: '8px 12px', fontSize: '11px', borderRadius: '8px' }}
                              required
                            />
                            <button
                              type="submit"
                              className="btn btn-primary"
                              disabled={submittingQuestion}
                              style={{ padding: '8px 12px', fontSize: '11px', borderRadius: '8px', minWidth: 0 }}
                            >
                              {submittingQuestion ? '..' : 'إرسال'}
                            </button>
                          </div>
                          {qaError && (
                            <p style={{ fontSize: '10px', color: '#ef4444', marginTop: '6px', fontWeight: 'bold', textAlign: 'right' }}>{qaError}</p>
                          )}
                          {qaSuccess && (
                            <p style={{ fontSize: '10px', color: '#10b981', marginTop: '6px', fontWeight: 'bold', textAlign: 'right' }}>{qaSuccess}</p>
                          )}
                        </div>
                      </form>

                      {/* Questions list */}
                      {questions.length === 0 ? (
                        <p className="body-small text-center" style={{ color: 'rgb(var(--on-surface-variant))', fontStyle: 'italic', padding: '20px 0' }}>لا توجد استفسارات سابقة. كن أول من يسأل!</p>
                      ) : (
                        <div className="flex flex-col gap-sm">
                          {questions.map(q => (
                            <div
                              key={q.id}
                              className="flex-col"
                              style={{
                                padding: '10px',
                                borderRadius: '8px',
                                backgroundColor: 'rgb(var(--surface-dim))',
                                borderRight: q.status === 'answered' ? '3px solid #10b981' : '3px solid rgb(var(--primary))',
                              }}
                            >
                              <div className="flex justify-between items-center" style={{ marginBottom: '6px' }}>
                                <span style={{ fontWeight: 'bold', fontSize: '10px', color: 'rgb(var(--on-surface-variant))' }}>سؤال طالب</span>
                                <span className={`badge ${q.status === 'answered' ? 'badge-success' : 'badge-primary'}`} style={{ fontSize: '8px', padding: '1px 4px' }}>
                                  {q.status === 'answered' ? 'تمت الإجابة' : 'قيد الانتظار'}
                                </span>
                              </div>
                              <p className="body-small" style={{ color: 'rgb(var(--on-surface))', fontSize: '11px', lineHeight: '1.5' }}>{q.body}</p>

                              {/* Answer */}
                              {q.status === 'answered' && q.answers && q.answers.length > 0 && (
                                <div style={{ marginTop: '8px', padding: '6px 8px', borderRight: '2px solid rgb(var(--primary))', backgroundColor: 'rgb(var(--surface-container-high))', borderRadius: '4px' }}>
                                  {q.answers.map((ans: any) => (
                                    <div key={ans.id}>
                                      <span style={{ fontWeight: 'bold', fontSize: '9px', color: 'rgb(var(--primary))' }}>{ans.author_name} (الإدارة):</span>
                                      <p className="body-small" style={{ fontSize: '10px', color: 'rgb(var(--on-surface-variant))', marginTop: '1px' }}>{ans.body}</p>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                    </>
                  )}
                </div>
              )}

              {/* Tab 4: Quiz Content */}
              {activeSidebarTab === 'quiz' && (
                <div 
                  className="flex flex-col gap-md" 
                  style={{ 
                    maxHeight: '400px', 
                    overflowY: 'auto', 
                    paddingRight: '4px',
                    direction: 'rtl',
                    textAlign: 'right'
                  }}
                >
                  {!user ? (
                    <div className="text-center" style={{ padding: '40px 10px', color: 'rgb(var(--on-surface-variant))' }}>
                      <span className="material-symbols-outlined" style={{ fontSize: '32px', marginBottom: '8px', color: 'rgb(var(--primary))' }}>lock</span>
                      <p className="body-small" style={{ fontWeight: 'bold' }}>يجب تسجيل الدخول لحل الواجبات والاختبارات.</p>
                    </div>
                  ) : quizLoading ? (
                    <div className="flex flex-col items-center justify-center" style={{ padding: '30px 0' }}>
                      <span className="material-symbols-outlined animate-spin" style={{ fontSize: '24px', color: 'rgb(var(--primary))' }}>sync</span>
                      <p className="body-small" style={{ marginTop: '8px', color: '#9ca3af' }}>جاري تحميل الأسئلة...</p>
                    </div>
                  ) : quizError ? (
                    <div style={{ textAlign: 'center', padding: '20px 10px', color: '#ef4444' }}>
                      <span className="material-symbols-outlined" style={{ fontSize: '24px', marginBottom: '8px' }}>warning</span>
                      <p className="body-small" style={{ fontWeight: 'bold' }}>{quizError}</p>
                    </div>
                  ) : !quizData ? (
                    <p className="body-small text-center" style={{ color: 'rgb(var(--on-surface-variant))', fontStyle: 'italic', padding: '20px 0' }}>
                      لا يوجد واجب أو اختبار متاح لهذه المحاضرة حالياً.
                    </p>
                  ) : quizAttempt ? (
                    /* Show attempt result */
                    <div className="flex flex-col gap-sm" style={{ padding: '10px', backgroundColor: 'rgba(255, 255, 255, 0.02)', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.05)' }}>
                      <div className="flex items-center gap-sm" style={{ color: '#10b981', fontWeight: 'bold', fontSize: '13px' }}>
                        <span className="icon">check_circle</span>
                        <span>تم تسليم الحل بنجاح!</span>
                      </div>
                      
                      <div className="flex justify-between items-center" style={{ marginTop: '10px', padding: '8px 12px', backgroundColor: '#18181c', borderRadius: '8px' }}>
                        <span style={{ fontSize: '11px', color: '#aaa' }}>درجتك في هذا الاختبار:</span>
                        <span style={{ fontWeight: 'bold', color: '#10b981', fontSize: '15px' }}>
                          {quizAttempt.score} / {quizData.max_score}
                        </span>
                      </div>

                      <div className="space-y-3" style={{ marginTop: '15px' }}>
                        <p style={{ fontSize: '11px', fontWeight: 'bold', color: '#aaa' }}>مراجعة إجاباتك:</p>
                        {quizQuestionsList.map((q, idx) => {
                          const studentAnswer = quizAttempt.answers?.[q.id];
                          return (
                            <div key={q.id} className="p-3" style={{ backgroundColor: 'rgba(255,255,255,0.01)', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.03)' }}>
                              <p style={{ fontSize: '11px', fontWeight: 'bold', color: '#fff' }}>س {idx + 1}: {q.question_text || '(سؤال بصورة)'}</p>
                              {q.image_url && <img src={q.image_url} alt="سؤال" style={{ maxWidth: '100%', maxHeight: '100px', objectFit: 'contain', marginTop: '6px' }} />}
                              
                              <p style={{ fontSize: '10px', marginTop: '6px', color: studentAnswer ? '#3b82f6' : '#ef4444' }}>
                                <strong>إجابتك: </strong> {studentAnswer || 'لم يتم الحل'}
                              </p>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ) : (
                    /* Show Quiz Solver Form */
                    <div className="flex flex-col gap-md">
                      <div style={{ paddingBottom: '10px', borderBottom: '1px solid rgb(var(--outline) / 0.1)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <div>
                          <h4 style={{ fontSize: '13px', fontWeight: 'bold', color: 'rgb(var(--on-surface))' }}>{quizData.title}</h4>
                          <p style={{ fontSize: '9px', color: '#aaa', marginTop: '2px' }}>الدرجة الكلية: {quizData.max_score} درجة • الأسئلة: {quizQuestionsList.length}</p>
                        </div>
                        {quizTimeLeft !== null && (
                          <div style={{ backgroundColor: 'rgba(var(--primary), 0.15)', border: '1px solid rgba(var(--primary), 0.3)', padding: '4px 8px', borderRadius: '8px', color: 'rgb(var(--primary))', fontSize: '12px', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '4px' }}>
                            <span className="material-symbols-outlined animate-pulse" style={{ fontSize: '16px' }}>timer</span>
                            <span>{formatTimeLeft(quizTimeLeft)}</span>
                          </div>
                        )}
                      </div>

                      <div className="space-y-4" style={{ marginTop: '10px' }}>
                        {quizQuestionsList.map((q, idx) => (
                          <div key={q.id} className="p-3 flex flex-col gap-sm" style={{ backgroundColor: 'rgb(var(--surface-dim))', borderRadius: '8px', border: '1px solid rgb(var(--outline) / 0.08)' }}>
                            <p style={{ fontSize: '11px', fontWeight: 'bold', color: 'rgb(var(--on-surface))' }}>س {idx + 1}: {q.question_text || '(انظر الصورة)'}</p>
                            
                            {q.image_url && (
                              <img src={q.image_url} alt="سؤال" style={{ maxWidth: '100%', maxHeight: '120px', objectFit: 'contain', marginTop: '6px', borderRadius: '4px' }} />
                            )}

                            <div className="flex flex-col gap-xs" style={{ marginTop: '8px' }}>
                              {q.options.map((opt: string, oIdx: number) => {
                                const isSelected = studentAnswers[q.id] === opt;
                                return (
                                  <label 
                                    key={oIdx} 
                                    className="flex items-center gap-sm" 
                                    style={{ 
                                      padding: '6px 8px', 
                                      borderRadius: '6px', 
                                      backgroundColor: isSelected ? 'rgba(var(--primary), 0.08)' : 'transparent',
                                      border: isSelected ? '1px solid rgba(var(--primary), 0.2)' : '1px solid transparent',
                                      cursor: 'pointer',
                                      fontSize: '10px',
                                      color: isSelected ? 'rgb(var(--primary))' : 'rgb(var(--on-surface))'
                                    }}
                                  >
                                    <input 
                                      type="radio" 
                                      name={`question-${q.id}`} 
                                      checked={isSelected}
                                      onChange={() => {
                                        setStudentAnswers({
                                          ...studentAnswers,
                                          [q.id]: opt
                                        });
                                      }}
                                      style={{ accentColor: 'rgb(var(--primary))' }}
                                    />
                                    <span>{opt}</span>
                                  </label>
                                );
                              })}
                            </div>
                          </div>
                        ))}
                      </div>

                      {quizError && (
                        <p style={{ fontSize: '10px', color: '#ef4444', marginTop: '8px' }}>{quizError}</p>
                      )}

                      {!showSubmitConfirm ? (
                        <button
                          className="btn btn-primary"
                          onClick={() => setShowSubmitConfirm(true)}
                          disabled={submittingQuiz || Object.keys(studentAnswers).length === 0}
                          style={{
                            width: '100%',
                            marginTop: '15px',
                            padding: '10px',
                            fontSize: '11px',
                            fontWeight: 'bold',
                            backgroundColor: 'rgb(var(--primary))',
                            color: '#fff',
                            border: 'none',
                            borderRadius: '8px',
                            cursor: 'pointer'
                          }}
                        >
                          تسليم إجابات الواجب
                        </button>
                      ) : (
                        <div style={{ marginTop: '15px', padding: '10px', backgroundColor: 'rgba(var(--primary), 0.08)', border: '1px solid rgba(var(--primary), 0.2)', borderRadius: '8px', textAlign: 'center' }}>
                          <p style={{ fontSize: '10px', color: 'rgb(var(--on-surface))', fontWeight: 'bold', marginBottom: '8px' }}>هل أنت متأكد من تسليم الإجابات؟ لا يمكن التعديل لاحقاً.</p>
                          <div className="flex gap-xs justify-center">
                            <button
                              className="btn btn-primary"
                              onClick={() => handleSubmitQuiz(false)}
                              disabled={submittingQuiz}
                              style={{ padding: '6px 12px', fontSize: '10px', backgroundColor: 'rgb(var(--primary))', borderRadius: '6px', minWidth: 0 }}
                            >
                              {submittingQuiz ? 'جاري التسليم...' : 'تأكيد التسليم'}
                            </button>
                            <button
                              className="btn btn-secondary"
                              onClick={() => setShowSubmitConfirm(false)}
                              disabled={submittingQuiz}
                              style={{ padding: '6px 12px', fontSize: '10px', borderRadius: '6px', minWidth: 0 }}
                            >
                              تراجع
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

        </div>

      </div>
      {/* ── Secure PDF Modal Viewer ── */}
      {selectedPdfUrl && (
        <div className="modal-overlay" style={{ zIndex: 2000 }}>
          <div className="modal-content" style={{ maxWidth: '800px', width: '95%', height: '85vh', display: 'flex', flexDirection: 'column' }}>
            {/* Header bar */}
            <div className="flex justify-between items-center" style={{ padding: '16px 24px', borderBottom: '1px solid rgb(var(--outline) / 0.15)' }}>
              <h3 className="title-small" style={{ margin: 0 }}>عارض المذكرات الآمن</h3>
              <button
                className="btn btn-secondary"
                style={{ padding: '6px 12px', minWidth: 0 }}
                onClick={() => {
                  setSelectedPdfUrl(null);
                  if (pdfBlobUrl) {
                    URL.revokeObjectURL(pdfBlobUrl);
                    setPdfBlobUrl(null);
                  }
                }}
              >
                إغلاق العارض
              </button>
            </div>

            {/* Document display */}
            <div style={{ flex: 1, position: 'relative', backgroundColor: 'rgb(var(--surface-dim))' }}>
              
              {pdfLoading ? (
                <Loader text="جاري تحميل الملف وتأمين التشفير" size="small" />
              ) : pdfBlobUrl ? (
                <iframe
                  src={`${pdfBlobUrl}#toolbar=0&navpanes=0&scrollbar=0`}
                  style={{ width: '100%', height: '100%', border: 'none' }}
                />
              ) : (
                <div className="flex items-center justify-center h-full">فشل تحميل الملف</div>
              )}

              {/* Diagonal Watermarks overlay across the document */}
              {!pdfLoading && pdfBlobUrl && (
                <div
                  style={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    width: '100%',
                    height: '100%',
                    pointerEvents: 'none',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'space-around',
                    alignItems: 'center',
                    opacity: 0.08,
                    zIndex: 10,
                    overflow: 'hidden',
                  }}
                >
                  {Array.from({ length: 5 }).map((_, i) => (
                    <div
                      key={i}
                      style={{
                        transform: 'rotate(-25deg)',
                        fontSize: '18px',
                        fontWeight: 'bold',
                        color: '#000',
                        fontFamily: 'Cairo, sans-serif',
                        whiteSpace: 'nowrap',
                      }}
                    >
                      {profile?.full_name} - {profile?.phone}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </SecurityGuard>
  );
};

export default LessonPlayer;

