import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { ApiService, getDeviceId } from '../services/api';
import { supabase } from '../services/supabase';

const grades = [
  'الصف الأول الثانوي',
  'الصف الثاني الثانوي',
  'الصف الثالث الثانوي',
];

const governorates = [
  'القاهرة', 'الجيزة', 'الإسكندرية', 'القليوبية', 'الدقهلية',
  'الشرقية', 'المنوفية', 'الغربية', 'البحيرة', 'دمياط',
  'كفر الشيخ', 'الفيوم', 'بني سويف', 'المنيا',
  'أسيوط', 'سوهاج', 'قنا', 'الأقصر', 'أسوان', 'البحر الأحمر',
  'الوادي الجديد', 'مطروح', 'شمال سيناء', 'جنوب سيناء', 'السويس', 'الإسماعيلية', 'بورسعيد'
];

interface LoginRegisterProps {
  onBrowseAsGuest?: () => void;
}

export const LoginRegister: React.FC<LoginRegisterProps> = ({ onBrowseAsGuest }) => {
  const {
    login,
    register,
    completeProfileSetup,
    needsProfileSetup,
    error,
    clearError
  } = useAuth();

  const [isSignUp, setIsSignUp] = useState(false);
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [showDeviceResetDialog, setShowDeviceResetDialog] = useState(false);
  const [deviceResetReason, setDeviceResetReason] = useState('');
  const [deviceResetSuccess, setDeviceResetSuccess] = useState(false);
  const [resetLoading, setResetLoading] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Form Fields
  const [emailOrPhone, setEmailOrPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [parentPhone, setParentPhone] = useState('');
  const [selectedGender, setSelectedGender] = useState('ذكر');
  const [selectedGrade, setSelectedGrade] = useState('الصف الأول الثانوي');
  const [selectedSpec, setSelectedSpec] = useState('عام');
  const [selectedGov, setSelectedGov] = useState('القاهرة');

  // Forgot password flow
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotSent, setForgotSent] = useState(false);

  const getSpecializations = (grade: string) => {
    if (grade === 'الصف الأول الثانوي') return ['عام', 'أزهر'];
    if (grade === 'الصف الثاني الثانوي') return ['عام', 'أزهر', 'علمي', 'أدبي'];
    return ['عام', 'أزهر', 'علمي علوم', 'علمي رياضة', 'أدبي'];
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    clearError();
    setLoading(true);

    try {
      if (!emailOrPhone || !password) {
        throw new Error('يرجى ملء جميع الحقول المطلوبة');
      }
      await login(emailOrPhone, password);
    } catch (err: any) {
      console.error(err);
      if (err.code === 'DEVICE_LIMIT_EXCEEDED' || (err.message && err.message.includes('الأجهزة'))) {
        setShowDeviceResetDialog(true);
      } else {
        setFormError(err.message || 'فشل تسجيل الدخول. يرجى مراجعة الحقول.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSignUpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    clearError();
    setLoading(true);

    try {
      if (!fullName || !phone || !parentPhone || !password || !confirmPassword) {
        throw new Error('يرجى ملء جميع الحقول المطلوبة');
      }
      if (password !== confirmPassword) {
        throw new Error('كلمتا المرور غير متطابقتين');
      }
      if (phone.length < 10) {
        throw new Error('رقم الهاتف غير صالح');
      }
      if (parentPhone.length < 10) {
        throw new Error('رقم هاتف ولي الأمر غير صالح');
      }

      await register({
        phone,
        fullName,
        parentPhone,
        grade: `${selectedGrade} - ${selectedSpec}`,
        governorate: selectedGov,
        password,
      });
    } catch (err: any) {
      console.error(err);
      setFormError(err.message || 'فشل التسجيل. حاول مرة أخرى.');
    } finally {
      setLoading(false);
    }
  };

  const handleProfileSetupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    clearError();
    setLoading(true);

    try {
      if (!fullName || !phone || !parentPhone) {
        throw new Error('يرجى ملء جميع الحقول المطلوبة');
      }
      await completeProfileSetup({
        fullName,
        phone,
        parentPhone,
        grade: `${selectedGrade} - ${selectedSpec}`,
        governorate: selectedGov,
      });
    } catch (err: any) {
      console.error(err);
      setFormError(err.message || 'فشل إكمال إعداد الملف الشخصي.');
    } finally {
      setLoading(false);
    }
  };

  const handleDeviceResetSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setResetLoading(true);
    try {
      if (deviceResetReason.trim().length < 5) {
        throw new Error('يرجى كتابة سبب صحيح (5 أحرف على الأقل)');
      }
      
      await ApiService.submitDeviceResetRequest({
        device_id: getDeviceId(),
        platform: 'web',
        model: navigator.userAgent.substring(0, 50),
        reason: deviceResetReason,
      });

      setDeviceResetSuccess(true);
    } catch (err: any) {
      console.error(err);
      alert(err.message || 'فشل إرسال طلب إعادة التعيين');
    } finally {
      setResetLoading(false);
    }
  };

  const handleForgotPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const isPhone = /^[0-9]+$/.test(forgotEmail.trim());
      const email = isPhone ? `${forgotEmail.trim()}@alhadaba-chemistry.com` : forgotEmail.trim();

      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: window.location.origin + '/reset-password',
      });
      if (error) throw error;
      setForgotSent(true);
    } catch (err: any) {
      console.error(err);
      setFormError(err.message || 'تعذر إرسال رابط استعادة كلمة المرور');
    } finally {
      setLoading(false);
    }
  };

  // Validation helpers
  const isPhoneValid = (num: string) => /^01[0125][0-9]{8}$/.test(num);
  const isParentPhoneValid = (num: string) => /^01[0125][0-9]{8}$/.test(num) && num !== phone;
  const isPasswordValid = (pw: string) => pw.length >= 6;
  const isConfirmPasswordValid = (cpw: string) => cpw === password && cpw.length >= 6;
  const isFullNameValid = (name: string) => name.trim().split(' ').filter(Boolean).length >= 3;

  const activeError = formError || error;

  if (needsProfileSetup) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-md" style={{ direction: 'rtl' }}>
        <div className="card card-glass w-full" style={{ maxWidth: '500px' }}>
          <h2 className="title-medium text-center" style={{ marginBottom: '16px', color: 'rgb(var(--primary))' }}>إكمال إعداد حساب الطالب</h2>
          <p className="body-small text-center" style={{ marginBottom: '24px' }}>يرجى ملء البيانات التالية لتفعيل حسابك على المنصة بنجاح.</p>
          
          {activeError && (
            <div className="badge badge-danger w-full justify-center" style={{ padding: '12px', marginBottom: '16px' }}>
              {activeError}
            </div>
          )}

          <form onSubmit={handleProfileSetupSubmit} className="flex flex-col">
            <div className="form-group">
              <label className="form-label">الاسم بالكامل</label>
              <div className="input-container">
                <input
                  type="text"
                  className="input-text"
                  placeholder="أدخل اسمك الحقيقي بالكامل"
                  value={fullName}
                  onChange={e => setFullName(e.target.value)}
                  required
                />
                <span className="icon input-icon-right">person</span>
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">رقم الهاتف (الخاص بك)</label>
              <div className="input-container">
                <input
                  type="tel"
                  className="input-text"
                  placeholder="رقم الموبايل الشخصي"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  required
                />
                <span className="icon input-icon-right">phone_iphone</span>
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">رقم هاتف ولي الأمر</label>
              <div className="input-container">
                <input
                  type="tel"
                  className="input-text"
                  placeholder="رقم موبايل ولي الأمر للطوارئ"
                  value={parentPhone}
                  onChange={e => setParentPhone(e.target.value)}
                  required
                />
                <span className="icon input-icon-right">family_restroom</span>
              </div>
            </div>

            <div className="grid-2 gap-md" style={{ marginBottom: '16px' }}>
              <div className="form-group">
                <label className="form-label">الصف الدراسي</label>
                <select
                  className="select"
                  value={selectedGrade}
                  onChange={e => {
                    setSelectedGrade(e.target.value);
                    const specs = getSpecializations(e.target.value);
                    setSelectedSpec(specs[0]);
                  }}
                >
                  {grades.map(g => <option key={g} value={g}>{g}</option>)}
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">التخصص / الشعبة</label>
                <select
                  className="select"
                  value={selectedSpec}
                  onChange={e => setSelectedSpec(e.target.value)}
                >
                  {getSpecializations(selectedGrade).map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
            </div>

            <div className="form-group" style={{ marginBottom: '24px' }}>
              <label className="form-label">المحافظة</label>
              <select
                className="select"
                value={selectedGov}
                onChange={e => setSelectedGov(e.target.value)}
              >
                {governorates.map(gov => <option key={gov} value={gov}>{gov}</option>)}
              </select>
            </div>

            <button type="submit" className="btn btn-primary w-full" disabled={loading}>
              {loading ? 'جاري الحفظ...' : 'حفظ وإكمال التسجيل'}
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-md" style={{ direction: 'rtl', position: 'relative' }}>
      {/* Decorative Gradients */}
      <div
        className="animate-pulse-slow"
        style={{
          position: 'absolute',
          top: '-120px',
          right: '-100px',
          width: '350px',
          height: '350px',
          borderRadius: '50%',
          background: 'rgba(var(--primary), 0.08)',
          filter: 'blur(80px)',
          pointerEvents: 'none',
        }}
      />
      <div
        className="animate-pulse-slow"
        style={{
          position: 'absolute',
          bottom: '-120px',
          left: '-100px',
          width: '300px',
          height: '300px',
          borderRadius: '50%',
          background: 'rgba(var(--accent), 0.06)',
          filter: 'blur(80px)',
          pointerEvents: 'none',
        }}
      />

      <div className="card card-glass w-full" style={{ maxWidth: '450px', zIndex: 10 }}>
        {/* Logo and Brand */}
        <div className="flex flex-col items-center" style={{ marginBottom: '32px' }}>
          <div
            style={{
              width: '72px',
              height: '72px',
              borderRadius: '16px',
              background: 'linear-gradient(135deg, rgb(var(--primary)) 0%, rgb(var(--primary)) 100%)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 0 25px rgba(var(--primary), 0.45)',
              fontWeight: '900',
              fontSize: '38px',
              color: '#fff',
              fontFamily: 'system-ui, sans-serif',
              marginBottom: '20px'
            }}
          >
            S
          </div>
          <h1 className="title-medium" style={{ fontWeight: 800 }}>المنصة الطلابية</h1>
          <p className="body-small">رحلتك نحو الدرجة النهائية تبدأ هنا</p>
        </div>

        {activeError && (
          <div className="badge badge-danger w-full justify-center" style={{ padding: '12px', marginBottom: '16px' }}>
            {activeError}
          </div>
        )}

        {/* ── Forgot Password Form ── */}
        {isForgotPassword ? (
          <form onSubmit={handleForgotPasswordSubmit} className="flex flex-col">
            <h2 className="title-small text-center" style={{ marginBottom: '16px' }}>استعادة كلمة المرور</h2>
            <p className="body-small text-center" style={{ marginBottom: '20px' }}>أدخل رقم الموبايل أو بريدك الإلكتروني لإرسال رابط إعادة تعيين كلمة المرور.</p>
            
            {forgotSent ? (
              <div className="badge badge-success w-full justify-center" style={{ padding: '12px', marginBottom: '16px' }}>
                تم إرسال رابط إعادة التعيين بنجاح. تفقد بريدك الإلكتروني.
              </div>
            ) : (
              <div className="form-group">
                <label className="form-label">البريد أو رقم الهاتف</label>
                <div className="input-container">
                  <input
                    type="text"
                    className="input-text"
                    placeholder="أدخل بريدك الإلكتروني أو رقم الموبايل"
                    value={forgotEmail}
                    onChange={e => setForgotEmail(e.target.value)}
                    required
                  />
                  <span className="icon input-icon-right">mail</span>
                </div>
              </div>
            )}

            <button type="submit" className="btn btn-primary w-full" disabled={loading || forgotSent} style={{ marginBottom: '16px' }}>
              {loading ? 'جاري الإرسال...' : 'إرسال الرابط'}
            </button>

            <button type="button" className="btn btn-secondary w-full" onClick={() => setIsForgotPassword(false)}>
              العودة لتسجيل الدخول
            </button>
          </form>
        ) : isSignUp ? (
          /* ── Register Form ── */
          <form onSubmit={handleSignUpSubmit} className="flex flex-col">
            <h2 className="title-small text-center" style={{ marginBottom: '24px' }}>إنشاء حساب طالب جديد</h2>
            
            <div className="form-group">
              <label className="form-label">الاسم بالكامل</label>
              <div className="input-container">
                <input
                  type="text"
                  className="input-text"
                  placeholder="أدخل اسمك الحقيقي بالكامل"
                  value={fullName}
                  onChange={e => setFullName(e.target.value)}
                  style={{
                    borderColor: fullName 
                      ? (isFullNameValid(fullName) ? 'rgba(16, 185, 129, 0.4)' : 'rgba(239, 68, 68, 0.4)') 
                      : 'rgba(255, 255, 255, 0.15)'
                  }}
                  required
                />
                <span className="icon input-icon-right">person</span>
              </div>
              {fullName && !isFullNameValid(fullName) && (
                <p style={{ color: '#f87171', fontSize: '10px', marginTop: '4px', paddingRight: '4px' }}>
                  ⚠️ يرجى إدخال اسمك ثلاثياً باللغة العربية على الأقل.
                </p>
              )}
            </div>

            <div className="form-group">
              <label className="form-label">رقم الهاتف (الموبايل)</label>
              <div className="input-container">
                <input
                  type="tel"
                  className="input-text"
                  placeholder="مثال: 01012345678"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  style={{
                    borderColor: phone 
                      ? (isPhoneValid(phone) ? 'rgba(16, 185, 129, 0.4)' : 'rgba(239, 68, 68, 0.4)') 
                      : 'rgba(255, 255, 255, 0.15)'
                  }}
                  required
                />
                <span className="icon input-icon-right">phone_iphone</span>
              </div>
              {phone && !isPhoneValid(phone) && (
                <p style={{ color: '#f87171', fontSize: '10px', marginTop: '4px', paddingRight: '4px' }}>
                  ⚠️ رقم المحمول غير صحيح (يجب أن يبدأ بـ 01 ويتكون من 11 رقماً).
                </p>
              )}
            </div>

            <div className="form-group">
              <label className="form-label">رقم هاتف ولي الأمر</label>
              <div className="input-container">
                <input
                  type="tel"
                  className="input-text"
                  placeholder="رقم ولي الأمر للطوارئ"
                  value={parentPhone}
                  onChange={e => setParentPhone(e.target.value)}
                  style={{
                    borderColor: parentPhone 
                      ? (isParentPhoneValid(parentPhone) ? 'rgba(16, 185, 129, 0.4)' : 'rgba(239, 68, 68, 0.4)') 
                      : 'rgba(255, 255, 255, 0.15)'
                  }}
                  required
                />
                <span className="icon input-icon-right">family_restroom</span>
              </div>
              {parentPhone && !isParentPhoneValid(parentPhone) && (
                <p style={{ color: '#f87171', fontSize: '10px', marginTop: '4px', paddingRight: '4px' }}>
                  ⚠️ يجب أن يكون رقماً مصرياً صحيحاً ومختلفاً عن رقم هاتفك الشخصي.
                </p>
              )}
            </div>

            <div className="form-group">
              <label className="form-label">كلمة المرور</label>
              <div className="input-container">
                <input
                  type="password"
                  className="input-text"
                  placeholder="أدخل كلمة مرور (6 رموز على الأقل)"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  style={{
                    borderColor: password 
                      ? (isPasswordValid(password) ? 'rgba(16, 185, 129, 0.4)' : 'rgba(239, 68, 68, 0.4)') 
                      : 'rgba(255, 255, 255, 0.15)'
                  }}
                  required
                />
                <span className="icon input-icon-right">lock</span>
              </div>
              {password && !isPasswordValid(password) && (
                <p style={{ color: '#f87171', fontSize: '10px', marginTop: '4px', paddingRight: '4px' }}>
                  ⚠️ يجب أن تتكون كلمة المرور من 6 خانات على الأقل.
                </p>
              )}
            </div>

            <div className="form-group">
              <label className="form-label">تأكيد كلمة المرور</label>
              <div className="input-container">
                <input
                  type="password"
                  className="input-text"
                  placeholder="أعد كتابة كلمة المرور"
                  value={confirmPassword}
                  onChange={e => setConfirmPassword(e.target.value)}
                  style={{
                    borderColor: confirmPassword 
                      ? (isConfirmPasswordValid(confirmPassword) ? 'rgba(16, 185, 129, 0.4)' : 'rgba(239, 68, 68, 0.4)') 
                      : 'rgba(255, 255, 255, 0.15)'
                  }}
                  required
                />
                <span className="icon input-icon-right">lock</span>
              </div>
              {confirmPassword && !isConfirmPasswordValid(confirmPassword) && (
                <p style={{ color: '#f87171', fontSize: '10px', marginTop: '4px', paddingRight: '4px' }}>
                  ⚠️ كلمات المرور غير متطابقة.
                </p>
              )}
            </div>

            <div className="grid-2 gap-md" style={{ marginBottom: '12px' }}>
              <div className="form-group">
                <label className="form-label">الصف الدراسي</label>
                <select
                  className="select"
                  value={selectedGrade}
                  onChange={e => {
                    setSelectedGrade(e.target.value);
                    const specs = getSpecializations(e.target.value);
                    setSelectedSpec(specs[0]);
                  }}
                >
                  {grades.map(g => <option key={g} value={g}>{g}</option>)}
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">التخصص</label>
                <select
                  className="select"
                  value={selectedSpec}
                  onChange={e => setSelectedSpec(e.target.value)}
                >
                  {getSpecializations(selectedGrade).map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
            </div>

            <div className="grid-2 gap-md" style={{ marginBottom: '24px' }}>
              <div className="form-group">
                <label className="form-label">النوع</label>
                <select
                  className="select"
                  value={selectedGender}
                  onChange={e => setSelectedGender(e.target.value)}
                >
                  <option value="ذكر">ذكر</option>
                  <option value="أنثى">أنثى</option>
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">المحافظة</label>
                <select
                  className="select"
                  value={selectedGov}
                  onChange={e => setSelectedGov(e.target.value)}
                >
                  {governorates.map(gov => <option key={gov} value={gov}>{gov}</option>)}
                </select>
              </div>
            </div>

            <button
              type="submit"
              className="btn btn-primary w-full"
              disabled={loading || !isFullNameValid(fullName) || !isPhoneValid(phone) || !isParentPhoneValid(parentPhone) || !isPasswordValid(password) || !isConfirmPasswordValid(confirmPassword)}
              style={{ marginBottom: '20px' }}
            >
              {loading ? 'جاري إنشاء الحساب...' : 'إنشاء حساب جديد'}
            </button>

            <p className="body-small text-center">
              تمتلك حساباً بالفعل؟{' '}
              <span
                onClick={() => setIsSignUp(false)}
                style={{ color: 'rgb(var(--primary))', fontWeight: 'bold', cursor: 'pointer' }}
              >
                تسجيل الدخول
              </span>
            </p>

            {onBrowseAsGuest && (
              <div style={{ marginTop: '20px', borderTop: '1px solid rgba(255,255,255,0.05)', paddingTop: '16px', display: 'flex', justifyContent: 'center' }}>
                <span
                  onClick={onBrowseAsGuest}
                  style={{ fontSize: '13px', color: 'rgb(var(--primary))', fontWeight: 'bold', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '4px' }}
                >
                  <span className="icon" style={{ fontSize: '18px' }}>explore</span>
                  تصفح المنصة كزائر
                </span>
              </div>
            )}
          </form>
        ) : (
          /* ── Login Form ── */
          <form onSubmit={handleLoginSubmit} className="flex flex-col">
            <h2 className="title-small text-center" style={{ marginBottom: '24px' }}>تسجيل الدخول للطالب</h2>

            <div className="form-group">
              <label className="form-label">رقم الهاتف أو البريد</label>
              <div className="input-container">
                <input
                  type="text"
                  className="input-text"
                  placeholder="أدخل رقم الموبايل أو بريدك الإلكتروني"
                  value={emailOrPhone}
                  onChange={e => setEmailOrPhone(e.target.value)}
                  required
                />
                <span className="icon input-icon-right">person</span>
              </div>
            </div>

            <div className="form-group" style={{ marginBottom: '8px' }}>
              <label className="form-label">كلمة المرور</label>
              <div className="input-container">
                <input
                  type="password"
                  className="input-text"
                  placeholder="أدخل كلمة المرور"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  required
                />
                <span className="icon input-icon-right">lock</span>
              </div>
            </div>

            <div className="flex justify-between items-center" style={{ marginBottom: '24px' }}>
              <span
                onClick={() => setIsForgotPassword(true)}
                style={{ fontSize: '12px', color: 'rgb(var(--on-surface-variant))', cursor: 'pointer' }}
              >
                نسيت كلمة المرور؟
              </span>
            </div>

            <button type="submit" className="btn btn-primary w-full" disabled={loading} style={{ marginBottom: '20px' }}>
              {loading ? 'جاري تسجيل الدخول...' : 'تسجيل الدخول'}
            </button>

            <p className="body-small text-center">
              ليس لديك حساب؟{' '}
              <span
                onClick={() => setIsSignUp(true)}
                style={{ color: 'rgb(var(--primary))', fontWeight: 'bold', cursor: 'pointer' }}
              >
                إنشاء حساب طالب
              </span>
            </p>

            {onBrowseAsGuest && (
              <div style={{ marginTop: '20px', borderTop: '1px solid rgba(255,255,255,0.05)', paddingTop: '16px', display: 'flex', justifyContent: 'center' }}>
                <span
                  onClick={onBrowseAsGuest}
                  style={{ fontSize: '13px', color: 'rgb(var(--primary))', fontWeight: 'bold', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '4px' }}
                >
                  <span className="icon" style={{ fontSize: '18px' }}>explore</span>
                  تصفح المنصة كزائر
                </span>
              </div>
            )}
          </form>
        )}
      </div>

      {/* ── Device Reset Request Modal ── */}
      {showDeviceResetDialog && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ padding: '24px', direction: 'rtl' }}>
            <div className="flex items-center gap-md" style={{ marginBottom: '16px' }}>
              <span className="icon" style={{ fontSize: '32px', color: 'rgb(var(--error))' }}>lock</span>
              <h3 className="title-small" style={{ margin: 0 }}>تجاوز حد الأجهزة المسموح بها</h3>
            </div>
            
            {deviceResetSuccess ? (
              <div className="flex flex-col items-center">
                <div className="badge badge-success w-full justify-center" style={{ padding: '12px', marginBottom: '20px' }}>
                  تم تقديم طلب إعادة تعيين الأجهزة بنجاح.
                </div>
                <p className="body-small text-center" style={{ marginBottom: '20px' }}>
                  طلبك قيد المراجعة حالياً من قِبل الأستاذ أو المساعدين. سيتم فك ارتباط الأجهزة السابقة قريباً لتتمكن من تشغيل حسابك من هذا المتصفح.
                </p>
                <button
                  className="btn btn-primary w-full"
                  onClick={() => {
                    setShowDeviceResetDialog(false);
                    setDeviceResetSuccess(false);
                    setDeviceResetReason('');
                  }}
                >
                  حسناً
                </button>
              </div>
            ) : (
              <form onSubmit={handleDeviceResetSubmit}>
                <p className="body-small" style={{ marginBottom: '16px', lineHeight: '1.6' }}>
                  لقد سجلت الدخول مسبقاً من عدد الأجهزة/المتصفحات المسموح به لحسابك. لفك ارتباط الأجهزة السابقة واستخدام حسابك على هذا المتصفح الجديد، يرجى كتابة سبب التغيير لتقديمه للإدارة:
                </p>

                <div className="form-group" style={{ marginBottom: '20px' }}>
                  <textarea
                    className="input-text"
                    style={{ height: '80px', paddingRight: '16px', resize: 'none' }}
                    placeholder="مثال: قمت بتغيير المتصفح الخاص بي / مسحت الكاش بالخطأ..."
                    value={deviceResetReason}
                    onChange={e => setDeviceResetReason(e.target.value)}
                    required
                  />
                </div>

                <div className="flex gap-md">
                  <button type="submit" className="btn btn-primary flex-1" disabled={resetLoading}>
                    {resetLoading ? 'جاري الإرسال...' : 'تقديم طلب التعيين'}
                  </button>
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={() => {
                      setShowDeviceResetDialog(false);
                      setDeviceResetReason('');
                    }}
                  >
                    إلغاء
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default LoginRegister;

