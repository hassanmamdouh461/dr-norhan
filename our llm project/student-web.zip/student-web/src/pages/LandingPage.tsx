import React, { useEffect, useState } from 'react';
import { ApiService } from '../services/api';
import { ChemicalParticles } from '../components/ChemicalParticles';
import teacherPortrait from '../assets/teacher_portrait-removebg-preview.png';

interface LandingPageProps {
  onShowAuth: () => void;
  onSelectCourse: (courseId: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onShowAuth, onSelectCourse }) => {
  const [courses, setCourses] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  useEffect(() => {
    const fetchCourses = async () => {
      setLoading(true);
      try {
        const res = await ApiService.getCourses(1);
        setCourses(res.courses || []);
      } catch (err) {
        console.error('Failed to load landing courses:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchCourses();
  }, []);

  const toggleFaq = (index: number) => {
    setActiveFaq(activeFaq === index ? null : index);
  };

  const faqData = [
    {
      q: 'كيف يمكنني الاشتراك وتفعيل الكورسات؟',
      a: 'يمكنك إنشاء حساب مجاني أولاً، ثم شراء كود التفعيل من نقاط البيع المعتمدة أو الدفع أونلاين وتفعيله مباشرة من لوحة التحكم الخاصة بك.'
    },
    {
      q: 'هل يمكنني حضور الدروس من أكثر من جهاز؟',
      a: 'لحماية حسابك ومحتوى المنصة، يتم ربط حسابك بجهازك الأساسي الذي تسجل منه لأول مرة. يمكنك طلب إعادة تعيين الجهاز من الدعم الفني عند الضرورة.'
    },
    {
      q: 'هل الشرح يغطي جميع أجزاء منهج الثانوية العامة؟',
      a: 'نعم، المنصة تغطي المنهج كاملاً بالتفصيل، مع مراجعات شاملة بعد كل باب وحل آلاف الأسئلة والامتحانات الوزارية السابقة.'
    },
    {
      q: 'كيف يمكنني التواصل مع المعلم لطرح الأسئلة الصعبة؟',
      a: 'توفر المنصة قسماً مخصصاً للأسئلة والأجوبة (سؤال وجواب) يمكنك من خلاله كتابة سؤالك وسيقوم فريق الدعم الأكاديمي بالإجابة عليك بالتفصيل خلال ساعات.'
    }
  ];

  return (
    <div className="landing-container" style={{ direction: 'rtl', minHeight: '100vh', backgroundColor: '#050507', color: '#f5f5f8' }}>
      
      {/* ── Top Header Navigation ── */}
      <header style={{
        padding: '20px 40px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        background: 'rgba(5, 5, 7, 0.75)',
        backdropFilter: 'blur(12px)',
        position: 'sticky',
        top: 0,
        zIndex: 100,
        borderBottom: '1px solid rgba(255, 255, 255, 0.05)'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <span style={{ fontSize: '24px', fontWeight: '900', color: 'rgb(var(--primary))', letterSpacing: '1px', fontFamily: 'Cairo, sans-serif' }}>
            الهضبة
          </span>
          <span className="badge" style={{ backgroundColor: 'rgba(var(--primary), 0.15)', color: 'rgb(220, 38, 38)', border: '1px solid rgba(var(--primary), 0.25)', fontSize: '10px', padding: '2px 8px', borderRadius: '6px' }}>
            الكيمياء
          </span>
        </div>
        
        <div style={{ display: 'flex', gap: '12px' }}>
          <button 
            onClick={onShowAuth}
            className="btn btn-secondary"
            style={{ padding: '8px 20px', borderRadius: '10px', fontSize: '13px', fontWeight: '700' }}
          >
            تسجيل الدخول
          </button>
          <button 
            onClick={onShowAuth}
            className="btn btn-primary"
            style={{ padding: '8px 24px', borderRadius: '10px', fontSize: '13px', fontWeight: '700', backgroundColor: 'rgb(var(--primary))', border: 'none', boxShadow: '0 4px 15px rgba(var(--primary), 0.3)' }}
          >
            انضم الآن مجاناً
          </button>
        </div>
      </header>

      {/* ── Section 1: Cinematic Hero Section ── */}
      <section className="layout-container" style={{ padding: '40px 16px 80px 16px' }}>
        <div className="hero-cinematic animate-fade-in-up">
          {/* Particles Canvas in Background */}
          <div className="hero-particles-wrapper">
            <ChemicalParticles />
          </div>

          {/* Right Column: Copy & CTAs */}
          <div className="hero-content-right">
            <div>
              <span style={{ 
                fontSize: '12px', 
                color: 'rgb(220, 38, 38)', 
                fontWeight: '800', 
                marginBottom: '12px', 
                display: 'flex', 
                alignItems: 'center', 
                gap: '8px', 
                textTransform: 'uppercase', 
                letterSpacing: '0.5px' 
              }}>
                <span className="material-symbols-outlined" style={{ fontSize: '16px' }}>workspace_premium</span>
                منصة الكيمياء الأولى للثانوية العامة 🧪
              </span>
              
              <h1 style={{ 
                fontSize: 'clamp(2rem, 5vw, 3.2rem)', 
                fontWeight: '900', 
                color: '#fff', 
                lineHeight: '1.25', 
                marginBottom: '16px',
                fontFamily: 'Cairo, sans-serif'
              }}>
                اتقن الكيمياء.<br />
                تفوّق في امتحانك النهائي.
              </h1>
              
              <p style={{ 
                fontSize: '15px', 
                color: '#94a3b8', 
                lineHeight: '1.8', 
                maxWidth: '560px',
                margin: '0 0 8px 0'
              }}>
                انضم لرحلة الشرح التفاعلي المتكامل لمنهج الكيمياء مع الأستاذ. شروحات مبسطة بأعلى جودة، تدريبات مستمرة، ومتابعة دقيقة لكل فكرة تضمن لك الدرجة النهائية.
              </p>
            </div>

            <div className="flex gap-md" style={{ flexWrap: 'wrap', zIndex: 5 }}>
              <button 
                onClick={onShowAuth}
                className="btn btn-primary animate-glow-pulse"
                style={{ 
                  fontSize: '14px', 
                  padding: '14px 32px', 
                  borderRadius: '12px', 
                  border: 'none', 
                  fontWeight: 'bold', 
                  backgroundColor: 'rgb(var(--primary))', 
                  color: '#fff', 
                  cursor: 'pointer',
                  boxShadow: '0 4px 20px rgba(var(--primary), 0.45)'
                }}
              >
                ابدأ رحلة تفوقك مجاناً
              </button>
              
              <a 
                href="#courses"
                className="btn btn-secondary"
                style={{ 
                  fontSize: '14px', 
                  padding: '14px 24px', 
                  borderRadius: '12px', 
                  fontWeight: 'bold',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '8px',
                  background: 'rgba(255,255,255,0.05)',
                  border: '1px solid rgba(255,255,255,0.1)'
                }}
              >
                تصفح المقررات الدراسية
              </a>
            </div>

            {/* Stats Bar Glass */}
            <div className="stats-bar-glass">
              <div className="stat-item-glass">
                <div className="stat-val-glass">12K+</div>
                <div className="stat-lbl-glass">طالب مسجل</div>
              </div>
              <div className="stat-item-glass">
                <div className="stat-val-glass">98%</div>
                <div className="stat-lbl-glass">نسبة النجاح</div>
              </div>
              <div className="stat-item-glass">
                <div className="stat-val-glass">4.9/5</div>
                <div className="stat-lbl-glass">تقييم الطلاب</div>
              </div>
            </div>
          </div>

          {/* Left Column: Teacher Portrait with Glowing Mask */}
          <div className="hero-image-left">
            <img 
              src={teacherPortrait} 
              alt="الأستاذ"
            />
            {/* Back Glowing Aura */}
            <div className="teacher-glowing-backdrop" />
          </div>
        </div>
      </section>

      {/* ── Section 2: Features ── */}
      <section className="landing-section" style={{ backgroundColor: '#07070a', borderTop: '1px solid rgba(255, 255, 255, 0.02)' }}>
        <div className="layout-container">
          <div className="landing-section-title">
            <h2>لماذا يفضل الطلاب منصة الهضبة؟</h2>
            <p>منظومة تعليمية متكاملة مصممة خصيصاً لمساعدتك على إتقان الكيمياء دون حفظ أعمى.</p>
          </div>

          <div className="grid grid-3 gap-lg">
            <div className="card surface-glass" style={{ padding: '32px', borderRadius: '20px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div style={{ width: '48px', height: '48px', borderRadius: '12px', background: 'rgba(var(--primary), 0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <span className="material-symbols-outlined" style={{ color: 'rgb(220, 38, 38)', fontSize: '24px' }}>science</span>
              </div>
              <h3 style={{ fontSize: '18px', fontWeight: '800' }}>شرح تفاعلي مبسط</h3>
              <p style={{ color: '#94a3b8', fontSize: '13.5px', lineHeight: '1.7', margin: 0 }}>
                فيديوهات شرح تفصيلية بتقنية عالية، تستخدم الجداول والرسومات التوضيحية لتفكيك الأفكار الصعبة لأجزاء سهلة الاستيعاب.
              </p>
            </div>

            <div className="card surface-glass" style={{ padding: '32px', borderRadius: '20px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div style={{ width: '48px', height: '48px', borderRadius: '12px', background: 'rgba(16, 185, 129, 0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <span className="material-symbols-outlined" style={{ color: '#10b981', fontSize: '24px' }}>edit_document</span>
              </div>
              <h3 style={{ fontSize: '18px', fontWeight: '800' }}>امتحانات وواجبات دورية</h3>
              <p style={{ color: '#94a3b8', fontSize: '13.5px', lineHeight: '1.7', margin: 0 }}>
                واجب بعد كل درس وامتحان شامل لكل وحدة، مع تصحيح تلقائي فوري يوضح لك مواطن القوة والضعف في أدائك.
              </p>
            </div>

            <div className="card surface-glass" style={{ padding: '32px', borderRadius: '20px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div style={{ width: '48px', height: '48px', borderRadius: '12px', background: 'rgba(255, 210, 63, 0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <span className="material-symbols-outlined" style={{ color: '#ffd23f', fontSize: '24px' }}>forum</span>
              </div>
              <h3 style={{ fontSize: '18px', fontWeight: '800' }}>دعم أكاديمي متواصل</h3>
              <p style={{ color: '#94a3b8', fontSize: '13.5px', lineHeight: '1.7', margin: 0 }}>
                منتدى داخلي لطرح الأسئلة ومناقشة الأفكار. فريق من المعيدين المتخصصين يجيب على أسئلتك لتظل دائماً على المسار الصحيح.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ── Section 3: Dynamic Courses Preview ── */}
      <section id="courses" className="landing-section" style={{ backgroundColor: '#050507' }}>
        <div className="layout-container">
          <div className="landing-section-title">
            <h2>المقررات الدراسية المتاحة</h2>
            <p>تصفح الكورسات الخاصة بكل المراحل الدراسية للثانوية العامة.</p>
          </div>

          {loading ? (
            <div style={{ display: 'flex', justifyContent: 'center', padding: '40px 0' }}>
              <div className="spinner" style={{ width: '40px', height: '40px', border: '4px solid rgba(255,255,255,0.05)', borderTopColor: 'rgb(var(--primary))', borderRadius: '50%', animation: 'spin 1s linear infinite' }}></div>
            </div>
          ) : courses.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '40px', color: '#94a3b8' }}>لا توجد مقررات دراسية منشورة حالياً.</div>
          ) : (
            <div className="grid grid-3 gap-lg">
              {courses.map((course: any) => (
                <div 
                  key={course.id} 
                  className="card surface-glass"
                  style={{ 
                    borderRadius: '20px', 
                    overflow: 'hidden', 
                    padding: 0, 
                    display: 'flex', 
                    flexDirection: 'column',
                    transition: 'transform 0.3s'
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-6px)'}
                  onMouseLeave={(e) => e.currentTarget.style.transform = 'none'}
                >
                  <div style={{ width: '100%', height: '180px', position: 'relative', overflow: 'hidden' }}>
                    <div style={{ 
                      position: 'absolute', 
                      top: '12px', 
                      right: '12px', 
                      backgroundColor: 'rgba(5, 5, 7, 0.75)', 
                      padding: '4px 10px', 
                      borderRadius: '8px', 
                      fontSize: '11px', 
                      fontWeight: '700',
                      border: '1px solid rgba(255,255,255,0.1)',
                      zIndex: 10
                    }}>
                      {course.grade}
                    </div>
                    {course.thumbnail_url ? (
                      <img src={course.thumbnail_url} alt={course.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    ) : (
                      <div style={{ width: '100%', height: '100%', background: 'linear-gradient(135deg, rgba(var(--primary), 0.3) 0%, rgba(5, 5, 7, 0.9) 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <span className="material-symbols-outlined" style={{ fontSize: '48px', color: 'rgba(255,255,255,0.15)' }}>school</span>
                      </div>
                    )}
                  </div>
                  
                  <div style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '14px', flex: 1, justifyContent: 'space-between' }}>
                    <div>
                      <h3 style={{ fontSize: '18px', fontWeight: '800', marginBottom: '8px' }}>{course.title}</h3>
                      <p style={{ color: '#94a3b8', fontSize: '13px', lineHeight: '1.6', margin: 0, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                        {course.description || 'لا يوجد وصف متاح للمقرر حالياً.'}
                      </p>
                    </div>

                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '10px' }}>
                      <span style={{ fontSize: '16px', fontWeight: '800', color: 'rgb(220, 38, 38)' }}>
                        {course.price_egp > 0 ? `${course.price_egp} ج.م` : 'مجاني'}
                      </span>
                      <button 
                        onClick={() => onSelectCourse(course.id)}
                        className="btn btn-primary"
                        style={{ fontSize: '12px', padding: '8px 16px', borderRadius: '8px', border: 'none', backgroundColor: 'rgb(var(--primary))', color: '#fff', fontWeight: '700' }}
                      >
                        عرض التفاصيل
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* ── Section 4: Testimonials ── */}
      <section className="landing-section" style={{ backgroundColor: '#07070a', borderTop: '1px solid rgba(255, 255, 255, 0.02)' }}>
        <div className="layout-container">
          <div className="landing-section-title">
            <h2>آراء وقصص نجاح طلابنا</h2>
            <p>طلاب العام الماضي يشاركون تجربتهم مع المنصة وكيف وصلوا للدرجات النهائية.</p>
          </div>

          <div className="grid grid-3 gap-lg">
            <div className="card surface-glass" style={{ padding: '28px', borderRadius: '20px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between', minHeight: '220px' }}>
              <p style={{ color: '#cbd5e1', fontSize: '13.5px', lineHeight: '1.7', fontStyle: 'italic', margin: 0 }}>
                "الكيمياء بالنسبة لي كانت عقدة حقيقية. بس مع الأستاذ وطريقته المنظمة في شرح الباب الثالث والتحليلية، فهمت كل القواعد الصعبة والحمد لله قفلت المادة في الامتحان."
              </p>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginTop: '20px' }}>
                <div style={{ width: '40px', height: '40px', borderRadius: '50%', backgroundColor: 'rgb(var(--primary))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '16px', fontWeight: '800' }}>م</div>
                <div>
                  <h4 style={{ fontSize: '14px', fontWeight: '800', margin: 0 }}>محمد أحمد</h4>
                  <span style={{ fontSize: '11px', color: '#94a3b8' }}>طالب 3 ثانوي — مجموع 96%</span>
                </div>
              </div>
            </div>

            <div className="card surface-glass" style={{ padding: '28px', borderRadius: '20px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between', minHeight: '220px' }}>
              <p style={{ color: '#cbd5e1', fontSize: '13.5px', lineHeight: '1.7', fontStyle: 'italic', margin: 0 }}>
                "الواجبات بعد كل درس والامتحان الأسبوعي كان ليهم فضل كبير جداً. تصحيح الواجب التلقائي بيخليني أعرف غلطي فوراً ومكررهوش تاني في الامتحانات الشاملة."
              </p>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginTop: '20px' }}>
                <div style={{ width: '40px', height: '40px', borderRadius: '50%', backgroundColor: 'rgb(var(--primary))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '16px', fontWeight: '800' }}>س</div>
                <div>
                  <h4 style={{ fontSize: '14px', fontWeight: '800', margin: 0 }}>سارة كريم</h4>
                  <span style={{ fontSize: '11px', color: '#94a3b8' }}>طالبة 3 ثانوي — الدرجة النهائية في الكيمياء</span>
                </div>
              </div>
            </div>

            <div className="card surface-glass" style={{ padding: '28px', borderRadius: '20px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between', minHeight: '220px' }}>
              <p style={{ color: '#cbd5e1', fontSize: '13.5px', lineHeight: '1.7', fontStyle: 'italic', margin: 0 }}>
                "أكتر حاجة متميزة في المنصة هي قسم سؤال وجواب. لما بيقف قدامي أي سؤال في الواجب أو الامتحانات الخارجية، بصوره وأرفعه وبيردوا عليا فوراً بالإجابة بالخطوات والشرح."
              </p>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginTop: '20px' }}>
                <div style={{ width: '40px', height: '40px', borderRadius: '50%', backgroundColor: '#1e293b', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '16px', fontWeight: '800' }}>ع</div>
                <div>
                  <h4 style={{ fontSize: '14px', fontWeight: '800', margin: 0 }}>علي محمود</h4>
                  <span style={{ fontSize: '11px', color: '#94a3b8' }}>طالب 3 ثانوي — مجموع 93.5%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Section 5: FAQ Accordion ── */}
      <section className="landing-section" style={{ backgroundColor: '#050507' }}>
        <div className="layout-container" style={{ maxWidth: '800px' }}>
          <div className="landing-section-title">
            <h2>الأسئلة الشائعة</h2>
            <p>إجابات سريعة على الاستفسارات التي تدور في ذهنك.</p>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {faqData.map((faq, idx) => (
              <div 
                key={idx} 
                className="card surface-glass" 
                style={{ 
                  padding: '20px', 
                  borderRadius: '12px', 
                  cursor: 'pointer',
                  border: activeFaq === idx ? '1px solid rgba(var(--primary), 0.3)' : '1px solid rgba(255,255,255,0.05)',
                  transition: 'border-color 0.3s'
                }}
                onClick={() => toggleFaq(idx)}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <h3 style={{ fontSize: '15px', fontWeight: '700', margin: 0, display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <span className="material-symbols-outlined" style={{ fontSize: '18px', color: 'rgb(var(--primary))' }}>help_outline</span>
                    {faq.q}
                  </h3>
                  <span className="material-symbols-outlined" style={{ fontSize: '18px', transition: 'transform 0.3s', transform: activeFaq === idx ? 'rotate(180deg)' : 'none' }}>
                    keyboard_arrow_down
                  </span>
                </div>
                {activeFaq === idx && (
                  <div style={{ marginTop: '16px', color: '#cbd5e1', fontSize: '13.5px', lineHeight: '1.7', borderTop: '1px solid rgba(255,255,255,0.05)', paddingTop: '16px' }}>
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Section 6: Final CTA ── */}
      <section className="landing-section" style={{ background: 'linear-gradient(180deg, #050507 0%, rgba(var(--primary), 0.08) 100%)', borderTop: '1px solid rgba(255, 255, 255, 0.02)' }}>
        <div className="layout-container" style={{ textAlign: 'center', maxWidth: '700px' }}>
          <h2 style={{ fontSize: '2rem', fontWeight: '800', marginBottom: '16px', fontFamily: 'Cairo, sans-serif' }}>ابدأ رحلتك للتفوق الأكاديمي اليوم!</h2>
          <p style={{ color: '#cbd5e1', fontSize: '15px', lineHeight: '1.8', marginBottom: '32px' }}>
            سجّل حساباً مجاناً الآن وابدأ بمشاهدة الدروس التجريبية المفتوحة مجاناً. لا تدع الكيمياء تقف عقبة أمام حلمك.
          </p>
          <button 
            onClick={onShowAuth}
            className="btn btn-primary animate-glow-pulse"
            style={{ 
              fontSize: '15px', 
              padding: '16px 48px', 
              borderRadius: '12px', 
              border: 'none', 
              fontWeight: 'bold', 
              backgroundColor: 'rgb(var(--primary))', 
              color: '#fff', 
              cursor: 'pointer',
              boxShadow: '0 4px 20px rgba(var(--primary), 0.4)'
            }}
          >
            سجّل حسابك مجاناً الآن
          </button>
        </div>
      </section>

      {/* ── Footer ── */}
      <footer style={{ 
        backgroundColor: '#030304', 
        borderTop: '1px solid rgba(255, 255, 255, 0.05)', 
        padding: '40px 20px', 
        textAlign: 'center',
        fontSize: '13px',
        color: '#94a3b8'
      }}>
        <div className="layout-container">
          <p style={{ margin: 0 }}>© {new Date().getFullYear()} منصة الهضبة لتعليم الكيمياء للثانوية العامة. جميع الحقوق محفوظة.</p>
          <p style={{ marginTop: '8px', fontSize: '11px', color: '#64748b' }}>تم التطوير بواسطة Synaptic Studio</p>
        </div>
      </footer>

    </div>
  );
};

