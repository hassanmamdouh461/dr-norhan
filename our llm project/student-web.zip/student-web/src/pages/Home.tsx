import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { ApiService } from '../services/api';
import { useTheme } from '../context/ThemeContext';
import teacherHero from '../assets/teacher_hero.png';
import teacherPortrait1 from '../assets/teacher_portrait_1.png';
import teacherPortrait2 from '../assets/teacher_portrait_2.png';
import teacherPortrait3 from '../assets/teacher_portrait_3.png';
import teacherPortrait4 from '../assets/teacher_portrait_4.png';


const governorates = [
  'القاهرة', 'الجيزة', 'الإسكندرية', 'القليوبية', 'الدقهلية',
  'الشرقية', 'المنوفية', 'الغربية', 'البحيرة', 'دمياط',
  'كفر الشيخ', 'الفيوم', 'بني سويف', 'المنيا',
  'أسيوط', 'سوهاج', 'قنا', 'الأقصر', 'أسوان', 'البحر الأحمر',
  'الوادي الجديد', 'مطروح', 'شمال سيناء', 'جنوب سيناء', 'السويس', 'الإسماعيلية', 'بورسعيد'
];

const grades = [
  'الصف الأول الثانوي',
  'الصف الثاني الثانوي',
  'الصف الثالث الثانوي',
];

interface HomeProps {
  onSelectCourse: (courseId: string) => void;
  onSelectLesson?: (lessonId: string, title: string, type: 'video' | 'pdf', isFree?: boolean, courseId?: string) => void;
  onShowAuth?: () => void;
}

let cachedHomeData: {
  courses: any[] | null;
  myCourses: any[] | null;
  questions: any[] | null;
  financials: any[] | null;
  devices: any[] | null;
  quizzes: any[] | null;
  playbackLogs: any[] | null;
  resetRequests: any[] | null;
  exams: any[] | null;
  stats: any | null;
  enrolledCoursesDetails: any[] | null;
} = {
  courses: null,
  myCourses: null,
  questions: null,
  financials: null,
  devices: null,
  quizzes: null,
  playbackLogs: null,
  resetRequests: null,
  exams: null,
  stats: null,
  enrolledCoursesDetails: null,
};

export const Home: React.FC<HomeProps> = ({ onSelectCourse, onShowAuth, onSelectLesson }) => {
  const { profile, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();

  const [activeTab, setActiveTab] = useState<'home' | 'explore' | 'my-courses' | 'qa' | 'profile' | 'exams'>('home');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);



  const [courses, setCourses] = useState<any[]>(cachedHomeData.courses || []);
  const [myCourses, setMyCourses] = useState<any[]>(cachedHomeData.myCourses || []);
  const [questions, setQuestions] = useState<any[]>(cachedHomeData.questions || []);
  const [qaSearch, setQaSearch] = useState('');
  const [qaFilter, setQaFilter] = useState<'all' | 'answered' | 'pending'>('all');
  const [upvotedQuestions, setUpvotedQuestions] = useState<Set<string>>(new Set());
  const [financials, setFinancials] = useState<any[]>(cachedHomeData.financials || []);
  const [devices, setDevices] = useState<any[]>(cachedHomeData.devices || []);
  const [quizzes, setQuizzes] = useState<any[]>(cachedHomeData.quizzes || []);
  const [playbackLogs, setPlaybackLogs] = useState<any[]>(cachedHomeData.playbackLogs || []);
  const [resetRequests, setResetRequests] = useState<any[]>(cachedHomeData.resetRequests || []);
  const [enrolledCoursesDetails, setEnrolledCoursesDetails] = useState<any[]>(cachedHomeData.enrolledCoursesDetails || []);

  // Standalone Exams State
  const [exams, setExams] = useState<any[]>(cachedHomeData.exams || []);
  const [selectedExam, setSelectedExam] = useState<any | null>(null);
  const [examQuestions, setExamQuestions] = useState<any[]>([]);
  const [examAttempt, setExamAttempt] = useState<any | null>(null);
  const [examAnswers, setExamAnswers] = useState<Record<string, string>>({});
  const [showExamModal, setShowExamModal] = useState(false);
  const [submittingExam, setSubmittingExam] = useState(false);
  const [examTimeLeft, setExamTimeLeft] = useState<number | null>(null);

  const hooks = [
    'تبسطلك الكيمياء 🔬',
    'تضمنلك الدرجة النهائية 🏆',
    'تتابع مستواك خطوة بخطوة 📈',
    'تأمّن طريقك للنجاح 🚀'
  ];
  const [currentHookIdx, setCurrentHookIdx] = useState(0);
  const [hookFade, setHookFade] = useState(true);

  const [teacherPoseIdx, setTeacherPoseIdx] = useState(0);
  const teacherImages = [
    teacherPortrait1,
    teacherPortrait2,
    teacherPortrait3,
    teacherPortrait4
  ];



  // Platform Benefits Stacked Notes State & Data
  const [cardOrder, setCardOrder] = useState<number[]>([0, 1, 2, 3, 4]);
  const [flyingCardId, setFlyingCardId] = useState<number | null>(null);

  const platformNotes = [
    {
      id: 0,
      type: 'yellow',
      icon: 'menu_book',
      title: 'محاضرات تفاعلية',
      desc: 'شرح كيميائي شامل ومبسط يربط المفاهيم.',
    },
    {
      id: 1,
      type: 'green',
      icon: 'quiz',
      title: 'امتحانات فورية',
      desc: 'اختبارات قياس مستوى بعد كل محاضرة.',
    },
    {
      id: 2,
      type: 'cyan',
      icon: 'forum',
      title: 'تواصل مباشر',
      desc: 'طرح الأسئلة وتلقي إجابات سريعة ومباشرة.',
    },
    {
      id: 3,
      type: 'purple',
      icon: 'schema',
      title: 'خرائط ذهنية',
      desc: 'كتيبات ملخصة بصرياً لسرعة التذكر والمراجعة.',
    },
    {
      id: 4,
      type: 'rose',
      icon: 'analytics',
      title: 'متابعة مستمرة',
      desc: 'تقارير دورية لولي الأمر لمتابعة الدرجات.',
    },
  ];

  const handleCardClick = (cardId: number) => {
    // Only the top card can be clicked, and only when no transition is flying
    if (cardOrder[0] !== cardId || flyingCardId !== null) return;

    setFlyingCardId(cardId);
    setTimeout(() => {
      setCardOrder(prev => [...prev.slice(1), prev[0]]);
      setFlyingCardId(null);
    }, 400); // matches transition time
  };

  const handleScrollToCourses = () => {
    const coursesSection = document.querySelector('.title-small');
    if (coursesSection) {
      coursesSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };



  useEffect(() => {
    const timer = setInterval(() => {
      setHookFade(false);
      setTimeout(() => {
        setCurrentHookIdx((prev) => (prev + 1) % hooks.length);
        setHookFade(true);
      }, 300);
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  // Automatically switch teacher poses every 4 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setTeacherPoseIdx((prev) => (prev + 1) % 4);
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  // Filters & State
  const [loading, setLoading] = useState(false);
  const [gradeFilter, setGradeFilter] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Q&A modals
  const [showAskModal, setShowAskModal] = useState(false);
  const [questionBody, setQuestionBody] = useState('');
  const [selectedQuestion, setSelectedQuestion] = useState<any | null>(null);
  
  // Redeem Code state
  const [redeemCode, setRedeemCode] = useState('');
  const [showRedeemModal, setShowRedeemModal] = useState(false);
  const [redeeming, setRedeeming] = useState(false);
  const [selectedCourseForRedeem, setSelectedCourseForRedeem] = useState<any | null>(null);

  // Profile Edit State
  const [editName, setEditName] = useState(profile?.full_name || '');
  const [editPhone, setEditPhone] = useState(profile?.phone || '');
  const [editParentPhone, setEditParentPhone] = useState(profile?.parent_phone || '');
  const [editGov, setEditGov] = useState(profile?.governorate || '');
  const [editGrade, setEditGrade] = useState(profile?.grade || 'الصف الأول الثانوي');
  const [updatingProfile, setUpdatingProfile] = useState(false);

  // Profile Avatar State
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [isUploadingAvatar, setIsUploadingAvatar] = useState(false);

  // Notifications State
  const [notifications, setNotifications] = useState<any[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [showNotificationsModal, setShowNotificationsModal] = useState(false);

  const fetchNotificationsList = async () => {
    if (!profile) return;
    try {
      const res = await ApiService.getNotifications();
      const list = res.notifications || [];
      setNotifications(list);
      setUnreadCount(list.filter((n: any) => n.is_read === 0).length);
    } catch (err) {
      console.error('Failed to fetch notifications:', err);
    }
  };

  const markNotificationAsRead = async (id: string) => {
    try {
      await ApiService.markNotificationRead(id);
      setNotifications(prev => prev.map(n => n.id === id ? { ...n, is_read: 1 } : n));
      setUnreadCount(prev => Math.max(0, prev - 1));
    } catch (err) {
      console.error('Failed to mark notification as read:', err);
    }
  };

  useEffect(() => {
    if (profile) {
      setEditName(profile.full_name || '');
      setEditPhone(profile.phone || '');
      setEditParentPhone(profile.parent_phone || '');
      setEditGov(profile.governorate || '');
      setEditGrade(profile.grade || 'الصف الأول الثانوي');
      
      const cached = localStorage.getItem(`student_avatar_${profile.id}`) || profile.avatar_url;
      setAvatarUrl(cached || null);
    } else {
      setAvatarUrl(null);
    }
  }, [profile]);

  useEffect(() => {
    if (!profile) return;
    fetchNotificationsList();
    const interval = setInterval(() => {
      fetchNotificationsList();
    }, 40000);
    return () => clearInterval(interval);
  }, [profile]);

  const [stats, setStats] = useState(cachedHomeData.stats || {
    coursesCount: 0,
    quizzesCount: 0,
    questionsCount: 0,
  });

  const loadData = async () => {
    const hasCache = !!cachedHomeData.courses;
    if (!hasCache) {
      setLoading(true);
    }
    try {
      // Load public courses
      const coursesRes = await ApiService.getCourses(1, gradeFilter || undefined);
      const coursesList = coursesRes.courses || [];
      setCourses(coursesList);
      cachedHomeData.courses = coursesList;

      // Load protected stats & lists only if logged in
      if (profile) {
        const myCoursesRes = await ApiService.getMyCourses();
        const myCoursesList = myCoursesRes.courses || [];
        setMyCourses(myCoursesList);
        cachedHomeData.myCourses = myCoursesList;

        const allEnrolledIds = Array.from(new Set([
          ...myCoursesList.map((c: any) => c.id),
          ...coursesList.filter((c: any) => c.is_free).map((c: any) => c.id)
        ]));

        try {
          const detailsPromises = allEnrolledIds.map((id: any) => ApiService.getCourseDetails(id).catch(() => null));
          const detailsResults = await Promise.all(detailsPromises);
          const validDetails = detailsResults.filter(Boolean).map((res: any) => res.course);
          setEnrolledCoursesDetails(validDetails);
          cachedHomeData.enrolledCoursesDetails = validDetails;
        } catch (err) {
          console.error("Error loading enrolled courses details for progress tracker:", err);
        }

        const questionsRes = await ApiService.getQuestions();
        const questionsList = questionsRes.questions || [];
        setQuestions(questionsList);
        cachedHomeData.questions = questionsList;

        const finRes = await ApiService.getMyFinancials();
        const financialsList = finRes.financials || [];
        setFinancials(financialsList);
        cachedHomeData.financials = financialsList;

        const devRes = await ApiService.getMyDevices();
        const devicesList = devRes.devices || [];
        setDevices(devicesList);
        cachedHomeData.devices = devicesList;

        const quizRes = await ApiService.getMyQuizAttempts();
        const quizzesList = quizRes.quiz_attempts || [];
        setQuizzes(quizzesList);
        cachedHomeData.quizzes = quizzesList;

        const logsRes = await ApiService.getMyPlaybackLogs();
        const playbackLogsList = logsRes.playback_logs || [];
        setPlaybackLogs(playbackLogsList);
        cachedHomeData.playbackLogs = playbackLogsList;

        const resetRes = await ApiService.getMyDeviceResetRequests();
        const resetRequestsList = resetRes.reset_requests || [];
        setResetRequests(resetRequestsList);
        cachedHomeData.resetRequests = resetRequestsList;

        const examsRes = await ApiService.getExams();
        const examsList = examsRes.exams || [];
        setExams(examsList);
        cachedHomeData.exams = examsList;

        await fetchNotificationsList();

        const currentStats = {
          coursesCount: myCoursesList.length,
          quizzesCount: quizzesList.length,
          questionsCount: questionsList.length,
        };
        setStats(currentStats);
        cachedHomeData.stats = currentStats;
      }
    } catch (err) {
      console.error('Error loading homepage data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [gradeFilter]);

  useEffect(() => {
    if (!selectedExam || !selectedExam.time_limit_mins || !examAttempt || examAttempt.is_submitted === 1) {
      setExamTimeLeft(null);
      return;
    }

    const startTime = new Date(examAttempt.started_at).getTime();
    const limitMs = selectedExam.time_limit_mins * 60 * 1000;

    const updateTimer = () => {
      const elapsed = Date.now() - startTime;
      const remaining = Math.max(0, Math.floor((limitMs - elapsed) / 1000));
      setExamTimeLeft(remaining);

      if (remaining <= 0) {
        clearInterval(timerId);
        handleSubmitExam();
      }
    };

    updateTimer();
    const timerId = setInterval(updateTimer, 1000);

    return () => clearInterval(timerId);
  }, [selectedExam, examAttempt, examAnswers]);

  const formatTimeLeft = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const handleRedeemSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!redeemCode.trim()) return;
    setRedeeming(true);
    try {
      const res = await ApiService.redeemCode(redeemCode.trim());
      alert(res.message || 'تم تفعيل الكورس بنجاح!');
      setShowRedeemModal(false);
      setRedeemCode('');
      loadData();
    } catch (err: any) {
      alert(err.message || 'فشل تفعيل الكود، يرجى المحاولة لاحقاً');
    } finally {
      setRedeeming(false);
    }
  };

  const handleUnbindDevice = async (id: string) => {
    if (!confirm('هل أنت متأكد من رغبتك في حذف هذا الجهاز؟')) return;
    try {
      await ApiService.deleteDevice(id);
      alert('تم حذف الجهاز بنجاح.');
      loadData();
    } catch (err: any) {
      alert(err.message || 'فشل حذف الجهاز');
    }
  };

  const handleAskQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!questionBody.trim() || questionBody.trim().length < 5) {
      alert('يرجى كتابة سؤال صحيح (5 أحرف على الأقل)');
      return;
    }
    try {
      await ApiService.askQuestion({
        body: questionBody.trim(),
      });
      alert('تم إرسال سؤالك بنجاح.');
      setQuestionBody('');
      setShowAskModal(false);
      loadData();
    } catch (err: any) {
      alert(err.message || 'تعذر إرسال السؤال');
    }
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setUpdatingProfile(true);
    try {
      await ApiService.updateProfile({
        full_name: editName,
        phone: editPhone,
        parent_phone: editParentPhone,
        grade: editGrade,
        governorate: editGov,
      });
      alert('تم تحديث الملف الشخصي بنجاح');
      loadData();
    } catch (err: any) {
      alert(err.message || 'فشل تحديث الملف الشخصي');
    } finally {
      setUpdatingProfile(false);
    }
  };

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // 1. Show immediate local preview
    const reader = new FileReader();
    reader.onloadend = () => {
      setAvatarUrl(reader.result as string);
      if (profile) {
        localStorage.setItem(`student_avatar_${profile.id}`, reader.result as string);
      }
    };
    reader.readAsDataURL(file);

    // 2. Try uploading to backend
    setIsUploadingAvatar(true);
    try {
      const res = await ApiService.uploadAvatar(file);
      if (res && res.avatar_url) {
        setAvatarUrl(res.avatar_url);
        if (profile) {
          localStorage.setItem(`student_avatar_${profile.id}`, res.avatar_url);
        }
      }
    } catch (err) {
      console.warn("Backend avatar upload fell back to local storage:", err);
    } finally {
      setIsUploadingAvatar(false);
    }
  };

  const handleOpenExam = async (examId: string) => {
    setLoading(true);
    try {
      const res = await ApiService.getExamDetails(examId);
      setSelectedExam(res.exam);
      setExamQuestions(res.questions || []);
      setExamAttempt(res.attempt || null);
      setExamAnswers(res.attempt?.answers || {});
      setShowExamModal(true);
    } catch (err: any) {
      alert(err.message || 'فشل تحميل تفاصيل الامتحان');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitExam = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!selectedExam) return;
    setSubmittingExam(true);
    try {
      const res = await ApiService.submitExamAnswers(selectedExam.id, examAnswers);
      if (!e) {
        alert(`انتهى الوقت المحدد للامتحان! تم تسليم إجاباتك تلقائياً. درجتك: ${res.score} / ${res.max_score}`);
      } else {
        alert(`تم تسليم الامتحان بنجاح! درجتك: ${res.score} / ${res.max_score}`);
      }
      setShowExamModal(false);
      setSelectedExam(null);
      setExamQuestions([]);
      setExamAttempt(null);
      setExamAnswers({});
      loadData();
    } catch (err: any) {
      alert(err.message || 'فشل تسليم الامتحان');
    } finally {
      setSubmittingExam(false);
    }
  };

  const handleOpenQuestionDetails = async (id: string) => {
    try {
      const res = await ApiService.getQuestionDetails(id);
      setSelectedQuestion(res);
    } catch (err: any) {
      alert(err.message || 'تعذر تحميل إجابات السؤال');
    }
  };

  // Filtered suggested courses
  const enrolledIds = new Set([
    ...myCourses.map(c => c.id),
    ...courses.filter(c => c.is_free).map(c => c.id)
  ]);
  const trackedCourses = courses.filter(c => enrolledIds.has(c.id));
  const filteredExploreCourses = courses.filter(c =>
    c.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredQuestions = questions.filter(q => {
    const matchesSearch = q.body.toLowerCase().includes(qaSearch.toLowerCase()) ||
                          (q.lesson_title && q.lesson_title.toLowerCase().includes(qaSearch.toLowerCase()));
    
    if (qaFilter === 'answered') {
      return matchesSearch && q.status === 'answered';
    }
    if (qaFilter === 'pending') {
      return matchesSearch && q.status !== 'answered';
    }
    return matchesSearch;
  });


  // Unused renderLessonCard removed to clean up and avoid TS errors

  const handleTabClick = (tab: 'home' | 'explore' | 'my-courses' | 'qa' | 'profile' | 'exams') => {
    if (tab === 'home' || tab === 'explore') {
      setActiveTab(tab);
    } else {
      if (!profile) {
        alert('يرجى تسجيل الدخول أولاً للوصول إلى هذا القسم.');
        onShowAuth?.();
      } else {
        setActiveTab(tab);
      }
    }
  };




  // Extract latest added items (courses and exams)
  const latestUpdates: any[] = [];
  if (courses && courses.length > 0) {
    courses.slice(0, 2).forEach(c => {
      latestUpdates.push({
        id: c.id,
        title: c.title,
        type: 'course',
        badge: 'مقرر جديد'
      });
    });
  }
  if (exams && exams.length > 0) {
    exams.slice(0, 2).forEach(e => {
      latestUpdates.push({
        id: e.id,
        title: e.title,
        type: 'exam',
        badge: 'امتحان شامل'
      });
    });
  }

  return (
    <div className="home-layout-container" style={{ direction: 'rtl', display: 'flex', height: '100vh', overflow: 'hidden' }}>
      
      {/* ── Sidebar (Right Side in RTL) ── */}
      <aside
        style={{
          width: isSidebarCollapsed ? '78px' : '290px',
          backgroundColor: 'rgb(var(--surface))',
          borderLeft: '1px solid rgb(var(--outline) / 0.15)',
          padding: isSidebarCollapsed ? '24px 10px' : '24px 20px',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
          transition: 'width 0.3s cubic-bezier(0.4, 0, 0.2, 1), padding 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
          height: '100%',
          overflowY: 'auto'
        }}
        className="desktop-sidebar"
      >
        <div className="flex flex-col">
          {/* Collapse/Expand Sidebar Toggle Button */}
          <div style={{ display: 'flex', justifyContent: isSidebarCollapsed ? 'center' : 'flex-end', marginBottom: '14px' }}>
            <button 
              onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
              style={{
                background: 'none',
                border: 'none',
                color: 'rgb(var(--on-surface-variant))',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                padding: '8px',
                borderRadius: '50%',
                backgroundColor: 'rgba(255, 255, 255, 0.03)',
                transition: 'all 0.2s'
              }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = 'rgba(16, 185, 129, 0.08)'}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.03)'}
              title={isSidebarCollapsed ? "توسيع القائمة" : "طي القائمة"}
            >
              <span className="material-symbols-outlined" style={{ fontSize: '20px' }}>
                {isSidebarCollapsed ? 'chevron_left' : 'chevron_right'}
              </span>
            </button>
          </div>

          {/* Sidebar Header (Profile or Brand) */}
          {profile ? (
            <div 
              className="glassy-profile-card"
              style={{ 
                marginBottom: '28px',
                padding: isSidebarCollapsed ? '12px 6px' : '20px 16px',
                borderRadius: '16px',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                textAlign: 'center',
                gap: isSidebarCollapsed ? '4px' : '12px',
                direction: 'rtl',
                backgroundColor: 'rgba(255, 255, 255, 0.03)',
                border: '1px solid rgba(255, 255, 255, 0.06)'
              }}
            >
              {/* Circular Avatar with Glowing Border */}
              <div style={{ position: 'relative' }}>
                <div
                  style={{
                    width: '56px',
                    height: '56px',
                    borderRadius: '50%',
                    overflow: 'hidden',
                    border: '2px solid rgb(var(--primary))',
                    boxShadow: '0 0 15px rgba(16, 185, 129, 0.35)',
                    backgroundColor: 'rgb(var(--surface-dim))',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}
                >
                  {avatarUrl ? (
                    <img src={avatarUrl} alt="صورة شخصية" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  ) : (
                    <span className="icon" style={{ fontSize: '32px', color: 'rgb(var(--primary))' }}>person</span>
                  )}
                </div>
                {/* Active Status Pulse Indicator */}
                <div className="status-dot answered" style={{ position: 'absolute', bottom: '3px', left: '3px', width: '10px', height: '10px', marginLeft: 0 }} />
              </div>
              
              {!isSidebarCollapsed && (
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', marginBottom: '4px' }}>
                    <h3 style={{ fontSize: '14px', fontWeight: '800', color: 'rgb(var(--on-surface))' }}>
                      {profile.full_name}
                    </h3>
                    {/* Notification Bell */}
                    <button 
                      onClick={() => setShowNotificationsModal(true)} 
                      style={{ 
                        background: 'none', 
                        border: 'none', 
                        color: unreadCount > 0 ? 'rgb(var(--primary))' : 'rgb(var(--on-surface-variant))', 
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        position: 'relative',
                        padding: '2px'
                      }}
                      title="الإشعارات والتنبيهات"
                      className="hover:scale-110 transition-transform"
                    >
                      <span className="material-symbols-outlined" style={{ fontSize: '18px' }}>
                        {unreadCount > 0 ? 'notifications_active' : 'notifications'}
                      </span>
                      {unreadCount > 0 && (
                        <span style={{
                          position: 'absolute',
                          top: '1px',
                          right: '1px',
                          backgroundColor: 'rgb(var(--primary))',
                          borderRadius: '50%',
                          width: '6px',
                          height: '6px',
                          boxShadow: '0 0 4px rgb(var(--primary))'
                        }} />
                      )}
                    </button>
                  </div>
                  <p style={{ fontSize: '10px', color: '#CCCCCC', fontWeight: 'bold', marginBottom: '2px' }}>
                    {profile.grade}
                  </p>
                  <span style={{ fontSize: '10px', color: '#CCCCCC' }}>
                    {profile.governorate}
                  </span>
                </div>
              )}
            </div>
          ) : (
            /* Synaptic Studio Brand Header for Guests */
            <div className="flex items-center" style={{ marginBottom: '40px', direction: 'rtl', justifyContent: isSidebarCollapsed ? 'center' : 'flex-start', gap: isSidebarCollapsed ? '0' : '12px' }}>
              <svg width="38" height="38" viewBox="0 0 42 42" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ filter: 'drop-shadow(0 0 8px rgba(16, 185, 129, 0.45))' }}>
                <circle cx="21" cy="21" r="20" fill="url(#synapse_grad)" stroke="rgba(16, 185, 129, 0.3)" strokeWidth="2"/>
                <path d="M14 15C16.5 12.5 20.5 12.5 23 15C25.5 17.5 24 21.5 21 23C18 24.5 16.5 28.5 19 31C21.5 33.5 25.5 33.5 28 31" stroke="#fff" strokeWidth="3" strokeLinecap="round"/>
                <circle cx="14" cy="15" r="3.5" fill="#ffd23f"/>
                <circle cx="21" cy="23" r="4" fill="#10b981"/>
                <circle cx="28" cy="31" r="3.5" fill="#ffd23f"/>
                <defs>
                  <linearGradient id="synapse_grad" x1="0" y1="0" x2="42" y2="42" gradientUnits="userSpaceOnUse">
                    <stop offset="0%" stopColor="rgb(var(--primary))"/>
                    <stop offset="100%" stopColor="rgb(var(--surface-container-high))"/>
                  </linearGradient>
                </defs>
              </svg>
              {!isSidebarCollapsed && (
                <div>
                  <h2 style={{ fontSize: '15px', fontWeight: 800, color: 'rgb(var(--on-surface))', letterSpacing: '0.5px', fontFamily: 'Cairo, sans-serif' }}>منصة الهضبة</h2>
                  <span style={{ fontSize: '10px', color: 'rgb(var(--on-surface-variant))', fontWeight: '600' }}>بإشراف سينابتك ستوديو</span>
                </div>
              )}
            </div>
          )}

          {/* Navigation Links */}
          <nav className="flex flex-col gap-sm">
            <button
              onClick={() => handleTabClick('home')}
              className="btn w-full"
              style={{
                justifyContent: isSidebarCollapsed ? 'center' : 'flex-start',
                padding: isSidebarCollapsed ? '12px 10px' : '12px 16px',
                borderRadius: '10px',
                backgroundColor: activeTab === 'home' ? 'rgb(var(--primary))' : 'transparent',
                color: activeTab === 'home' ? '#fff' : 'rgb(var(--on-surface-variant))',
                boxShadow: activeTab === 'home' ? '0 4px 15px rgba(16, 185, 129, 0.35)' : 'none',
                border: 'none',
                fontSize: '14px',
                fontWeight: activeTab === 'home' ? '700' : '500',
                transition: 'all 0.2s var(--motion-easing)',
              }}
              onMouseEnter={(e) => {
                if (activeTab !== 'home') {
                  e.currentTarget.style.color = '#fff';
                  e.currentTarget.style.backgroundColor = 'rgba(16, 185, 129, 0.08)';
                }
              }}
              onMouseLeave={(e) => {
                if (activeTab !== 'home') {
                  e.currentTarget.style.color = 'rgb(var(--on-surface-variant))';
                  e.currentTarget.style.backgroundColor = 'transparent';
                }
              }}
              title="الرئيسية"
            >
              <span className="icon" style={{ marginLeft: isSidebarCollapsed ? '0' : '12px', fontSize: '20px' }}>home</span>
              {!isSidebarCollapsed && 'الرئيسية'}
            </button>

            <button
              onClick={() => handleTabClick('explore')}
              className="btn w-full"
              style={{
                justifyContent: isSidebarCollapsed ? 'center' : 'flex-start',
                padding: isSidebarCollapsed ? '12px 10px' : '12px 16px',
                borderRadius: '10px',
                backgroundColor: activeTab === 'explore' ? 'rgb(var(--primary))' : 'transparent',
                color: activeTab === 'explore' ? '#fff' : 'rgb(var(--on-surface-variant))',
                boxShadow: activeTab === 'explore' ? '0 4px 15px rgba(16, 185, 129, 0.35)' : 'none',
                border: 'none',
                fontSize: '14px',
                fontWeight: activeTab === 'explore' ? '700' : '500',
                transition: 'all 0.2s var(--motion-easing)',
              }}
              onMouseEnter={(e) => {
                if (activeTab !== 'explore') {
                  e.currentTarget.style.color = '#fff';
                  e.currentTarget.style.backgroundColor = 'rgba(16, 185, 129, 0.08)';
                }
              }}
              onMouseLeave={(e) => {
                if (activeTab !== 'explore') {
                  e.currentTarget.style.color = 'rgb(var(--on-surface-variant))';
                  e.currentTarget.style.backgroundColor = 'transparent';
                }
              }}
              title="الدورات"
            >
              <span className="icon" style={{ marginLeft: isSidebarCollapsed ? '0' : '12px', fontSize: '20px' }}>explore</span>
              {!isSidebarCollapsed && 'الدورات'}
            </button>

            <button
              onClick={() => handleTabClick('my-courses')}
              className="btn w-full"
              style={{
                justifyContent: isSidebarCollapsed ? 'center' : 'flex-start',
                padding: isSidebarCollapsed ? '12px 10px' : '12px 16px',
                borderRadius: '10px',
                backgroundColor: activeTab === 'my-courses' ? 'rgb(var(--primary))' : 'transparent',
                color: activeTab === 'my-courses' ? '#fff' : 'rgb(var(--on-surface-variant))',
                boxShadow: activeTab === 'my-courses' ? '0 4px 15px rgba(16, 185, 129, 0.35)' : 'none',
                border: 'none',
                fontSize: '14px',
                fontWeight: activeTab === 'my-courses' ? '700' : '500',
                transition: 'all 0.2s var(--motion-easing)',
              }}
              onMouseEnter={(e) => {
                if (activeTab !== 'my-courses') {
                  e.currentTarget.style.color = '#fff';
                  e.currentTarget.style.backgroundColor = 'rgba(16, 185, 129, 0.08)';
                }
              }}
              onMouseLeave={(e) => {
                if (activeTab !== 'my-courses') {
                  e.currentTarget.style.color = 'rgb(var(--on-surface-variant))';
                  e.currentTarget.style.backgroundColor = 'transparent';
                }
              }}
              title="كورساتي المفضلة"
            >
              <span className="icon" style={{ marginLeft: isSidebarCollapsed ? '0' : '12px', fontSize: '20px' }}>school</span>
              {!isSidebarCollapsed && 'كورساتي المفضلة'}
            </button>

            <button
              onClick={() => handleTabClick('exams')}
              className="btn w-full"
              style={{
                justifyContent: isSidebarCollapsed ? 'center' : 'flex-start',
                padding: isSidebarCollapsed ? '12px 10px' : '12px 16px',
                borderRadius: '10px',
                backgroundColor: activeTab === 'exams' ? 'rgb(var(--primary))' : 'transparent',
                color: activeTab === 'exams' ? '#fff' : 'rgb(var(--on-surface-variant))',
                boxShadow: activeTab === 'exams' ? '0 4px 15px rgba(16, 185, 129, 0.35)' : 'none',
                border: 'none',
                fontSize: '14px',
                fontWeight: activeTab === 'exams' ? '700' : '500',
                transition: 'all 0.2s var(--motion-easing)',
              }}
              onMouseEnter={(e) => {
                if (activeTab !== 'exams') {
                  e.currentTarget.style.color = '#fff';
                  e.currentTarget.style.backgroundColor = 'rgba(16, 185, 129, 0.08)';
                }
              }}
              onMouseLeave={(e) => {
                if (activeTab !== 'exams') {
                  e.currentTarget.style.color = 'rgb(var(--on-surface-variant))';
                  e.currentTarget.style.backgroundColor = 'transparent';
                }
              }}
              title="الامتحانات والفيديوهات"
            >
              <span className="icon" style={{ marginLeft: isSidebarCollapsed ? '0' : '12px', fontSize: '20px' }}>assignment</span>
              {!isSidebarCollapsed && 'الامتحانات والفيديوهات'}
            </button>

            <button
              onClick={() => handleTabClick('qa')}
              className="btn w-full"
              style={{
                justifyContent: isSidebarCollapsed ? 'center' : 'flex-start',
                padding: isSidebarCollapsed ? '12px 10px' : '12px 16px',
                borderRadius: '10px',
                backgroundColor: activeTab === 'qa' ? 'rgb(var(--primary))' : 'transparent',
                color: activeTab === 'qa' ? '#fff' : 'rgb(var(--on-surface-variant))',
                boxShadow: activeTab === 'qa' ? '0 4px 15px rgba(16, 185, 129, 0.35)' : 'none',
                border: 'none',
                fontSize: '14px',
                fontWeight: activeTab === 'qa' ? '700' : '500',
                transition: 'all 0.2s var(--motion-easing)',
              }}
              onMouseEnter={(e) => {
                if (activeTab !== 'qa') {
                  e.currentTarget.style.color = '#fff';
                  e.currentTarget.style.backgroundColor = 'rgba(16, 185, 129, 0.08)';
                }
              }}
              onMouseLeave={(e) => {
                if (activeTab !== 'qa') {
                  e.currentTarget.style.color = 'rgb(var(--on-surface-variant))';
                  e.currentTarget.style.backgroundColor = 'transparent';
                }
              }}
              title="الأسئلة والاستفسارات"
            >
              <span className="icon" style={{ marginLeft: isSidebarCollapsed ? '0' : '12px', fontSize: '20px' }}>question_answer</span>
              {!isSidebarCollapsed && 'الأسئلة والاستفسارات'}
            </button>

            <button
              onClick={() => handleTabClick('profile')}
              className="btn w-full"
              style={{
                justifyContent: isSidebarCollapsed ? 'center' : 'flex-start',
                padding: isSidebarCollapsed ? '12px 10px' : '12px 16px',
                borderRadius: '10px',
                backgroundColor: activeTab === 'profile' ? 'rgb(var(--primary))' : 'transparent',
                color: activeTab === 'profile' ? '#fff' : 'rgb(var(--on-surface-variant))',
                boxShadow: activeTab === 'profile' ? '0 4px 15px rgba(16, 185, 129, 0.35)' : 'none',
                border: 'none',
                fontSize: '14px',
                fontWeight: activeTab === 'profile' ? '700' : '500',
                transition: 'all 0.2s var(--motion-easing)',
              }}
              onMouseEnter={(e) => {
                if (activeTab !== 'profile') {
                  e.currentTarget.style.color = '#fff';
                  e.currentTarget.style.backgroundColor = 'rgba(16, 185, 129, 0.08)';
                }
              }}
              onMouseLeave={(e) => {
                if (activeTab !== 'profile') {
                  e.currentTarget.style.color = 'rgb(var(--on-surface-variant))';
                  e.currentTarget.style.backgroundColor = 'transparent';
                }
              }}
              title="ملفي الشخصي"
            >
              <span className="icon" style={{ marginLeft: isSidebarCollapsed ? '0' : '12px', fontSize: '20px' }}>person</span>
              {!isSidebarCollapsed && 'ملفي الشخصي'}
            </button>
          </nav>

          {/* Stats section inside the sidebar */}
          {profile && !isSidebarCollapsed && (
            <div style={{ marginTop: '24px', padding: '16px 12px', backgroundColor: 'rgb(var(--surface-container-low))', borderRadius: '12px', border: '1px solid rgb(var(--outline) / 0.1)' }}>
              <h4 style={{ fontSize: '11px', color: '#CCCCCC', marginBottom: '12px', fontWeight: 'bold' }}>إحصائياتي الدراسية</h4>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '12px' }}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#CCCCCC' }}>
                    <span className="icon" style={{ fontSize: '16px', color: 'rgb(var(--primary))' }}>video_library</span>
                    المحتويات المفضلة
                  </span>
                  <span style={{ fontWeight: 'bold', color: 'rgb(var(--on-surface))' }}>{stats.coursesCount}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '12px' }}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#CCCCCC' }}>
                    <span className="icon" style={{ fontSize: '16px', color: 'rgb(var(--primary))' }}>task_alt</span>
                    الامتحانات المحلولة
                  </span>
                  <span style={{ fontWeight: 'bold', color: 'rgb(var(--on-surface))' }}>{stats.quizzesCount}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '12px' }}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#CCCCCC' }}>
                    <span className="icon" style={{ fontSize: '16px', color: 'rgb(var(--primary))' }}>help_outline</span>
                    الأسئلة المطروحة
                  </span>
                  <span style={{ fontWeight: 'bold', color: 'rgb(var(--on-surface))' }}>{stats.questionsCount}</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Area with Theme/Logout */}
        <div className="flex flex-col gap-md" style={{ borderTop: '1px solid rgba(16, 185, 129, 0.1)', paddingTop: '20px' }}>
          {/* Custom Theme Switcher */}
          <div style={{ display: 'flex', alignItems: 'center', backgroundColor: 'rgb(var(--surface-dim))', borderRadius: '12px', padding: '3px', border: '1px solid rgb(var(--outline) / 0.1)', flexDirection: isSidebarCollapsed ? 'column' : 'row', gap: isSidebarCollapsed ? '6px' : '0' }}>
            <button
              onClick={() => theme === 'light' && toggleTheme()}
              style={{
                flex: isSidebarCollapsed ? 'none' : 1,
                width: isSidebarCollapsed ? '36px' : 'auto',
                height: isSidebarCollapsed ? '36px' : 'auto',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '6px',
                background: theme === 'dark' ? 'linear-gradient(135deg, rgb(16, 185, 129) 0%, rgb(5, 150, 105) 100%)' : 'transparent',
                color: theme === 'dark' ? '#fff' : 'rgb(var(--on-surface-variant))',
                border: 'none',
                borderRadius: '8px',
                padding: '8px 4px',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
                fontSize: '12px',
                fontWeight: 'bold',
                fontFamily: 'Cairo, sans-serif'
              }}
              title="الوضع الليلي"
            >
              <span className={`icon ${theme === 'dark' ? 'animate-moon-swing' : ''}`} style={{ fontSize: '18px', color: theme === 'dark' ? '#ffd23f' : 'inherit' }}>dark_mode</span>
              {!isSidebarCollapsed && 'الوضع الليلي'}
            </button>
            <button
              onClick={() => theme === 'dark' && toggleTheme()}
              style={{
                flex: isSidebarCollapsed ? 'none' : 1,
                width: isSidebarCollapsed ? '36px' : 'auto',
                height: isSidebarCollapsed ? '36px' : 'auto',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '6px',
                background: theme === 'light' ? 'linear-gradient(135deg, rgb(16, 185, 129) 0%, rgb(5, 150, 105) 100%)' : 'transparent',
                color: theme === 'light' ? '#fff' : 'rgb(var(--on-surface-variant))',
                border: 'none',
                borderRadius: '8px',
                padding: '8px 4px',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
                fontSize: '12px',
                fontWeight: 'bold',
                fontFamily: 'Cairo, sans-serif'
              }}
              title="الوضع المضيء"
            >
              <span className={`icon ${theme === 'light' ? 'animate-sun-beam' : ''}`} style={{ fontSize: '18px', color: theme === 'light' ? '#ffd23f' : 'inherit' }}>light_mode</span>
              {!isSidebarCollapsed && 'الوضع المضيء'}
            </button>
          </div>

          {profile ? (
            <button
              onClick={logout}
              className="btn w-full"
              style={{
                justifyContent: 'center',
                backgroundColor: 'transparent',
                color: '#f87171',
                border: '1px solid rgba(239, 68, 68, 0.2)',
                fontSize: '14px',
                fontWeight: '700',
                padding: '12px',
                borderRadius: '10px',
                transition: 'all 0.2s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = 'rgba(239, 68, 68, 0.1)';
                e.currentTarget.style.borderColor = 'rgba(239, 68, 68, 0.4)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'transparent';
                e.currentTarget.style.borderColor = 'rgba(239, 68, 68, 0.2)';
              }}
              title="تسجيل الخروج"
            >
              <span className="icon" style={{ marginLeft: isSidebarCollapsed ? '0' : '8px', fontSize: '18px' }}>logout</span>
              {!isSidebarCollapsed && 'تسجيل الخروج'}
            </button>
          ) : (
            <div className="flex w-full" style={{ marginTop: '4px', flexDirection: isSidebarCollapsed ? 'column' : 'row', gap: '8px' }}>
              <button
                onClick={() => onShowAuth?.()}
                className="btn"
                style={{
                  flex: isSidebarCollapsed ? 'none' : 1,
                  justifyContent: 'center',
                  backgroundColor: 'transparent',
                  color: '#fff',
                  border: '1px solid rgba(255, 255, 255, 0.25)',
                  fontSize: '13px',
                  fontWeight: 'bold',
                  padding: '10px',
                  borderRadius: '8px',
                  transition: 'all 0.2s ease',
                  fontFamily: 'Cairo, sans-serif'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.05)';
                  e.currentTarget.style.borderColor = 'rgba(var(--primary), 0.4)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'transparent';
                  e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.25)';
                }}
                title="تسجيل الدخول"
              >
                {isSidebarCollapsed ? <span className="icon" style={{ fontSize: '18px' }}>login</span> : 'دخول'}
              </button>
              <button
                onClick={() => onShowAuth?.()}
                className="btn"
                style={{
                  flex: isSidebarCollapsed ? 'none' : 1,
                  justifyContent: 'center',
                  backgroundColor: 'rgb(var(--primary))',
                  color: '#fff',
                  border: 'none',
                  fontSize: '13px',
                  fontWeight: 'bold',
                  padding: '10px',
                  borderRadius: '8px',
                  transition: 'all 0.2s ease',
                  boxShadow: '0 4px 10px rgba(var(--primary), 0.35)',
                  fontFamily: 'Cairo, sans-serif'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = 'rgb(var(--primary))';
                  e.currentTarget.style.boxShadow = '0 0 15px rgba(var(--primary), 0.6)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'rgb(var(--primary))';
                  e.currentTarget.style.boxShadow = '0 4px 10px rgba(var(--primary), 0.35)';
                }}
                title="إنشاء حساب جديد"
              >
                {isSidebarCollapsed ? <span className="icon" style={{ fontSize: '18px' }}>person_add</span> : 'تسجيل'}
              </button>
            </div>
          )}

          {/* Copyright Section */}
          {!isSidebarCollapsed && (
            <a
              href="https://www.synapticstudio.tech/ar/start"
              target="_blank"
              rel="noopener noreferrer"
              style={{
                marginTop: 'auto',
                paddingTop: '20px',
                textAlign: 'center',
                fontSize: '11px',
                color: 'rgb(var(--on-surface-variant))',
                textDecoration: 'none',
                transition: 'all 0.2s ease',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '6px',
                fontFamily: 'Cairo, sans-serif',
                fontWeight: '600',
                borderTop: '1px solid rgb(var(--outline) / 0.1)'
              }}
              onMouseEnter={(e) => {
                const children = e.currentTarget.children;
                if (children[0]) (children[0] as HTMLElement).style.color = '#3b82f6';
                if (children[1]) (children[1] as HTMLElement).style.color = 'rgb(var(--on-surface))';
                if (children[2]) (children[2] as HTMLElement).style.color = '#60a5fa';
              }}
              onMouseLeave={(e) => {
                const children = e.currentTarget.children;
                if (children[0]) (children[0] as HTMLElement).style.color = 'rgb(var(--on-surface-variant))';
                if (children[1]) (children[1] as HTMLElement).style.color = 'rgb(var(--on-surface-variant))';
                if (children[2]) (children[2] as HTMLElement).style.color = '#3b82f6';
              }}
            >
              <span className="icon" style={{ fontSize: '13px', color: 'rgb(var(--on-surface-variant))', transition: 'color 0.2s' }}>copyright</span>
              <span style={{ color: 'rgb(var(--on-surface-variant))', transition: 'color 0.2s' }}>حقوق النشر والتشغيل محفوظة لـ </span>
              <span style={{ color: '#3b82f6', fontWeight: '800', transition: 'color 0.2s' }}>سينابتك ستوديو</span>
            </a>
          )}
        </div>
      </aside>

      {/* ── Main Content Area ── */}
      <main className="chemistry-matrix-bg" style={{ flex: 1, backgroundColor: 'rgb(var(--background))', overflowY: 'auto', padding: '40px', height: '100%' }}>
        
        {/* Desktop Top Header Banner (Only visible on larger screens) */}
        {activeTab !== 'home' && (
          <div className="desktop-top-header" style={{ display: 'none', justifyContent: 'space-between', alignItems: 'center', marginBottom: '28px', direction: 'rtl' }}>
          {/* Right Side: Welcome message or Active tab title */}
          <div>
            <h1 style={{ fontSize: '20px', fontWeight: '900', color: 'rgb(var(--on-surface))', fontFamily: 'Cairo, sans-serif', margin: 0 }}>
              {activeTab === 'explore' && 'تصفح الدورات'}
              {activeTab === 'my-courses' && 'مقرراتي التعليمية'}
              {activeTab === 'exams' && 'الامتحانات والفيديوهات'}
              {activeTab === 'qa' && 'الأسئلة والاستفسارات'}
              {activeTab === 'profile' && 'الملف الشخصي'}
            </h1>
          </div>

          {/* Left Side: Streak & Notification Actions */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            {profile && (
              <>
                {/* Daily Streak Indicator */}
                <div 
                  style={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    gap: '8px', 
                    backgroundColor: 'rgba(255, 107, 107, 0.08)', 
                    border: '1px solid rgba(255, 107, 107, 0.25)', 
                    padding: '8px 14px', 
                    borderRadius: '12px',
                    color: '#ff6b6b',
                    fontWeight: 'bold',
                    fontSize: '13px'
                  }}
                  title="أيام التعلم المتتالية"
                >
                  <span className="material-symbols-outlined animate-pulse" style={{ fontSize: '18px', color: '#ff6b6b' }}>local_fire_department</span>
                  <span>{(profile as any).streak_count || 3} يوم متتالي</span>
                </div>

                {/* Notifications Bell */}
                <button 
                  onClick={() => setShowNotificationsModal(true)} 
                  className="btn" 
                  style={{ 
                    padding: '10px 14px', 
                    borderRadius: '12px', 
                    backgroundColor: 'rgba(255, 255, 255, 0.04)', 
                    border: '1px solid rgba(255, 255, 255, 0.06)',
                    color: '#fff',
                    position: 'relative', 
                    display: 'flex', 
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer',
                    transition: 'all 0.2s'
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.borderColor = 'rgba(16, 185, 129, 0.3)'}
                  onMouseLeave={(e) => e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.06)'}
                  title="التنبيهات"
                >
                  <span className="material-symbols-outlined" style={{ fontSize: '20px', color: unreadCount > 0 ? 'rgb(var(--primary))' : '#fff' }}>
                    {unreadCount > 0 ? 'notifications_active' : 'notifications'}
                  </span>
                  {unreadCount > 0 && (
                    <span style={{
                      position: 'absolute',
                      top: '6px',
                      right: '6px',
                      backgroundColor: 'rgb(var(--primary))',
                      borderRadius: '50%',
                      width: '7px',
                      height: '7px',
                      boxShadow: '0 0 6px rgb(var(--primary))'
                    }} />
                  )}
                </button>
              </>
            )}
          </div>

          </div>
        )}
        
        {/* Mobile Header Banner (Alternative Navigation for small screens) */}
        <div className="mobile-header" style={{ display: 'none', marginBottom: '24px', justifyContent: 'space-between', alignItems: 'center', direction: 'rtl' }}>
          <div className="flex gap-sm items-center">
            {/* Logout Button (Leftmost) */}
            <button 
              onClick={logout} 
              className="btn" 
              style={{ 
                padding: '10px 14px', 
                borderRadius: '12px', 
                backgroundColor: 'rgba(239, 68, 68, 0.15)', 
                color: 'rgb(239, 68, 68)', 
                border: 'none',
                display: 'flex', 
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer'
              }}
              title="تسجيل الخروج"
            >
              <span className="icon" style={{ fontSize: '20px' }}>logout</span>
            </button>

            {/* Theme Toggle Button */}
            <button 
              onClick={toggleTheme} 
              className="btn" 
              style={{ 
                padding: '10px 14px', 
                borderRadius: '12px', 
                backgroundColor: 'rgba(255, 255, 255, 0.05)', 
                border: '1px solid rgba(255, 255, 255, 0.08)',
                color: '#ffd23f',
                display: 'flex', 
                alignItems: 'center',
                justifyContent: 'center',
                overflow: 'hidden',
                cursor: 'pointer'
              }}
              title="تبديل المظهر"
            >
              {theme === 'dark' ? (
                <span className="icon animate-sun-beam" style={{ color: '#ffd23f', fontSize: '20px' }}>light_mode</span>
              ) : (
                <span className="icon animate-moon-swing" style={{ color: '#ffd23f', fontSize: '20px' }}>dark_mode</span>
              )}
            </button>

            {/* Notification Bell Button */}
            {profile && (
              <button 
                onClick={() => setShowNotificationsModal(true)} 
                className="btn" 
                style={{ 
                  padding: '10px 14px', 
                  borderRadius: '12px', 
                  backgroundColor: 'rgba(255, 255, 255, 0.05)', 
                  border: '1px solid rgba(255, 255, 255, 0.08)',
                  color: '#fff',
                  position: 'relative', 
                  display: 'flex', 
                  alignItems: 'center',
                  justifyContent: 'center',
                  cursor: 'pointer'
                }}
                title="التنبيهات"
              >
                <span className="material-symbols-outlined" style={{ fontSize: '20px', color: unreadCount > 0 ? 'rgb(var(--primary))' : '#fff' }}>
                  {unreadCount > 0 ? 'notifications_active' : 'notifications'}
                </span>
                {unreadCount > 0 && (
                  <span style={{
                    position: 'absolute',
                    top: '6px',
                    right: '6px',
                    backgroundColor: 'rgb(var(--primary))',
                    borderRadius: '50%',
                    width: '7px',
                    height: '7px',
                    boxShadow: '0 0 6px rgb(var(--primary))'
                  }} />
                )}
              </button>
            )}
            {/* Mobile Daily Streak Indicator */}
            {profile && (
              <div 
                style={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  gap: '4px', 
                  backgroundColor: 'rgba(255, 107, 107, 0.08)', 
                  border: '1px solid rgba(255, 107, 107, 0.25)', 
                  padding: '8px 12px', 
                  borderRadius: '12px',
                  color: '#ff6b6b',
                  fontWeight: 'bold',
                  fontSize: '12px'
                }}
                title="أيام التعلم المتتالية"
              >
                <span className="material-symbols-outlined" style={{ fontSize: '16px', color: '#ff6b6b' }}>local_fire_department</span>
                <span>{(profile as any).streak_count || 3}🔥</span>
              </div>
            )}
          </div>

          {/* Platform Title (Rightmost) */}
          <div className="flex items-center gap-sm">
            <h2 style={{ fontSize: '15px', fontFamily: 'Cairo, sans-serif', fontWeight: 'bold', color: '#fff' }}>المنصة الطلابية</h2>
            <span className="icon" style={{ color: 'rgb(var(--primary))', fontSize: '22px' }}>school</span>
          </div>
        </div>

        {/* Loading Indicator */}
        {loading && (
          <div style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '3px', zIndex: 100 }}>
            <div className="shimmer-loading" style={{ height: '100%' }}></div>
          </div>
        )}

        {/* ── TAB 1: HOME TAB ── */}
        {activeTab === 'home' && (
          <div className="flex flex-col gap-xl">
            <div className="animate-fade-in-up hero-premium-card" style={{ padding: '32px' }}>
              {/* DESKTOP LAYOUT (visible on desktop) */}
              <div className="desktop-hero-layout">
                {/* Right Area (Portrait Column: Teacher Portrait) */}
                <div className="hero-portrait-column">
                  {/* Render all 4 images with smooth opacity transitions and automatic switching */}
                  {teacherImages.map((imgSrc, idx) => (
                    <img 
                      key={idx}
                      src={imgSrc} 
                      alt="منصة الوفيرة"
                      className={`portrait-teacher-img pose-img-${idx} ${teacherPoseIdx === idx ? 'pose-active' : 'pose-inactive'}`}
                    />
                  ))}
                </div>

                {/* Left Area (Content Column: Text at top, Pegboard at bottom) */}
                <div className="hero-content-column">
                  
                  {/* Top Text & Buttons block */}
                  <div className="hero-text-block">
                    <span style={{ fontSize: '11px', color: 'rgb(var(--primary))', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '6px', letterSpacing: '0.5px', justifyContent: 'center', width: '100%', marginBottom: '8px' }}>
                      <span className="material-symbols-outlined animate-pulse" style={{ fontSize: '16px', color: 'rgb(var(--primary))' }}>workspace_premium</span>
                      المنصة التعليمية الرسمية للأستاذ أحمد عادل المحدثة
                    </span>
                    
                    <div>
                      <h1 style={{ fontSize: '48px', fontWeight: '900', color: '#fff', margin: 0, fontFamily: 'Cairo, sans-serif', lineHeight: '1.2', textShadow: '0 2px 10px rgba(0,0,0,0.5)', textAlign: 'center' }}>
                        منصتك الأولى لتعلّم وفهم <span style={{ color: 'rgb(var(--primary))', textShadow: '0 0 15px rgba(16, 185, 129, 0.35)' }}>الكيمياء</span>
                      </h1>
                      <h2 style={{ fontSize: '36px', fontWeight: '900', color: '#fff', margin: '10px 0 0 0', fontFamily: 'Cairo, sans-serif', lineHeight: '1.2', textShadow: '0 2px 10px rgba(0,0,0,0.5)', textAlign: 'center' }}>
                        تأمّن طريقك للنجاح 🚀
                      </h2>
                    </div>

                    <p style={{ fontSize: '15px', color: '#F3F4F6', lineHeight: '1.6', margin: '14px auto 0 auto', maxWidth: '580px', fontWeight: '500', textAlign: 'center' }}>
                      رحلتك نحو الدرجة النهائية في الكيمياء تبدأ من هنا، نقدم لك تجربة تعليمية استثنائية تجمع بين الفهم المبسط والمشاهدة الذكية لتضمن تفوقك الدراسي.
                    </p>

                    {/* Horizontal Action Buttons Row - Centered */}
                    <div className="hero-buttons-horizontal-row" style={{ display: 'flex', gap: '16px', marginTop: '20px', alignItems: 'center', justifyContent: 'center' }}>
                      {/* Outline Button */}
                      <button 
                        onClick={() => setShowRedeemModal(true)}
                        className="btn btn-secondary"
                        style={{ 
                          fontSize: '15px', 
                          padding: '12px 32px', 
                          borderRadius: '12px', 
                          color: '#E6E6E6', 
                          backgroundColor: 'rgba(255,255,255,0.05)', 
                          border: '1px solid rgba(255,255,255,0.12)', 
                          fontWeight: 'bold', 
                          cursor: 'pointer',
                          transition: 'all 0.2s ease',
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
                          e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.25)';
                          e.currentTarget.style.color = '#fff';
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.05)';
                          e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.12)';
                          e.currentTarget.style.color = '#E6E6E6';
                        }}
                      >
                        تفعيل كود مقرر
                      </button>
                      {/* Solid Green Glowing Button */}
                      <button 
                        onClick={() => handleTabClick('explore')}
                        className="btn btn-primary"
                        style={{ 
                          fontSize: '15px', 
                          padding: '12px 32px', 
                          borderRadius: '12px', 
                          border: '1px solid rgba(255, 255, 255, 0.25)', 
                          fontWeight: 'bold', 
                          backgroundColor: 'rgb(var(--primary))', 
                          color: '#fff', 
                          cursor: 'pointer', 
                          boxShadow: '0 6px 20px rgba(16, 185, 129, 0.4)',
                          transition: 'transform 0.2s cubic-bezier(0.4, 0, 0.2, 1), background-color 0.2s, box-shadow 0.2s',
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.transform = 'scale(1.03)';
                          e.currentTarget.style.backgroundColor = '#10b981';
                          e.currentTarget.style.boxShadow = '0 8px 24px rgba(16, 185, 129, 0.55)';
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.transform = 'scale(1)';
                          e.currentTarget.style.backgroundColor = 'rgb(var(--primary))';
                          e.currentTarget.style.boxShadow = '0 6px 20px rgba(16, 185, 129, 0.4)';
                        }}
                      >
                        ابدأ التعلم الآن
                      </button>
                    </div>
                  </div>

                  {/* Centered Pegboard Block at the bottom */}
                  <div className="hero-pegboard-block">
                    <div className="hero-wooden-pegboard">
                      <div className="pegboard-notes-container">
                        {/* Note 1: Yellow */}
                        <div className="pegboard-note-card pegboard-note-yellow pegboard-note-1">
                          <div className="pegboard-peg" />
                          <h4>منهج كامل وشرح وافي</h4>
                          <p>شرح تفصيلي ومبسط يعتمد على بناء المفاهيم الكيميائية.</p>
                        </div>
                        {/* Note 2: Green */}
                        <div className="pegboard-note-card pegboard-note-green pegboard-note-2">
                          <div className="pegboard-peg" />
                          <h4>تدريبات وامتحانات دورية</h4>
                          <p>امتحانات وتدريبات عقب كل محاضرة لقياس استيعابك.</p>
                        </div>
                        {/* Note 3: Purple */}
                        <div className="pegboard-note-card pegboard-note-purple pegboard-note-3">
                          <div className="pegboard-peg" />
                          <h4>ملخصات وخرائط ذهنية</h4>
                          <p>كتيبات ملخصة وخرائط لتسهيل الفهم والاستذكار السريع.</p>
                        </div>
                        {/* Note 4: Rose */}
                        <div className="pegboard-note-card pegboard-note-rose pegboard-note-4">
                          <div className="pegboard-peg" />
                          <h4>متابعة أولياء الأمور</h4>
                          <p>تقارير دورية لمستويات الطالب وتفاصيل درجاته وتقدمه.</p>
                        </div>
                      </div>
                    </div>
                  </div>

                </div>
              </div>

                            {/* MOBILE LAYOUT (Exactly as it was) */}
              <div className="mobile-hero-layout">
                <div className="hero-text-column">
                  <span style={{ fontSize: '11px', color: 'rgb(var(--primary))', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '6px', letterSpacing: '0.5px', justifyContent: 'var(--hero-badge-justify, flex-start)', width: '100%' }}>
                    <span className="material-symbols-outlined animate-pulse" style={{ fontSize: '16px', color: 'rgb(var(--primary))' }}>workspace_premium</span>
                    المنصة التعليمية الرسمية للأستاذ أحمد عادل المحدثة
                  </span>
                  
                  <div>
                    <h1 style={{ fontSize: '32px', fontWeight: '900', color: '#fff', margin: 0, fontFamily: 'Cairo, sans-serif', lineHeight: '1.4', textShadow: '0 2px 10px rgba(0,0,0,0.5)' }}>
                      منصتك الأولى لتعلّم وفهم <span style={{ color: 'rgb(var(--primary))', textShadow: '0 0 15px rgba(16, 185, 129, 0.35)' }}>الكيمياء</span>
                    </h1>
                    <div style={{ height: '40px', overflow: 'hidden', marginTop: '4px' }}>
                      <h2 
                        style={{
                          fontSize: '26px',
                          fontWeight: '900',
                          color: 'rgb(var(--primary))',
                          margin: 0,
                          transition: 'all 0.3s ease-in-out',
                          opacity: hookFade ? 1 : 0,
                          transform: hookFade ? 'translateY(0)' : 'translateY(-10px)'
                        }}
                      >
                        {hooks[currentHookIdx]}
                      </h2>
                    </div>
                  </div>

                  <p style={{ fontSize: '13px', color: '#E6E6E6', lineHeight: '1.6', margin: 0, maxWidth: '520px', fontWeight: '500' }}>
                    رحلتك نحو <strong style={{ color: '#fff', fontWeight: '800' }}>الدرجة النهائية في الكيمياء</strong> تبدأ من هنا! نقدم لك تجربة تعليمية استثنائية تجمع بين الشرح المبسط والمتابعة الذكية لتضمن تفوقك الدراسي.
                  </p>

                  {/* Clean Action Buttons */}
                  <div className="hero-buttons-container" style={{ display: 'flex', gap: '12px', marginTop: '4px', flexWrap: 'wrap', alignItems: 'center' }}>
                    <button 
                      onClick={() => handleTabClick('explore')}
                      className="btn btn-primary"
                      style={{ 
                        fontSize: '14px', 
                        padding: '10px 24px', 
                        borderRadius: '10px', 
                        border: '1px solid rgba(255, 255, 255, 0.25)', 
                        fontWeight: 'bold', 
                        backgroundColor: 'rgb(var(--primary))', 
                        color: '#fff', 
                        cursor: 'pointer', 
                        boxShadow: '0 6px 20px rgba(16, 185, 129, 0.4)',
                        transition: 'transform 0.2s cubic-bezier(0.4, 0, 0.2, 1), background-color 0.2s, box-shadow 0.2s',
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.transform = 'scale(1.03)';
                        e.currentTarget.style.backgroundColor = '#10b981';
                        e.currentTarget.style.boxShadow = '0 8px 24px rgba(16, 185, 129, 0.55)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.transform = 'scale(1)';
                        e.currentTarget.style.backgroundColor = 'rgb(var(--primary))';
                        e.currentTarget.style.boxShadow = '0 6px 20px rgba(16, 185, 129, 0.4)';
                      }}
                    >
                      ابدأ التعلم الآن
                    </button>
                    <button 
                      onClick={() => setShowRedeemModal(true)}
                      className="btn btn-secondary"
                      style={{ 
                        fontSize: '13px', 
                        padding: '10px 20px', 
                        borderRadius: '10px', 
                        color: '#E6E6E6', 
                        backgroundColor: 'rgba(255,255,255,0.05)', 
                        border: '1px solid rgba(255, 255, 255, 0.12)', 
                        fontWeight: 'bold', 
                        cursor: 'pointer',
                        transition: 'all 0.2s ease' 
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
                        e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.25)';
                        e.currentTarget.style.color = '#fff';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.05)';
                        e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.12)';
                        e.currentTarget.style.color = '#E6E6E6';
                      }}
                    >
                      تفعيل كود مقرر
                    </button>
                  </div>

                  <div className="hero-stats-container">
                    <div className="hero-stat-item">
                      <span style={{ fontSize: '18px', fontWeight: '900', color: 'rgb(var(--primary))' }}>+50K</span>
                      <span style={{ fontSize: '10px', color: '#CCCCCC' }}>طالب مسجل بالمنصة</span>
                    </div>
                    <div className="hero-stat-item">
                      <span style={{ fontSize: '18px', fontWeight: '900', color: 'rgb(var(--primary))' }}>+2.5M</span>
                      <span style={{ fontSize: '10px', color: '#CCCCCC' }}>مشاهدة تعليمية</span>
                    </div>
                    <div className="hero-stat-item">
                      <span style={{ fontSize: '18px', fontWeight: '900', color: 'rgb(var(--primary))' }}>+100</span>
                      <span style={{ fontSize: '10px', color: '#CCCCCC' }}>إطلاق ومحتوى إضافي</span>
                    </div>
                  </div>
                </div>

                {/* Pinned board with 5 carousel stacked cards on mobile */}
                <div className="hero-board-column">
                  <div className="board-nail" />
                  <svg className="board-rope" viewBox="0 0 400 35">
                    <path d="M 12 35 L 200 6 L 388 35" stroke="#7c3f12" strokeWidth="3" fill="none" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  <div className="hero-wooden-board">
                    <div className="board-notes-container">
                      {platformNotes.map((note) => {
                        const stackPos = cardOrder.indexOf(note.id);
                        const isFlying = flyingCardId === note.id;
                        return (
                          <div 
                            key={note.id}
                            onClick={() => handleCardClick(note.id)}
                            className={`taped-note-card taped-note-${note.type} stack-pos-${stackPos} ${isFlying ? 'flying-out' : ''}`}
                          >
                            <div className="tape" />
                            <div className="note-icon-circle">
                              <span className="material-symbols-outlined note-icon">{note.icon}</span>
                            </div>
                            <h4>{note.title}</h4>
                            <p>{note.desc}</p>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>


                {/* Left Column: Premium Circular Orb with Pop-Out Torso */}
                <div className="hero-portrait-column" style={{ minHeight: '250px', height: '250px', position: 'relative', width: '100%', display: 'flex', justifyContent: 'center', alignItems: 'flex-end', marginBottom: '-32px' }}>
                  {/* Glowing Backlight */}
                  <div 
                    style={{
                      position: 'absolute',
                      width: '180px',
                      height: '180px',
                      background: 'radial-gradient(circle, rgba(var(--primary), 0.22) 0%, transparent 70%)',
                      borderRadius: '50%',
                      filter: 'blur(25px)',
                      zIndex: 1,
                      top: '15%',
                      left: '50%',
                      transform: 'translateX(-50%)'
                    }}
                  />

                  {/* Circular Orb Container (behind teacher, centered) */}
                  <div
                    style={{
                      position: 'absolute',
                      width: '160px',
                      height: '160px',
                      borderRadius: '50%',
                      background: 'radial-gradient(circle, rgba(var(--primary), 0.15) 0%, rgba(20, 20, 25, 0.6) 100%)',
                      border: '3px solid rgba(var(--primary), 0.45)',
                      boxShadow: '0 0 25px rgba(var(--primary), 0.25), inset 0 0 15px rgba(var(--primary), 0.15)',
                      top: '55%',
                      left: '50%',
                      transform: 'translate(-50%, -50%)',
                      zIndex: 2
                    }}
                  >
                    {/* Glassmorphic reflection highlight overlay inside the orb */}
                    <div 
                      style={{
                        position: 'absolute',
                        top: '6px',
                        left: '6px',
                        right: '6px',
                        height: '100px',
                        borderRadius: '110px 110px 0 0',
                        background: 'linear-gradient(to bottom, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0) 100%)',
                        pointerEvents: 'none',
                        zIndex: 3
                      }}
                    />
                  </div>

                  {/* Render all 4 images with smooth opacity transitions and automatic switching on mobile */}
                  {teacherImages.map((imgSrc, idx) => (
                    <img 
                      key={idx}
                      src={imgSrc} 
                      alt="الأستاذ أحمد عادل - الهضبة"
                      className={`pose-img-${idx} ${teacherPoseIdx === idx ? 'pose-active' : 'pose-inactive'}`}
                      style={{
                        height: '250px',
                        width: 'auto',
                        maxWidth: '120%',
                        objectFit: 'contain',
                        zIndex: 4,
                        position: 'absolute',
                        bottom: 0,
                        left: '50%',
                        transform: 'translateX(-50%)',
                        transition: 'opacity 0.5s ease, transform 0.5s ease',
                        opacity: teacherPoseIdx === idx ? 1 : 0,
                        pointerEvents: teacherPoseIdx === idx ? 'auto' : 'none',
                      }}
                    />
                  ))}
                </div>
              </div>
              
              {/* SCROLL DOWN INDICATOR BUTTON (desktop layout only) */}
              <button className="hero-scroll-down-btn" onClick={handleScrollToCourses} title="انتقل للمحاضرات">
                <span className="material-symbols-outlined">keyboard_double_arrow_down</span>
              </button>
            </div>

            {/* Main Content Layout: Courses Ribbon & Progress Sidebar */}
            <div style={{ display: 'flex', gap: '28px', flexWrap: 'wrap', width: '100%', direction: 'rtl', marginTop: '24px' }}>
              
              {/* Right Column: Courses (flex: 2.2) */}
              <div style={{ flex: '2.2', minWidth: '320px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
                <h3 className="title-small" style={{ marginBottom: '4px', fontWeight: '800' }}>المقررات الدراسية المتاحة</h3>
                
                {courses.length === 0 ? (
                  <p className="body-medium text-center" style={{ padding: '40px', background: 'rgba(20, 20, 25, 0.4)', borderRadius: '16px', border: '1px solid rgba(255,255,255,0.03)' }}>
                    لا توجد مقررات دراسية متاحة حالياً.
                  </p>
                ) : (
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(270px, 1fr))', gap: '20px' }}>
                    {courses.map(course => {
                      const isEnrolled = enrolledIds.has(course.id);
                      return (
                        <div
                          key={course.id}
                          className="premium-course-card flex flex-col justify-between"
                          onClick={() => onSelectCourse(course.id)}
                          style={{
                            borderRadius: '16px',
                            padding: '16px',
                            transition: 'transform 0.2s, box-shadow 0.2s',
                            cursor: 'pointer'
                          }}
                        >
                          <div>
                            <div style={{ position: 'relative', height: '160px', overflow: 'hidden', borderRadius: '12px', marginBottom: '14px', background: 'rgb(var(--surface-dim))' }}>
                              {/* Price / Enrolled Badge */}
                              <div style={{
                                position: 'absolute',
                                top: '10px',
                                right: '10px',
                                backgroundColor: isEnrolled ? 'rgb(var(--primary))' : (course.is_free ? 'rgb(var(--primary))' : 'rgba(20, 20, 22, 0.85)'),
                                color: '#fff',
                                padding: '4px 12px',
                                borderRadius: '20px',
                                fontSize: '11px',
                                fontWeight: 'bold',
                                zIndex: 3,
                                boxShadow: '0 2px 8px rgba(0,0,0,0.3)',
                                border: !isEnrolled && !course.is_free ? '1px solid rgba(255,255,255,0.12)' : 'none'
                              }}>
                                {isEnrolled ? 'معي' : (course.is_free ? 'مجاني' : `${course.reference_price || 0} ج.م`)}
                              </div>
                              {course.cover_image || course.cover_url ? (
                                <img src={course.cover_image || course.cover_url} alt={course.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                              ) : (
                                <div style={{ width: '100%', height: '100%', position: 'relative', overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                  <img src={teacherHero} alt="صورة تعبيرية" style={{ width: '100%', height: '100%', objectFit: 'cover', opacity: '0.45', objectPosition: 'top center' }} />
                                  <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle, rgba(16, 185, 129, 0.2) 0%, rgb(var(--surface)) 100%)' }} />
                                  <span className="icon" style={{ fontSize: '32px', color: 'rgb(var(--primary))', zIndex: 1 }}>school</span>
                                </div>
                              )}
                            </div>
                            <h4 className="body-large" style={{ fontWeight: '800', color: 'rgb(var(--on-surface))', marginBottom: '6px', fontSize: '15px' }}>{course.title}</h4>
                            <p className="body-small" style={{ marginBottom: '12px', color: '#CCCCCC', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden', textOverflow: 'ellipsis', height: '34px', lineHeight: '1.4' }}>{course.description || 'شرح شامل للمقرر الدراسي بكل تفاصيله'}</p>
                          </div>

                          <div className="flex items-center justify-between" style={{ borderTop: '1px solid rgb(var(--outline) / 0.1)', paddingTop: '12px', marginTop: '8px' }}>
                            {isEnrolled ? (
                              <button
                                className="btn btn-primary"
                                onClick={(e) => { e.stopPropagation(); onSelectCourse(course.id); }}
                                style={{
                                  padding: '8px 20px',
                                  borderRadius: '8px',
                                  fontSize: '11px',
                                  fontWeight: 'bold',
                                  backgroundColor: 'rgb(var(--primary))',
                                  color: '#fff',
                                  border: 'none',
                                  boxShadow: '0 4px 10px rgba(16, 185, 129, 0.3)',
                                  cursor: 'pointer'
                                }}
                              >
                                ابدأ الدراسة
                              </button>
                            ) : (
                              <button
                                className="btn"
                                style={{
                                  backgroundColor: 'rgba(255, 255, 255, 0.05)',
                                  color: '#E6E6E6',
                                  border: '1px solid rgba(255, 255, 255, 0.12)',
                                  padding: '8px 20px',
                                  borderRadius: '8px',
                                  fontSize: '11px',
                                  fontWeight: 'bold',
                                  cursor: 'pointer',
                                  transition: 'all 0.2s ease'
                                }}
                                onMouseEnter={(e) => {
                                  e.currentTarget.style.backgroundColor = 'rgba(16, 185, 129, 0.08)';
                                  e.currentTarget.style.borderColor = 'rgb(var(--primary))';
                                  e.currentTarget.style.color = '#fff';
                                }}
                                onMouseLeave={(e) => {
                                  e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.05)';
                                  e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.12)';
                                  e.currentTarget.style.color = '#E6E6E6';
                                }}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  if (!profile) {
                                    alert('هذا المحتوى يتطلب تسجيل الدخول والاشتراك.');
                                    onShowAuth?.();
                                    return;
                                  }
                                  setSelectedCourseForRedeem(course);
                                  setShowRedeemModal(true);
                                }}
                              >
                                <span className="icon" style={{ fontSize: '13px', marginLeft: '4px' }}>vpn_key</span>
                                تفعيل مقرر
                              </button>
                            )}
                            <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#CCCCCC' }}>{course.lessons_count || 0} محاضرة</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Left Column: Continue Your Journey Sidebar (flex: 1) */}
            <div style={{ flex: '1', minWidth: '270px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <h3 className="title-small" style={{ marginBottom: '4px', fontWeight: '800', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span className="material-symbols-outlined animate-pulse" style={{ color: 'rgb(var(--primary))', fontSize: '20px' }}>ads_click</span>
                كمل اللي باقي لك
              </h3>
              
              <div 
                className="card bento-card-glass" 
                style={{ 
                  width: '100%', 
                  padding: '20px', 
                  borderRadius: '16px', 
                  border: '1px solid rgb(var(--outline) / 0.1)', 
                  background: 'rgb(var(--surface-container-low))', 
                  backdropFilter: 'blur(10px)',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '16px'
                }}
              >
                {trackedCourses.length === 0 ? (
                  <div style={{ textAlign: 'center', padding: '24px 12px' }}>
                    <span className="material-symbols-outlined" style={{ fontSize: '32px', color: 'rgb(var(--on-surface-variant))', marginBottom: '8px' }}>school</span>
                    <p style={{ fontSize: '12px', color: 'rgb(var(--on-surface-variant))', lineHeight: '1.6', margin: 0 }}>
                      لم تشترك في أي مقررات دراسية بعد. تصفّح المقررات المتاحة لتبدأ رحلتك!
                    </p>
                  </div>
                ) : (
                  trackedCourses.map((course) => {
                    const courseDetails = enrolledCoursesDetails.find(d => d.id === course.id);
                    
                    if (!courseDetails) {
                      return (
                        <div key={course.id} style={{ display: 'flex', flexDirection: 'column', gap: '8px', paddingBottom: '12px', borderBottom: '1px solid rgb(var(--outline) / 0.1)' }}>
                          <div className="premium-skeleton-card" style={{ height: '14px', width: '75%', borderRadius: '4px' }} />
                          <div className="premium-skeleton-card" style={{ height: '36px', width: '100%', borderRadius: '8px', marginTop: '6px' }} />
                        </div>
                      );
                    }

                    const lessons = courseDetails.lessons || [];
                    if (lessons.length === 0) {
                      return (
                        <div key={course.id} style={{ paddingBottom: '12px', borderBottom: '1px solid rgb(var(--outline) / 0.1)' }}>
                          <span style={{ fontSize: '13px', fontWeight: 'bold', color: 'rgb(var(--on-surface))', display: 'block', marginBottom: '4px' }}>{course.title}</span>
                          <span style={{ fontSize: '11px', color: 'rgb(var(--on-surface-variant))' }}>لا توجد محاضرات مرفوعة في هذا مقرر حالياً.</span>
                        </div>
                      );
                    }

                    // Find where student stands using playbackLogs
                    const courseLogs = playbackLogs.filter((log: any) => log.course_id === course.id);
                    const sortedLogs = [...courseLogs].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
                    const latestLog = sortedLogs[0];

                    let lastWatchedIndex = -1;
                    if (latestLog) {
                      lastWatchedIndex = lessons.findIndex((l: any) => l.id === latestLog.lesson_id);
                    }

                    const hasStarted = lastWatchedIndex !== -1;
                    const watchedCount = hasStarted ? lastWatchedIndex + 1 : 0;
                    const progressPercent = Math.round((watchedCount / lessons.length) * 100);
                    const isCompleted = watchedCount === lessons.length;
                    
                    // The next lesson they should watch is the one immediately after the last watched index
                    const nextLessons = lessons.slice(watchedCount);
                    const currentStandingLesson = hasStarted ? lessons[lastWatchedIndex] : null;

                    const radius = 18;
                    const circumference = 2 * Math.PI * radius;
                    const strokeDashoffset = circumference - (progressPercent / 100) * circumference;

                    return (
                      <div key={course.id} style={{ display: 'flex', flexDirection: 'column', gap: '12px', paddingBottom: '16px', borderBottom: '1px solid rgb(var(--outline) / 0.1)' }}>
                        {/* Course Header Info with Circular Progress */}
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '12px' }}>
                          <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', flex: 1, textAlign: 'right' }}>
                            <span style={{ fontSize: '13px', fontWeight: '800', color: 'rgb(var(--on-surface))' }}>{course.title}</span>
                            <span style={{ fontSize: '10px', color: 'rgb(var(--on-surface-variant))' }}>
                              تم إكمال {watchedCount} من {lessons.length} محاضرة
                            </span>
                          </div>
                          
                          {/* Circular SVG Progress Ring */}
                          <div style={{ position: 'relative', width: '42px', height: '42px', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                            <svg width="42" height="42" style={{ transform: 'rotate(-90deg)' }}>
                              {/* Background circle */}
                              <circle
                                cx="21"
                                cy="21"
                                r={radius}
                                fill="transparent"
                                stroke="rgba(255, 255, 255, 0.05)"
                                strokeWidth="3"
                              />
                              {/* Active progress circle */}
                              <circle
                                cx="21"
                                cy="21"
                                r={radius}
                                fill="transparent"
                                stroke="rgb(var(--primary))"
                                strokeWidth="3"
                                strokeDasharray={circumference}
                                strokeDashoffset={strokeDashoffset}
                                strokeLinecap="round"
                                style={{ transition: 'stroke-dashoffset 0.5s ease-in-out', filter: 'drop-shadow(0 0 3px rgba(16, 185, 129, 0.4))' }}
                              />
                            </svg>
                            <span style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', fontSize: '9px', fontWeight: 'bold', color: 'rgb(var(--on-surface))' }}>
                              {progressPercent}%
                            </span>
                          </div>
                        </div>

                        {/* Current standing (أنت هنا) */}
                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', background: 'rgb(var(--surface-bright))', padding: '8px 12px', borderRadius: '8px', border: '1px solid rgb(var(--outline) / 0.1)' }}>
                          <span className="material-symbols-outlined" style={{ fontSize: '16px', color: hasStarted ? '#10b981' : '#f59e0b' }}>
                            {hasStarted ? 'check_circle' : 'hourglass_empty'}
                          </span>
                          <div style={{ display: 'flex', flexDirection: 'column', gap: '1px', textAlign: 'right' }}>
                            <span style={{ fontSize: '9px', color: 'rgb(var(--on-surface-variant))' }}>آخر محاضرة تم مشاهدتها:</span>
                            <span style={{ fontSize: '11px', color: 'rgb(var(--on-surface))', fontWeight: 'bold' }}>
                              {currentStandingLesson ? currentStandingLesson.title : 'لم تبدأ مشاهدة المقرر بعد'}
                            </span>
                          </div>
                        </div>

                        {/* Next lessons remaining */}
                        {isCompleted ? (
                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', backgroundColor: 'rgba(16, 185, 129, 0.08)', padding: '8px 12px', borderRadius: '8px', border: '1px solid rgba(16, 185, 129, 0.2)' }}>
                            <span className="material-symbols-outlined" style={{ fontSize: '18px', color: '#10b981' }}>workspace_premium</span>
                            <span style={{ fontSize: '11px', color: '#10b981', fontWeight: 'bold' }}>أحسنت! أكملت جميع المحاضرات المتاحة حالياً 🏆</span>
                          </div>
                        ) : (
                          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                            <span style={{ fontSize: '10px', color: 'rgb(var(--on-surface-variant))', textAlign: 'right', fontWeight: 'bold' }}>المحاضرات المتبقية لتصل لآخر التحديثات:</span>
                            
                            {/* List next remaining lessons */}
                            {nextLessons.slice(0, 3).map((lesson: any) => (
                              <div 
                                key={lesson.id}
                                onClick={() => {
                                  if (onSelectLesson) {
                                    onSelectLesson(lesson.id, lesson.title, lesson.type, lesson.is_free, course.id);
                                  }
                                }}
                                style={{
                                  display: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'space-between',
                                  padding: '8px 10px',
                                  borderRadius: '8px',
                                  background: 'rgb(var(--surface-bright))',
                                  border: '1px solid rgb(var(--outline) / 0.08)',
                                  cursor: 'pointer',
                                  transition: 'all 0.2s ease'
                                }}
                                onMouseEnter={(e) => {
                                  e.currentTarget.style.background = 'rgba(var(--primary), 0.08)';
                                  e.currentTarget.style.borderColor = 'rgba(var(--primary), 0.2)';
                                }}
                                onMouseLeave={(e) => {
                                  e.currentTarget.style.background = 'rgb(var(--surface-bright))';
                                  e.currentTarget.style.borderColor = 'rgb(var(--outline) / 0.08)';
                                }}
                              >
                                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                  <span className="material-symbols-outlined" style={{ fontSize: '14px', color: 'rgb(var(--on-surface-variant))' }}>
                                    {lesson.type === 'video' ? 'play_circle' : 'description'}
                                  </span>
                                  <span style={{ fontSize: '11px', color: 'rgb(var(--on-surface))', fontWeight: '600', maxWidth: '160px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                    {lesson.title}
                                  </span>
                                </div>
                                <span style={{ fontSize: '9px', color: 'rgb(var(--primary))', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '2px' }}>
                                  ابدأ الآن
                                  <span className="material-symbols-outlined" style={{ fontSize: '10px' }}>arrow_back</span>
                                </span>
                              </div>
                            ))}

                            {nextLessons.length > 3 && (
                              <span style={{ fontSize: '9px', color: '#888', textAlign: 'center', display: 'block', marginTop: '2px' }}>
                                + ويتبقى {nextLessons.length - 3} محاضرات أخرى لتكمل المقرر بالكامل
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </div>

          </div>


        </div>
      )}

        {/* ── TAB 2: EXPLORE TAB ── */}
        {activeTab === 'explore' && (
          <div className="flex flex-col gap-lg">
            <h2 className="title-medium">استكشف جميع الدورات</h2>
            
            {/* Search and Filters */}
            <div className="flex gap-md" style={{ flexWrap: 'wrap' }}>
              <div className="input-container" style={{ flex: 1, minWidth: '250px' }}>
                <input
                  type="text"
                  className="input-text"
                  placeholder="ابحث عن دورة تعليمية..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                />
                <span className="icon input-icon-right">search</span>
              </div>
              <select
                className="select"
                style={{ width: '220px' }}
                value={gradeFilter}
                onChange={e => setGradeFilter(e.target.value)}
              >
                <option value="">جميع الصفوف الدراسية</option>
                <option value="الصف الأول الثانوي">الصف الأول الثانوي</option>
                <option value="الصف الثاني الثانوي">الصف الثاني الثانوي</option>
                <option value="الصف الثالث الثانوي">الصف الثالث الثانوي</option>
              </select>
            </div>

            {/* Courses grid */}
            {filteredExploreCourses.length === 0 ? (
              <p className="body-medium text-center" style={{ padding: '40px' }}>لا توجد كورسات تطابق معايير البحث.</p>
            ) : (
              <div className="grid-3 gap-md">
                {filteredExploreCourses.map(course => {
                  const isEnrolled = enrolledIds.has(course.id);
                  return (
                    <div
                      key={course.id}
                      className="premium-course-card flex flex-col justify-between"
                      onClick={() => onSelectCourse(course.id)}
                    >
                      <div>
                        <div style={{ position: 'relative', height: '160px', overflow: 'hidden', borderRadius: '10px', marginBottom: '12px', background: 'rgb(var(--surface-dim))' }}>
                          {/* Price Badge */}
                          <div style={{
                            position: 'absolute',
                            top: '10px',
                            right: '10px',
                            backgroundColor: course.is_free ? 'rgba(16, 185, 129, 0.9)' : 'rgba(var(--primary), 0.9)',
                            color: '#fff',
                            padding: '4px 10px',
                            borderRadius: '20px',
                            fontSize: '11px',
                            fontWeight: 'bold',
                            zIndex: 3,
                            boxShadow: '0 2px 8px rgba(0,0,0,0.3)'
                          }}>
                            {course.is_free ? 'مجاني' : `${course.reference_price || 0} ج.م`}
                          </div>
                          {course.cover_image || course.cover_url ? (
                            <img src={course.cover_image || course.cover_url} alt={course.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                          ) : (
                            <div style={{ width: '100%', height: '100%', position: 'relative', overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                              <img src={teacherHero} alt="صورة تعبيرية" style={{ width: '100%', height: '100%', objectFit: 'cover', opacity: '0.45', objectPosition: 'top center' }} />
                              <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle, rgba(var(--primary), 0.2) 0%, rgb(var(--surface)) 100%)' }} />
                              <span className="icon" style={{ fontSize: '32px', color: 'rgb(var(--primary))', zIndex: 1 }}>school</span>
                            </div>
                          )}
                          <div className="play-overlay-container">
                            <div className="play-button-pill">
                              <span className="icon" style={{ color: '#fff', fontSize: '24px', marginRight: '-2px' }}>play_arrow</span>
                            </div>
                          </div>
                        </div>
                        <h4 className="body-large" style={{ fontWeight: '800', color: 'rgb(var(--on-surface))', marginBottom: '6px', fontSize: '15px' }}>{course.title}</h4>
                        <p className="body-small" style={{ marginBottom: '12px', color: 'rgb(var(--on-surface-variant))' }}>{course.description || 'شرح شامل للمقرر الدراسي'}</p>
                      </div>

                      <div className="flex items-center justify-between" style={{ borderTop: '1px solid rgb(var(--outline) / 0.1)', paddingTop: '10px', marginTop: '6px' }}>
                        {isEnrolled ? (
                          <button
                            className="btn btn-secondary"
                            onClick={(e) => { e.stopPropagation(); onSelectCourse(course.id); }}
                            style={{
                              padding: '8px 16px',
                              borderRadius: '8px',
                              fontSize: '12px',
                              fontWeight: 'bold',
                            }}
                          >
                            مفتوح (ابدأ الدراسة)
                          </button>
                        ) : (
                          <button
                            className="btn"
                            style={{
                              backgroundColor: 'rgb(var(--primary))',
                              color: '#fff',
                              border: 'none',
                              padding: '8px 16px',
                              borderRadius: '8px',
                              fontSize: '12px',
                              fontWeight: 'bold',
                              boxShadow: '0 4px 10px rgba(var(--primary), 0.3)'
                            }}
                            onClick={(e) => {
                              e.stopPropagation();
                              if (!profile) {
                                alert('هذا المحتوى يتطلب تسجيل الدخول والاشتراك.');
                                onShowAuth?.();
                                return;
                              }
                              setSelectedCourseForRedeem(course);
                              setShowRedeemModal(true);
                            }}
                          >
                            <span className="icon" style={{ fontSize: '14px', marginLeft: '4px' }}>vpn_key</span>
                            تفعيل
                          </button>
                        )}
                        <span style={{ fontSize: '12px', fontWeight: 'bold', color: 'rgb(var(--on-surface-variant))' }}>{course.lessons_count || 0} محاضرة</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ── TAB 3: MY COURSES TAB ── */}
        {activeTab === 'my-courses' && (
          <div className="flex flex-col gap-lg">
            <h2 className="title-medium">مقرراتي الدراسية المفعّلة</h2>
            
            {myCourses.length === 0 ? (
              <div className="card text-center" style={{ padding: '60px' }}>
                <span className="icon" style={{ fontSize: '56px', color: 'rgb(var(--on-surface-variant))', marginBottom: '16px' }}>school</span>
                <p className="body-large" style={{ fontWeight: 'bold' }}>لم تشترك في أي مقرر بعد.</p>
                <p className="body-small" style={{ marginBottom: '24px' }}>قم بتفعيل مقرر دراسي باستخدام الكود لتتمكن من البدء.</p>
                <button className="btn btn-primary" onClick={() => setShowRedeemModal(true)}>تفعيل كود</button>
              </div>
            ) : (
              <div className="grid-3 gap-md">
                {myCourses.map(course => (
                  <div
                    key={course.id}
                    className="premium-course-card flex flex-col justify-between"
                    onClick={() => onSelectCourse(course.id)}
                  >
                    <div>
                      <div style={{ position: 'relative', height: '160px', overflow: 'hidden', borderRadius: '10px', marginBottom: '12px', background: 'rgb(var(--surface-dim))' }}>
                        {course.cover_image || course.cover_url ? (
                          <img src={course.cover_image || course.cover_url} alt={course.title} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                        ) : (
                          <div style={{ width: '100%', height: '100%', position: 'relative', overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                            <img src={teacherHero} alt="صورة تعبيرية" style={{ width: '100%', height: '100%', objectFit: 'cover', opacity: '0.45', objectPosition: 'top center' }} />
                            <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle, rgba(var(--primary), 0.2) 0%, rgb(var(--surface)) 100%)' }} />
                            <span className="icon" style={{ fontSize: '32px', color: 'rgb(var(--primary))', zIndex: 1 }}>school</span>
                          </div>
                        )}
                        <div className="play-overlay-container">
                          <div className="play-button-pill">
                            <span className="icon" style={{ color: '#fff', fontSize: '24px', marginRight: '-2px' }}>play_arrow</span>
                          </div>
                        </div>
                      </div>
                      <h4 className="body-large" style={{ fontWeight: '800', color: 'rgb(var(--on-surface))', marginBottom: '6px', fontSize: '15px' }}>{course.title}</h4>
                      <p className="body-small" style={{ marginBottom: '12px', color: 'rgb(var(--on-surface-variant))' }}>{course.description || 'كورس شرح وتدريبات المنهج بالكامل'}</p>
                    </div>

                    <div style={{ marginTop: '12px', borderTop: '1px solid rgb(var(--outline) / 0.1)', paddingTop: '10px' }}>
                      <div className="flex justify-between" style={{ fontSize: '11px', marginBottom: '6px', fontWeight: 'bold' }}>
                        <span>نسبة الإنجاز</span>
                        <span style={{ color: '#10b981' }}>مفعّل للدراسة</span>
                      </div>
                      <div style={{ height: '6px', backgroundColor: 'rgb(var(--surface-dim))', borderRadius: '3px', overflow: 'hidden' }}>
                        <div style={{ height: '100%', width: '100%', backgroundColor: 'rgb(var(--primary))' }}></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ── TAB 6: EXAMS TAB ── */}
        {activeTab === 'exams' && (
          <div className="flex flex-col gap-xl" style={{ direction: 'rtl' }}>
            <div>
              <h2 className="title-medium" style={{ color: '#fff', fontWeight: '800', marginBottom: '6px' }}>الامتحانات العامة والتقييمات 📝</h2>
              <p className="body-medium" style={{ color: 'rgb(var(--on-surface-variant))', fontSize: '13px' }}>
                هنا تجد كافة الامتحانات الشاملة والتقييمات الدورية الخاصة بالمقررات التي تشترك بها.
              </p>
            </div>

            {exams.length === 0 ? (
              <div className="card flex flex-col items-center justify-center" style={{ padding: '60px 24px', textAlign: 'center', background: 'rgba(255,255,255,0.01)', border: '1px dashed rgba(255,255,255,0.08)', borderRadius: '16px' }}>
                <span className="icon" style={{ fontSize: '48px', color: 'rgb(var(--on-surface-variant))', marginBottom: '16px' }}>assignment_late</span>
                <h3 style={{ fontSize: '16px', fontWeight: '700', color: '#fff', marginBottom: '8px' }}>لا توجد امتحانات متاحة حالياً</h3>
                <p style={{ fontSize: '13px', color: 'rgb(var(--on-surface-variant))', maxWidth: '360px', margin: '0 auto' }}>
                  بمجرد قيام المدرس برفع امتحانات عامة للمقررات المشترك بها، ستظهر لك هنا مباشرة للحل والتقييم.
                </p>
              </div>
            ) : (
              <div className="grid-2 gap-lg">
                {exams.map((exam: any) => {
                  const hasAttempt = exam.student_score !== null && exam.student_score !== undefined;
                  const scorePercentage = hasAttempt ? ((exam.student_score / exam.max_score) * 100).toFixed(0) : '0';
                  const isPassed = hasAttempt && parseInt(scorePercentage) >= 50;

                  return (
                    <div
                      key={exam.id}
                      className="card flex flex-col justify-between"
                      style={{
                        background: 'linear-gradient(145deg, rgba(255, 255, 255, 0.03) 0%, rgba(255, 255, 255, 0.01) 100%)',
                        border: '1px solid rgba(255, 255, 255, 0.05)',
                        borderRadius: '16px',
                        padding: '24px',
                        transition: 'all 0.3s ease',
                        boxShadow: '0 8px 30px rgba(0,0,0,0.2)'
                      }}
                    >
                      <div>
                        <div className="flex justify-between items-start" style={{ marginBottom: '12px' }}>
                          <span className="badge" style={{ backgroundColor: 'rgba(var(--primary), 0.08)', color: 'rgb(var(--primary))', border: '1px solid rgba(var(--primary), 0.15)', fontSize: '11px', padding: '4px 10px', borderRadius: '6px' }}>
                            {exam.course_title}
                          </span>
                          
                          {hasAttempt ? (
                            <span className="badge" style={{ backgroundColor: isPassed ? 'rgba(16,185,129,0.1)' : 'rgba(239,68,68,0.1)', color: isPassed ? '#10b981' : 'rgb(var(--error))', border: `1px solid ${isPassed ? 'rgba(16,185,129,0.2)' : 'rgba(239,68,68,0.2)'}`, fontSize: '11px', padding: '4px 10px', borderRadius: '6px', display: 'flex', alignItems: 'center', gap: '4px' }}>
                              <span className="icon" style={{ fontSize: '14px' }}>{isPassed ? 'check_circle' : 'cancel'}</span>
                              تم الحل: {scorePercentage}%
                            </span>
                          ) : (
                            <span className="badge" style={{ backgroundColor: 'rgba(245,158,11,0.1)', color: '#f59e0b', border: '1px solid rgba(245,158,11,0.2)', fontSize: '11px', padding: '4px 10px', borderRadius: '6px', display: 'flex', alignItems: 'center', gap: '4px' }}>
                              <span className="status-dot answered" style={{ width: '6px', height: '6px', backgroundColor: '#f59e0b', boxShadow: '0 0 8px #f59e0b', marginLeft: 0 }} />
                              مطلوب حله
                            </span>
                          )}
                        </div>

                        <h3 style={{ fontSize: '16px', fontWeight: '800', color: '#fff', marginBottom: '8px', lineHeight: '1.5' }}>
                          {exam.title}
                        </h3>
                        <p style={{ fontSize: '12px', color: 'rgb(var(--on-surface-variant))', marginBottom: '20px' }}>
                          الدرجة الكلية للامتحان: <strong style={{ color: '#fff' }}>{exam.max_score} درجة</strong>
                        </p>
                      </div>

                      <div style={{ borderTop: '1px solid rgba(255,255,255,0.04)', paddingTop: '16px' }}>
                        {hasAttempt ? (
                          <div className="flex justify-between items-center">
                            <span style={{ fontSize: '12px', color: 'rgb(var(--on-surface-variant))' }}>
                              درجتك: <strong style={{ color: isPassed ? '#10b981' : 'rgb(var(--error))', fontSize: '14px' }}>{exam.student_score} / {exam.max_score}</strong>
                            </span>
                            <button
                              className="btn btn-secondary"
                              style={{ padding: '8px 16px', fontSize: '12px', borderRadius: '8px' }}
                              onClick={() => handleOpenExam(exam.id)}
                            >
                              عرض الإجابات
                            </button>
                          </div>
                        ) : (
                          <button
                            className="btn btn-primary w-full"
                            style={{ padding: '10px', fontSize: '13px', fontWeight: 'bold', borderRadius: '8px', boxShadow: '0 4px 12px rgba(var(--primary), 0.25)' }}
                            onClick={() => handleOpenExam(exam.id)}
                          >
                            بدء حل الامتحان الآن
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ── TAB 4: Q&A TAB ── */}
        {activeTab === 'qa' && (
          <div className="flex flex-col gap-lg">
            {/* Header section */}
            <div className="flex justify-between items-center flex-wrap gap-md" style={{ borderBottom: '1px solid rgba(255,255,255,0.06)', paddingBottom: '20px' }}>
              <div>
                <h2 className="title-medium" style={{ color: '#fff', fontWeight: '800', marginBottom: '6px' }}>منتدى الأسئلة والاستفسارات 💬</h2>
                <p className="body-medium" style={{ color: 'rgb(var(--on-surface-variant))', fontSize: '13px' }}>
                  اطرح أسئلتك بخصوص المنهج وسيجيبك الأستاذ المساعد وطاقم العمل في أسرع وقت.
                </p>
              </div>
              <button className="btn btn-primary" onClick={() => setShowAskModal(true)} style={{ borderRadius: '10px', boxShadow: '0 4px 15px rgba(var(--primary), 0.3)' }}>
                <span className="icon" style={{ marginLeft: '6px' }}>add</span>
                طرح سؤال جديد
              </button>
            </div>

            {/* Search & Filter Bar */}
            <div className="flex gap-md flex-wrap" style={{ width: '100%' }}>
              {/* Search */}
              <div className="form-group flex-1" style={{ minWidth: '260px' }}>
                <div style={{ position: 'relative', width: '100%' }}>
                  <input
                    type="text"
                    className="input-text"
                    placeholder="ابحث عن سؤال، درس، أو كلمة مفتاحية..."
                    value={qaSearch}
                    onChange={e => setQaSearch(e.target.value)}
                    style={{ paddingRight: '40px', borderRadius: '10px', backgroundColor: '#131316', border: '1px solid rgba(255,255,255,0.06)' }}
                  />
                  <span className="icon" style={{ position: 'absolute', right: '14px', top: '50%', transform: 'translateY(-50%)', color: 'rgb(var(--on-surface-variant))' }}>search</span>
                </div>
              </div>

              {/* Status Filters */}
              <div className="flex gap-xs" style={{ backgroundColor: '#131316', padding: '4px', borderRadius: '10px', border: '1px solid rgba(255,255,255,0.06)' }}>
                {[
                  { id: 'all', label: 'الكل' },
                  { id: 'answered', label: 'تمت الإجابة' },
                  { id: 'pending', label: 'قيد الانتظار' }
                ].map(filter => (
                  <button
                    key={filter.id}
                    onClick={() => setQaFilter(filter.id as any)}
                    className="btn"
                    style={{
                      padding: '8px 16px',
                      fontSize: '12px',
                      borderRadius: '8px',
                      border: 'none',
                      backgroundColor: qaFilter === filter.id ? 'rgb(var(--primary))' : 'transparent',
                      color: qaFilter === filter.id ? '#fff' : 'rgb(var(--on-surface-variant))',
                      fontWeight: qaFilter === filter.id ? 'bold' : 'normal',
                      minWidth: 0,
                      transition: 'all 0.2s'
                    }}
                  >
                    {filter.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Questions List */}
            {filteredQuestions.length === 0 ? (
              <div className="card flex flex-col items-center justify-center text-center" style={{ padding: '60px 20px', backgroundColor: '#131316', border: '1px solid rgba(255,255,255,0.04)' }}>
                <span className="icon text-primary animate-float" style={{ fontSize: '48px', color: 'rgb(var(--primary))', marginBottom: '16px' }}>forum</span>
                <h4 className="title-small" style={{ marginBottom: '8px', color: '#fff' }}>لم يتم العثور على استفسارات</h4>
                <p className="body-medium" style={{ color: 'rgb(var(--on-surface-variant))', maxWidth: '400px', margin: '0 auto 20px' }}>
                  {qaSearch ? 'لا توجد نتائج تطابق بحثك الحالي، جرب كلمات أخرى.' : 'كن أول من يطرح سؤالاً في هذا القسم وسنجيبك بالتفصيل!'}
                </p>
                {!qaSearch && (
                  <button className="btn btn-secondary" onClick={() => setShowAskModal(true)}>
                    طرح سؤال الآن
                  </button>
                )}
              </div>
            ) : (
              <div className="grid-2 gap-md" style={{ alignItems: 'stretch' }}>
                {filteredQuestions.map(q => {
                  const isUpvoted = upvotedQuestions.has(q.id);
                  const upvoteCount = (q.upvotes || 0) + (isUpvoted ? 1 : 0);
                  return (
                    <div
                      key={q.id}
                      className={`premium-qa-card ${q.status === 'answered' ? 'status-answered' : 'status-pending'}`}
                      onClick={() => handleOpenQuestionDetails(q.id)}
                    >
                      <div>
                        {/* Header: Date + Status Badge */}
                        <div className="flex justify-between items-center" style={{ marginBottom: '12px', flexWrap: 'wrap', gap: '8px' }}>
                          <div className="flex items-center gap-xs">
                            <span className="icon" style={{ fontSize: '14px', color: 'rgb(var(--on-surface-variant))' }}>schedule</span>
                            <span className="body-small" style={{ color: 'rgb(var(--on-surface-variant))', fontSize: '11px' }}>
                              {new Date(q.created_at).toLocaleDateString('ar-EG', { day: 'numeric', month: 'short', year: 'numeric' })}
                            </span>
                          </div>
                          <span
                            className="badge"
                            style={{
                              backgroundColor: q.status === 'answered' ? 'rgba(16,185,129,0.12)' : 'rgba(255,210,63,0.12)',
                              color: q.status === 'answered' ? '#10b981' : '#ffd23f',
                              border: q.status === 'answered' ? '1px solid rgba(16,185,129,0.2)' : '1px solid rgba(255,210,63,0.2)',
                              fontSize: '11px',
                              padding: '4px 10px',
                              borderRadius: '20px',
                              display: 'inline-flex',
                              alignItems: 'center',
                              gap: '2px'
                            }}
                          >
                            <span className={`status-dot ${q.status === 'answered' ? 'answered' : 'pending'}`} />
                            <span>{q.status === 'answered' ? 'تمت الإجابة' : 'قيد الانتظار'}</span>
                          </span>
                        </div>

                        {/* Lesson Title Context Badge */}
                        {q.lesson_title && (
                          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', backgroundColor: 'rgba(255,255,255,0.03)', padding: '4px 8px', borderRadius: '6px', marginBottom: '12px', border: '1px solid rgba(255,255,255,0.05)' }}>
                            <span className="icon" style={{ fontSize: '12px', color: 'rgb(var(--primary))' }}>play_circle</span>
                            <span style={{ fontSize: '10px', color: '#D1D5DB', fontWeight: 'bold' }}>درس: {q.lesson_title}</span>
                          </div>
                        )}

                        <p className="body-medium text-clamp-3" style={{ fontWeight: '700', lineHeight: '1.6', color: '#fff', fontSize: '14px', marginBottom: '16px' }}>
                          {q.body}
                        </p>
                      </div>

                      {/* Footer Actions */}
                      <div className="flex justify-between items-center" style={{ borderTop: '1px solid rgba(255,255,255,0.04)', paddingTop: '14px', marginTop: 'auto' }}>
                        
                        {/* Interactive Upvote Button */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            const next = new Set(upvotedQuestions);
                            if (next.has(q.id)) {
                              next.delete(q.id);
                            } else {
                              next.add(q.id);
                            }
                            setUpvotedQuestions(next);
                          }}
                          className="btn"
                          style={{
                            padding: '6px 12px',
                            borderRadius: '8px',
                            backgroundColor: isUpvoted ? 'rgba(var(--primary), 0.12)' : 'rgba(255,255,255,0.02)',
                            color: isUpvoted ? 'rgb(var(--primary))' : 'rgb(var(--on-surface-variant))',
                            border: isUpvoted ? '1px solid rgba(var(--primary), 0.25)' : '1px solid rgba(255,255,255,0.06)',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '6px',
                            fontSize: '11px',
                            minWidth: 0
                          }}
                        >
                          <span className="icon" style={{ fontSize: '14px' }}>thumb_up</span>
                          <span>أحتاج إجابة ({upvoteCount})</span>
                        </button>

                        <div className="flex items-center gap-xs" style={{ color: 'rgb(var(--on-surface-variant))', fontSize: '12px' }}>
                          <span className="icon" style={{ fontSize: '16px' }}>forum</span>
                          <span style={{ fontWeight: '500' }}>{q.answers_count || 0} ردود</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ── TAB 5: PROFILE TAB ── */}
        {activeTab === 'profile' && (
          <div className="flex flex-col gap-xl" style={{ direction: 'rtl' }}>
            
            {/* Redesigned Premium Profile Header */}
            <div
              className="card"
              style={{
                background: 'linear-gradient(145deg, rgba(255, 255, 255, 0.03) 0%, rgba(255, 255, 255, 0.01) 100%)',
                border: '1px solid rgba(255, 255, 255, 0.05)',
                borderRadius: '20px',
                padding: '32px 24px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                flexWrap: 'wrap',
                gap: '24px'
              }}
            >
              <div className="flex items-center gap-lg flex-wrap">
                {/* Avatar with Upload Trigger */}
                <div className="avatar-container">
                  <div
                    style={{
                      width: '110px',
                      height: '110px',
                      borderRadius: '50%',
                      overflow: 'hidden',
                      border: '3px solid rgb(var(--primary))',
                      boxShadow: '0 0 25px rgba(var(--primary), 0.25)',
                      backgroundColor: '#161619',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      position: 'relative'
                    }}
                  >
                    {avatarUrl ? (
                      <img src={avatarUrl} alt="صورة شخصية" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    ) : (
                      <span className="icon" style={{ fontSize: '48px', color: 'rgb(var(--primary))' }}>person</span>
                    )}
                    
                    {/* Hover Overlay for Camera Upload */}
                    <div className="avatar-overlay">
                      <span className="icon" style={{ color: '#fff', fontSize: '24px', marginBottom: '2px' }}>photo_camera</span>
                      <span style={{ fontSize: '9px', color: '#ccc', fontWeight: 'bold' }}>تغيير الصورة</span>
                    </div>
                  </div>
                  
                  {/* File Input */}
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleAvatarChange}
                    style={{
                      position: 'absolute',
                      inset: 0,
                      opacity: 0,
                      cursor: 'pointer',
                      zIndex: 3
                    }}
                    disabled={isUploadingAvatar}
                  />

                  {/* Uploading Spinner */}
                  {isUploadingAvatar && (
                    <div style={{ position: 'absolute', inset: 0, backgroundColor: 'rgba(0,0,0,0.7)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 4 }}>
                      <span className="icon animate-spin" style={{ color: 'rgb(var(--primary))', fontSize: '28px' }}>sync</span>
                    </div>
                  )}
                </div>

                <div>
                  <h2 style={{ fontSize: '22px', fontWeight: '800', color: '#fff', marginBottom: '6px' }}>
                    {profile?.full_name}
                  </h2>
                  <p style={{ fontSize: '13px', color: 'rgb(var(--on-surface-variant))', marginBottom: '12px', fontWeight: 'bold' }}>
                    {profile?.phone}
                  </p>
                  <div className="flex gap-sm flex-wrap">
                    <span className="badge" style={{ backgroundColor: 'rgba(var(--primary), 0.1)', color: 'rgb(var(--primary))', border: '1px solid rgba(var(--primary), 0.25)', fontSize: '11px', padding: '4px 12px', borderRadius: '20px' }}>
                      {profile?.grade}
                    </span>
                    <span className="badge" style={{ backgroundColor: 'rgba(255,255,255,0.03)', color: '#ccc', border: '1px solid rgba(255,255,255,0.06)', fontSize: '11px', padding: '4px 12px', borderRadius: '20px' }}>
                      {profile?.governorate}
                    </span>
                    <span className="badge" style={{ backgroundColor: 'rgba(16, 185, 129, 0.1)', color: '#10b981', border: '1px solid rgba(16, 185, 129, 0.2)', fontSize: '11px', padding: '4px 12px', borderRadius: '20px', display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
                      <span className="status-dot answered" style={{ width: '5px', height: '5px', marginLeft: 0 }} />
                      حساب نشط
                    </span>
                  </div>
                </div>
              </div>

              {/* Quick Info Block */}
              <div className="flex gap-md hide-mobile">
                <div style={{ backgroundColor: 'rgba(255,255,255,0.02)', padding: '12px 20px', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.04)', textAlign: 'center' }}>
                  <span style={{ fontSize: '10px', color: 'rgb(var(--on-surface-variant))', display: 'block', marginBottom: '2px' }}>المحاضرات</span>
                  <span style={{ fontSize: '20px', fontWeight: '800', color: '#fff' }}>{stats.coursesCount}</span>
                </div>
                <div style={{ backgroundColor: 'rgba(255,255,255,0.02)', padding: '12px 20px', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.04)', textAlign: 'center' }}>
                  <span style={{ fontSize: '10px', color: 'rgb(var(--on-surface-variant))', display: 'block', marginBottom: '2px' }}>الامتحانات</span>
                  <span style={{ fontSize: '20px', fontWeight: '800', color: '#fff' }}>{stats.quizzesCount}</span>
                </div>
              </div>
            </div>

            <div className="grid-2 gap-lg" style={{ alignItems: 'start' }}>
              {/* Profile Edit Form */}
              <div className="card">
                <h3 className="title-small" style={{ marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span className="icon" style={{ color: 'rgb(var(--primary))' }}>manage_accounts</span>
                  تعديل البيانات الشخصية
                </h3>
                <form onSubmit={handleUpdateProfile} className="flex flex-col gap-md">
                  <div className="form-group">
                    <label className="form-label">الاسم بالكامل</label>
                    <input type="text" className="input-text" value={editName} onChange={e => setEditName(e.target.value)} required style={{ borderRadius: '10px', backgroundColor: '#131316', border: '1px solid rgba(255,255,255,0.06)' }} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">رقم الهاتف الشخصي</label>
                    <input type="tel" className="input-text" value={editPhone} onChange={e => setEditPhone(e.target.value)} required style={{ borderRadius: '10px', backgroundColor: '#131316', border: '1px solid rgba(255,255,255,0.06)' }} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">رقم ولي الأمر</label>
                    <input type="tel" className="input-text" value={editParentPhone} onChange={e => setEditParentPhone(e.target.value)} required style={{ borderRadius: '10px', backgroundColor: '#131316', border: '1px solid rgba(255,255,255,0.06)' }} />
                  </div>
                  <div className="grid-2 gap-sm">
                    <div className="form-group">
                      <label className="form-label">المحافظة</label>
                      <select className="select" value={editGov} onChange={e => setEditGov(e.target.value)} style={{ borderRadius: '10px', backgroundColor: '#131316', border: '1px solid rgba(255,255,255,0.06)' }}>
                        {governorates.map(g => <option key={g} value={g}>{g}</option>)}
                      </select>
                    </div>
                    <div className="form-group">
                      <label className="form-label">المرحلة الدراسية</label>
                      <select className="select" value={editGrade} onChange={e => setEditGrade(e.target.value)} style={{ borderRadius: '10px', backgroundColor: '#131316', border: '1px solid rgba(255,255,255,0.06)' }}>
                        {grades.map(g => <option key={g} value={g}>{g}</option>)}
                      </select>
                    </div>
                  </div>
                  <button type="submit" className="btn btn-primary" disabled={updatingProfile} style={{ marginTop: '12px', borderRadius: '10px' }}>
                    {updatingProfile ? 'جاري الحفظ...' : 'حفظ التغييرات'}
                  </button>
                </form>
              </div>

              {/* Security & Linked Devices */}
              <div className="flex flex-col gap-lg">
                <div className="card">
                  <h3 className="title-small" style={{ marginBottom: '12px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span className="icon" style={{ color: 'rgb(var(--primary))' }}>devices</span>
                    الأجهزة المربوطة بالحساب
                  </h3>
                  <p className="body-small" style={{ marginBottom: '20px', lineHeight: '1.6' }}>
                    يسمح لك النظام بالدخول من جهازين فقط لضمان أمان حسابك.
                  </p>
                  
                  <div className="flex flex-col gap-sm">
                    {devices.length === 0 ? (
                      <p className="body-medium" style={{ color: 'rgb(var(--on-surface-variant))', fontStyle: 'italic' }}>لا توجد أجهزة مربوطة.</p>
                    ) : (
                      devices.map(dev => (
                        <div key={dev.id} className="card-flat flex justify-between items-center" style={{ padding: '12px', borderRadius: '10px', backgroundColor: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.04)' }}>
                          <div className="flex items-center gap-md">
                            <span className="icon" style={{ fontSize: '24px', color: 'rgb(var(--primary))' }}>laptop_mac</span>
                            <div>
                              <p className="body-medium" style={{ fontWeight: 'bold', color: '#fff', fontSize: '13px' }}>{dev.model || 'متصفح ويب'}</p>
                              <p className="body-small" style={{ fontSize: '10px' }}>رابط الجهاز: {dev.device_id.substring(0, 15)}...</p>
                            </div>
                          </div>
                          <button
                            className="btn btn-error"
                            style={{ padding: '6px 12px', fontSize: '11px', borderRadius: '8px' }}
                            onClick={() => handleUnbindDevice(dev.id)}
                          >
                            إلغاء الربط
                          </button>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* Device Reset Requests List */}
                <div className="card">
                  <h3 className="title-small" style={{ marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span className="icon" style={{ color: 'rgb(var(--primary))' }}>history</span>
                    طلبات إعادة تعيين الأجهزة
                  </h3>
                  <div className="flex flex-col gap-sm">
                    {resetRequests.length === 0 ? (
                      <p className="body-small" style={{ color: 'rgb(var(--on-surface-variant))', fontStyle: 'italic' }}>لا توجد طلبات سابقة.</p>
                    ) : (
                      resetRequests.map((req: any) => (
                        <div key={req.id} className="card-flat flex justify-between items-center" style={{ padding: '12px', borderRadius: '10px', backgroundColor: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.04)' }}>
                          <div>
                            <p className="body-medium" style={{ fontWeight: 'bold', color: '#fff', fontSize: '12px' }}>السبب: {req.reason}</p>
                            <span className="body-small" style={{ fontSize: '10px' }}>{new Date(req.created_at).toLocaleDateString('ar-EG')}</span>
                          </div>
                          <span
                            className={`badge`}
                            style={{
                              backgroundColor: req.status === 'approved' ? 'rgba(16,185,129,0.12)' : req.status === 'pending' ? 'rgba(245,158,11,0.12)' : 'rgba(239,68,68,0.12)',
                              color: req.status === 'approved' ? '#10b981' : req.status === 'pending' ? '#f59e0b' : '#ef4444',
                              border: req.status === 'approved' ? '1px solid rgba(16,185,129,0.2)' : req.status === 'pending' ? '1px solid rgba(245,158,11,0.2)' : '1px solid rgba(239,68,68,0.2)',
                              fontSize: '10px',
                              padding: '2px 8px',
                              borderRadius: '6px'
                            }}
                          >
                            {req.status === 'approved' ? 'تمت الموافقة' : req.status === 'pending' ? 'قيد الانتظار' : 'مرفوض'}
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Financial Transactions Log */}
            <div className="card">
              <h3 className="title-small" style={{ marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span className="icon" style={{ color: 'rgb(var(--primary))' }}>payments</span>
                سجل العمليات المالية وتفعيل الأكواد
              </h3>
              <div className="flex flex-col gap-sm">
                {financials.length === 0 ? (
                  <p className="body-small" style={{ color: 'rgb(var(--on-surface-variant))', fontStyle: 'italic' }}>لا توجد عمليات مسجلة.</p>
                ) : (
                  financials.map((fin: any) => (
                    <div key={fin.id} className="card-flat flex justify-between items-center" style={{ padding: '12px', borderRadius: '10px', backgroundColor: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.04)' }}>
                      <div>
                        <p className="body-medium" style={{ fontWeight: 'bold', color: '#fff', fontSize: '13px' }}>{fin.course_title || 'تفعيل مقرر'}</p>
                        <span className="body-small" style={{ fontSize: '10px' }}>{new Date(fin.created_at).toLocaleDateString('ar-EG')}</span>
                      </div>
                      <div className="flex flex-col items-end">
                        <span className="badge" style={{ backgroundColor: 'rgba(var(--primary), 0.1)', color: 'rgb(var(--primary))', border: '1px solid rgba(var(--primary), 0.2)', fontSize: '11px', padding: '2px 8px', borderRadius: '6px' }}>
                          {fin.amount > 0 ? `+${fin.amount}` : fin.amount} ج.م
                        </span>
                        {fin.code_string && <span style={{ fontSize: '10px', color: 'rgb(var(--on-surface-variant))', marginTop: '4px' }}>كود: {fin.code_string}</span>}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Quiz attempts scores */}
            <div className="card">
              <h3 className="title-small" style={{ marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span className="icon" style={{ color: 'rgb(var(--primary))' }}>grade</span>
                نتائج ودرجات الامتحانات والواجبات
              </h3>
              <div className="flex flex-col gap-sm">
                {quizzes.length === 0 ? (
                  <p className="body-small" style={{ color: 'rgb(var(--on-surface-variant))', fontStyle: 'italic' }}>لم يتم حل أي امتحانات بعد.</p>
                ) : (
                  quizzes.map((q: any) => {
                    const pct = ((q.score / q.max_score) * 100).toFixed(0);
                    return (
                      <div key={q.id} className="card-flat flex justify-between items-center" style={{ padding: '12px', borderRadius: '10px', backgroundColor: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.04)' }}>
                        <div>
                          <p className="body-medium" style={{ fontWeight: 'bold', color: '#fff', fontSize: '13px' }}>{q.quiz_title}</p>
                          <span className="body-small" style={{ fontSize: '10px' }}>{new Date(q.created_at).toLocaleDateString('ar-EG')}</span>
                        </div>
                        <div className="flex flex-col items-end">
                          <span style={{ fontWeight: 'bold', fontSize: '14px', color: parseInt(pct) >= 50 ? 'rgb(16, 185, 129)' : 'rgb(var(--primary))' }}>{pct}%</span>
                          <span style={{ fontSize: '10px', color: 'rgb(var(--on-surface-variant))' }}>{q.score} / {q.max_score}</span>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Playback Logs timeline */}
            <div className="card">
              <h3 className="title-small" style={{ marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span className="icon" style={{ color: 'rgb(var(--primary))' }}>history_edu</span>
                سجل مشاهدة المحاضرات والدورات
              </h3>
              <div className="flex flex-col gap-sm">
                {playbackLogs.length === 0 ? (
                  <p className="body-small" style={{ color: 'rgb(var(--on-surface-variant))', fontStyle: 'italic' }}>لا توجد مشاهدات مسجلة بعد.</p>
                ) : (
                  playbackLogs.map((log: any) => (
                    <div key={log.id} className="card-flat flex justify-between items-center" style={{ padding: '12px', borderRadius: '10px', backgroundColor: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.04)' }}>
                      <div>
                        <p className="body-medium" style={{ fontWeight: 'bold', color: '#fff', fontSize: '13px' }}>{log.lesson_title}</p>
                        <span className="body-small" style={{ fontSize: '10px' }}>{new Date(log.created_at).toLocaleString('ar-EG')}</span>
                      </div>
                      <span
                        className="badge"
                        style={{
                          backgroundColor: log.action === 'open' ? 'rgba(var(--primary), 0.1)' : 'rgba(255,255,255,0.04)',
                          color: log.action === 'open' ? 'rgb(var(--primary))' : '#ccc',
                          border: log.action === 'open' ? '1px solid rgba(var(--primary), 0.2)' : '1px solid rgba(255,255,255,0.06)',
                          fontSize: '10px',
                          padding: '4px 10px',
                          borderRadius: '6px'
                        }}
                      >
                        {log.action === 'open' ? 'بدء المشاهدة' : 'مغادرة المشاهدة'} ({log.position_seconds} ثانية)
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {/* ── Premium Platform Footer ── */}
        <footer 
          style={{ 
            marginTop: '48px', 
            paddingTop: '32px', 
            paddingBottom: '20px', 
            borderTop: '1px solid rgba(16, 185, 129, 0.12)', 
            display: 'flex', 
            justifyContent: 'space-between', 
            alignItems: 'center', 
            flexWrap: 'wrap', 
            gap: '24px',
            direction: 'rtl'
          }}
        >
          {/* Right Section: Brand & Description */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', maxWidth: '320px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <span className="icon" style={{ color: 'rgb(var(--primary))', fontSize: '24px' }}>school</span>
              <h3 style={{ fontSize: '15px', fontWeight: '900', color: '#fff', margin: 0, fontFamily: 'Cairo, sans-serif' }}>منصة الهضبة التعليمية</h3>
            </div>
            <p style={{ fontSize: '11px', color: '#B3B3B3', lineHeight: '1.6', margin: 0 }}>
              المنصة الرسمية للأستاذ أحمد عادل لشرح مادة الكيمياء للثانوية العامة بأحدث الطرق التفاعلية والامتحانات الذكية.
            </p>
          </div>

          {/* Left Section: Socials & Support Contact */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', alignItems: 'flex-start' }}>
            <span style={{ fontSize: '12px', fontWeight: '800', color: '#fff' }}>تواصل معنا للدعم والاستفسارات:</span>
            
            {/* Contact Actions Row */}
            <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
              {/* WhatsApp Button */}
              <a 
                href="https://wa.me/201034324951" 
                target="_blank" 
                rel="noopener noreferrer" 
                style={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  gap: '8px', 
                  backgroundColor: 'rgba(37, 211, 102, 0.08)', 
                  border: '1px solid rgba(37, 211, 102, 0.25)', 
                  padding: '8px 14px', 
                  borderRadius: '10px',
                  color: '#25D366',
                  fontSize: '12px',
                  fontWeight: 'bold',
                  textDecoration: 'none',
                  transition: 'all 0.2s'
                }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = 'rgba(37, 211, 102, 0.15)'}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'rgba(37, 211, 102, 0.08)'}
              >
                <svg width="16" height="16" fill="currentColor" viewBox="0 0 24 24" style={{ flexShrink: 0 }}>
                  <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.514 2.266 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.724-1.455L0 24zm6.79-11.667c.131-.232.024-.564-.04-.695-.36-.738-.813-1.625-.92-1.841-.085-.17-.17-.17-.255-.17-.074-.002-.153-.002-.23-.002-.305 0-.712.11-.986.379-.275.269-1.05.992-1.05 2.42 0 1.427 1.05 2.806 1.196 2.996.147.19 2.012 3.109 4.954 4.316.699.287 1.245.459 1.67.591.703.22 1.344.189 1.85.114.565-.084 1.737-.696 1.984-1.371.247-.674.247-1.253.173-1.372-.074-.118-.272-.189-.57-.336-.297-.147-1.737-.83-2.009-.926-.272-.097-.47-.147-.668.147-.197.294-.766.926-.939 1.118-.173.193-.347.218-.644.07-.297-.148-1.253-.448-2.387-1.427-.883-.76-1.479-1.7-1.652-1.994-.173-.294-.018-.453.13-.6 l.462-.519c.148-.19.197-.294.297-.49z"/>
                </svg>
                <span>الواتساب: 01034324951</span>
              </a>

              {/* Call Support Button */}
              <a 
                href="tel:01034324951" 
                style={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  gap: '8px', 
                  backgroundColor: 'rgba(16, 185, 129, 0.08)', 
                  border: '1px solid rgba(16, 185, 129, 0.25)', 
                  padding: '8px 14px', 
                  borderRadius: '10px',
                  color: 'rgb(var(--primary))',
                  fontSize: '12px',
                  fontWeight: 'bold',
                  textDecoration: 'none',
                  transition: 'all 0.2s'
                }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = 'rgba(16, 185, 129, 0.15)'}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'rgba(16, 185, 129, 0.08)'}
              >
                <span className="material-symbols-outlined" style={{ fontSize: '18px' }}>call</span>
                <span>اتصال هاتفي</span>
              </a>
            </div>

            {/* Social Media Links Row */}
            <div style={{ display: 'flex', gap: '14px', marginTop: '4px' }}>
              {/* Facebook */}
              <a 
                href="https://facebook.com" 
                target="_blank" 
                rel="noopener noreferrer" 
                style={{ color: 'rgb(var(--on-surface-variant))', textDecoration: 'none', display: 'flex', alignItems: 'center', transition: 'color 0.2s' }}
                onMouseEnter={(e) => e.currentTarget.style.color = '#1877f2'}
                onMouseLeave={(e) => e.currentTarget.style.color = 'rgb(var(--on-surface-variant))'}
                title="فيسبوك"
              >
                <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.84 3.44 8.87 8 9.8V15H8v-3h2V9.5C10 7.57 11.57 6 13.5 6H16v3h-2c-.55 0-1 .45-1 1v2h3v3h-3v6.95c4.56-.93 8-4.96 8-9.75z"/>
                </svg>
              </a>

              {/* YouTube */}
              <a 
                href="https://youtube.com" 
                target="_blank" 
                rel="noopener noreferrer" 
                style={{ color: 'rgb(var(--on-surface-variant))', textDecoration: 'none', display: 'flex', alignItems: 'center', transition: 'color 0.2s' }}
                onMouseEnter={(e) => e.currentTarget.style.color = '#ff0000'}
                onMouseLeave={(e) => e.currentTarget.style.color = 'rgb(var(--on-surface-variant))'}
                title="يوتيوب"
              >
                <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M23.498 6.163a3.003 3.003 0 0 0-2.11-2.11C19.518 3.545 12 3.545 12 3.545s-7.518 0-9.388.508a3.003 3.003 0 0 0-2.11 2.11C0 8.033 0 12 0 12s0 3.967.502 5.837a3.003 3.003 0 0 0 2.11 2.11c1.87.508 9.388.508 9.388.508s7.518 0 9.388-.508a3.003 3.003 0 0 0 2.11-2.11C24 15.967 24 12 24 12s0-3.967-.502-5.837zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                </svg>
              </a>

              {/* Telegram */}
              <a 
                href="https://telegram.org" 
                target="_blank" 
                rel="noopener noreferrer" 
                style={{ color: 'rgb(var(--on-surface-variant))', textDecoration: 'none', display: 'flex', alignItems: 'center', transition: 'color 0.2s' }}
                onMouseEnter={(e) => e.currentTarget.style.color = '#0088cc'}
                onMouseLeave={(e) => e.currentTarget.style.color = 'rgb(var(--on-surface-variant))'}
                title="تليجرام"
              >
                <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 0 0-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.37.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .24z"/>
                </svg>
              </a>
            </div>
          </div>
        </footer>
      </main>

      {/* ── Ask a Question Modal ── */}
      {showAskModal && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ padding: '24px' }}>
            <h3 className="title-small" style={{ marginBottom: '16px' }}>طرح سؤال جديد</h3>
            <form onSubmit={handleAskQuestion} className="flex flex-col">
              <div className="form-group" style={{ marginBottom: '20px' }}>
                <label className="form-label">اكتب سؤالك بوضوح</label>
                <textarea
                  className="input-text"
                  style={{ height: '120px', paddingRight: '16px', resize: 'none' }}
                  placeholder="مثال: يرجى شرح القانون الأول للديناميكا الحرارية في الدرس الثاني..."
                  value={questionBody}
                  onChange={e => setQuestionBody(e.target.value)}
                  required
                />
              </div>
              <div className="flex gap-md">
                <button type="submit" className="btn btn-primary flex-1">إرسال السؤال</button>
                <button type="button" className="btn btn-secondary" onClick={() => setShowAskModal(false)}>إلغاء</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ── Question Details Modal ── */}
      {selectedQuestion && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ padding: '24px', maxWidth: '600px' }}>
            <div className="flex justify-between items-center" style={{ marginBottom: '20px', borderBottom: '1px solid rgb(var(--outline))', paddingBottom: '12px' }}>
              <h3 className="title-small">تفاصيل السؤال والردود</h3>
              <button
                className="btn btn-secondary"
                style={{ padding: '6px 12px', minWidth: 0 }}
                onClick={() => setSelectedQuestion(null)}
              >
                إغلاق
              </button>
            </div>
            
            <div style={{ marginBottom: '20px' }}>
              <div className="flex gap-sm items-center" style={{ marginBottom: '8px' }}>
                <span className="icon" style={{ color: 'rgb(var(--primary))' }}>help_outline</span>
                <span style={{ fontWeight: 'bold' }}>سؤالك:</span>
              </div>
              <p className="card-flat body-medium" style={{ backgroundColor: 'rgb(var(--surface-container-low))' }}>{selectedQuestion.question?.body}</p>
            </div>

            <div>
              <h4 style={{ fontSize: '13px', marginBottom: '12px', color: 'rgb(var(--on-surface-variant))' }}>ردود الأستاذ والمساعدين:</h4>
              {selectedQuestion.answers?.length === 0 ? (
                <p className="body-small" style={{ color: 'rgb(var(--on-surface-variant))', fontStyle: 'italic' }}>لا توجد ردود بعد. يرجى الانتظار حتى يقوم الأستاذ أو مساعدوه بالرد.</p>
              ) : (
                <div className="flex flex-col gap-sm">
                  {selectedQuestion.answers?.map((ans: any) => (
                    <div key={ans.id} className="card-flat" style={{ borderRight: '3px solid rgb(var(--primary))' }}>
                      <div className="flex justify-between items-center" style={{ marginBottom: '4px' }}>
                        <span style={{ fontWeight: 'bold', fontSize: '12px', color: 'rgb(var(--primary))' }}>{ans.author_name} (إدارة المنصة)</span>
                        <span style={{ fontSize: '10px' }}>{new Date(ans.created_at).toLocaleDateString('ar-EG')}</span>
                      </div>
                      <p className="body-medium">{ans.body}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ── Redeem Code Modal ── */}
      {showRedeemModal && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ padding: '24px' }}>
            <h3 className="title-small" style={{ marginBottom: '8px' }}>
              تفعيل مقرر جديد بكود
            </h3>
            <p className="body-small" style={{ marginBottom: '20px' }}>
              {selectedCourseForRedeem ? `أنت تقوم بتفعيل كورس: "${selectedCourseForRedeem.title}"` : 'يرجى إدخال الكود المكون من 12 رمزاً لتفعيل المقرر الدراسي بالكامل.'}
            </p>
            <form onSubmit={handleRedeemSubmit} className="flex flex-col">
              <div className="form-group" style={{ marginBottom: '24px' }}>
                <label className="form-label">كود التفعيل</label>
                <div className="input-container">
                  <input
                    type="text"
                    className="input-text"
                    placeholder="مثال: PHY-XXXX-XXXX"
                    value={redeemCode}
                    onChange={e => setRedeemCode(e.target.value)}
                    required
                  />
                  <span className="icon input-icon-right">vpn_key</span>
                </div>
              </div>
              <div className="flex gap-md">
                <button type="submit" className="btn btn-primary flex-1" disabled={redeeming}>
                  {redeeming ? 'جاري التحقق والتفعيل...' : 'تأكيد التفعيل'}
                </button>
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => {
                    setShowRedeemModal(false);
                    setRedeemCode('');
                    setSelectedCourseForRedeem(null);
                  }}
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* ── Notifications Modal ── */}
      {showNotificationsModal && (
        <div className="modal-overlay" style={{ direction: 'rtl' }}>
          <div className="modal-content" style={{ padding: '24px', maxWidth: '520px', width: '90%', maxHeight: '75vh', overflowY: 'auto', borderRadius: '16px' }}>
            <div className="flex justify-between items-center" style={{ borderBottom: '1px solid rgba(255, 255, 255, 0.08)', paddingBottom: '16px', marginBottom: '20px' }}>
              <div className="flex items-center gap-sm">
                <span className="material-symbols-outlined text-primary" style={{ fontSize: '24px' }}>notifications</span>
                <h3 className="title-small" style={{ margin: 0 }}>
                  مركز التنبيهات والإشعارات
                </h3>
              </div>
              <button 
                onClick={() => setShowNotificationsModal(false)}
                style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,0.4)', cursor: 'pointer' }}
                className="hover:text-white transition-colors"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <div className="flex flex-col gap-md">
              {notifications.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '40px 0' }}>
                  <span className="material-symbols-outlined text-secondary" style={{ fontSize: '48px', opacity: 0.3, marginBottom: '12px' }}>notifications_off</span>
                  <p className="body-medium" style={{ color: 'rgb(var(--on-surface-variant))' }}>لا توجد تنبيهات جديدة حالياً.</p>
                  <p className="body-small" style={{ opacity: 0.6 }}>ابقَ مستعداً لتلقي الإشعارات من مدرسك!</p>
                </div>
              ) : (
                <div className="flex flex-col gap-sm" style={{ maxHeight: '50vh', overflowY: 'auto', paddingRight: '4px' }}>
                  {notifications.map((n) => {
                    const isUnread = n.is_read === 0;
                    return (
                      <div
                        key={n.id}
                        onClick={() => isUnread && markNotificationAsRead(n.id)}
                        style={{
                          padding: '14px 16px',
                          borderRadius: '12px',
                          background: isUnread ? 'rgba(var(--primary), 0.06)' : 'rgba(255, 255, 255, 0.02)',
                          border: isUnread ? '1px solid rgba(var(--primary), 0.15)' : '1px solid rgba(255, 255, 255, 0.04)',
                          cursor: 'pointer',
                          transition: 'all 0.25s ease',
                          position: 'relative',
                        }}
                        className="hover:bg-surface-container-low"
                      >
                        <div className="flex justify-between items-start" style={{ marginBottom: '6px' }}>
                          <span style={{
                            fontSize: '10px',
                            fontWeight: 'bold',
                            color: 'rgb(var(--primary))',
                            background: 'rgba(var(--primary), 0.1)',
                            padding: '2px 8px',
                            borderRadius: '50px'
                          }}>
                            {n.type === 'announcement' ? 'تنويه عام' : n.type === 'new_lesson' ? 'درس جديد' : 'تنبيه نظام'}
                          </span>
                          <span style={{ fontSize: '10px', opacity: 0.5 }}>
                            {new Date(n.sent_at).toLocaleDateString('ar-EG', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <h4 style={{ fontSize: '13px', fontWeight: '800', color: '#fff', marginBottom: '4px' }}>
                          {n.title}
                        </h4>
                        <p style={{ fontSize: '11px', color: 'rgb(var(--on-surface-variant))', lineHeight: '1.5' }}>
                          {n.body}
                        </p>
                        {isUnread && (
                          <span style={{
                            position: 'absolute',
                            top: '14px',
                            right: '6px',
                            backgroundColor: 'rgb(var(--primary))',
                            borderRadius: '50%',
                            width: '6px',
                            height: '6px'
                          }} />
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
      {/* ── Standalone Exam Solver Modal ── */}
      {showExamModal && selectedExam && (
        <div className="modal-overlay" style={{ direction: 'rtl' }}>
          <div className="modal-content" style={{ padding: '24px', maxWidth: '700px', width: '90%', maxHeight: '85vh', overflowY: 'auto', borderRadius: '16px' }}>
            <div className="flex justify-between items-center" style={{ borderBottom: '1px solid rgba(255, 255, 255, 0.08)', paddingBottom: '16px', marginBottom: '20px' }}>
              <div>
                <h3 className="title-small" style={{ color: '#fff', fontWeight: '800' }}>{selectedExam.title}</h3>
                <p style={{ fontSize: '11px', color: 'rgb(var(--on-surface-variant))', marginTop: '4px' }}>
                  الدرجة الكلية: {selectedExam.max_score} درجة • عدد الأسئلة: {examQuestions.length}
                </p>
              </div>
              <div className="flex items-center gap-sm">
                {examTimeLeft !== null && (
                  <div style={{ backgroundColor: 'rgba(var(--primary), 0.15)', border: '1px solid rgba(var(--primary), 0.3)', padding: '6px 12px', borderRadius: '10px', color: 'rgb(var(--primary))', fontSize: '13px', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <span className="material-symbols-outlined" style={{ fontSize: '18px' }}>timer</span>
                    <span>{formatTimeLeft(examTimeLeft)}</span>
                  </div>
                )}
                <button
                  className="btn btn-secondary"
                  style={{ padding: '6px 12px', minWidth: 0, borderRadius: '8px' }}
                  onClick={() => {
                    setShowExamModal(false);
                    setSelectedExam(null);
                    setExamQuestions([]);
                    setExamAttempt(null);
                    setExamAnswers({});
                  }}
                >
                  إغلاق
                </button>
              </div>
            </div>

            {examAttempt ? (
              // View Graded Exam (Already Submitted)
              <div className="flex flex-col gap-lg">
                <div style={{ backgroundColor: 'rgba(16, 185, 129, 0.08)', border: '1px solid rgba(16, 185, 129, 0.2)', padding: '16px', borderRadius: '12px', textAlign: 'center', marginBottom: '10px' }}>
                  <p style={{ fontSize: '14px', color: '#10b981', fontWeight: 'bold' }}>لقد قمت بحل هذا الامتحان مسبقاً</p>
                  <p style={{ fontSize: '20px', fontWeight: '800', color: '#fff', marginTop: '6px' }}>
                    درجتك: {examAttempt.score} / {selectedExam.max_score}
                  </p>
                  <span style={{ fontSize: '11px', color: 'rgb(var(--on-surface-variant))', display: 'block', marginTop: '4px' }}>
                    تاريخ التسليم: {new Date(examAttempt.submitted_at).toLocaleString('ar-EG')}
                  </span>
                </div>

                <div className="flex flex-col gap-md">
                  {examQuestions.map((q, idx) => {
                    const studentChoice = examAttempt.answers?.[q.id] || '';
                    return (
                      <div key={q.id} style={{ padding: '16px', backgroundColor: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.04)', borderRadius: '12px' }}>
                        <p style={{ fontSize: '14px', fontWeight: 'bold', color: '#fff', marginBottom: '12px' }}>
                          {idx + 1}. {q.question_text}
                        </p>
                        {q.image_url && (
                          <img src={q.image_url} alt="سؤال" style={{ maxWidth: '100%', maxHeight: '200px', borderRadius: '8px', marginBottom: '12px', objectFit: 'contain' }} />
                        )}
                        <div className="grid-2 gap-sm">
                          {q.options?.map((opt: string) => {
                            const isSelected = studentChoice === opt;
                            return (
                              <div
                                key={opt}
                                style={{
                                  padding: '10px 14px',
                                  borderRadius: '8px',
                                  fontSize: '13px',
                                  backgroundColor: isSelected ? 'rgba(var(--primary), 0.12)' : 'rgba(255,255,255,0.01)',
                                  border: isSelected ? '1px solid rgba(var(--primary), 0.3)' : '1px solid rgba(255,255,255,0.04)',
                                  color: isSelected ? 'rgb(var(--primary))' : '#ccc',
                                  display: 'flex',
                                  alignItems: 'center',
                                  gap: '8px'
                                }}
                              >
                                <span className="icon" style={{ fontSize: '16px' }}>{isSelected ? 'radio_button_checked' : 'radio_button_unchecked'}</span>
                                {opt}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : (
              // Solve Exam Form
              <form onSubmit={handleSubmitExam} className="flex flex-col gap-lg">
                <div className="flex flex-col gap-md">
                  {examQuestions.map((q, idx) => (
                    <div key={q.id} style={{ padding: '20px', backgroundColor: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.04)', borderRadius: '12px' }}>
                      <p style={{ fontSize: '14px', fontWeight: 'bold', color: '#fff', marginBottom: '12px' }}>
                        {idx + 1}. {q.question_text}
                      </p>
                      {q.image_url && (
                        <img src={q.image_url} alt="سؤال" style={{ maxWidth: '100%', maxHeight: '200px', borderRadius: '8px', marginBottom: '12px', objectFit: 'contain' }} />
                      )}
                      <div className="grid-2 gap-sm">
                        {q.options?.map((opt: string) => {
                          const isSelected = examAnswers[q.id] === opt;
                          return (
                            <button
                              type="button"
                              key={opt}
                              onClick={() => setExamAnswers(prev => ({ ...prev, [q.id]: opt }))}
                              style={{
                                padding: '12px 16px',
                                borderRadius: '8px',
                                fontSize: '13px',
                                textAlign: 'right',
                                backgroundColor: isSelected ? 'rgba(var(--primary), 0.1)' : 'rgba(255,255,255,0.01)',
                                border: isSelected ? '1px solid rgb(var(--primary))' : '1px solid rgba(255,255,255,0.05)',
                                color: isSelected ? '#fff' : '#ccc',
                                cursor: 'pointer',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '8px',
                                transition: 'all 0.2s ease'
                              }}
                            >
                              <span className="icon" style={{ fontSize: '16px', color: isSelected ? 'rgb(var(--primary))' : '#666' }}>{isSelected ? 'radio_button_checked' : 'radio_button_unchecked'}</span>
                              {opt}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>

                <div style={{ borderTop: '1px solid rgba(255,255,255,0.08)', paddingTop: '20px', display: 'flex', gap: '12px' }}>
                  <button type="submit" className="btn btn-primary flex-1" disabled={submittingExam || examQuestions.length === 0} style={{ padding: '12px', borderRadius: '10px', fontWeight: 'bold' }}>
                    {submittingExam ? 'جاري تصحيح وتسليم الامتحان...' : 'تسليم الامتحان الآن'}
                  </button>
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={() => {
                      setShowExamModal(false);
                      setSelectedExam(null);
                      setExamQuestions([]);
                      setExamAttempt(null);
                      setExamAnswers({});
                    }}
                    style={{ borderRadius: '10px' }}
                  >
                    إلغاء
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* ── Mobile Bottom Navigation Bar ── */}
      <nav className="mobile-bottom-nav">
        <button
          onClick={() => handleTabClick('home')}
          className={`mobile-bottom-nav-item ${activeTab === 'home' ? 'active' : ''}`}
        >
          <span className="icon">home</span>
          <span>الرئيسية</span>
        </button>
        
        <button
          onClick={() => handleTabClick('explore')}
          className={`mobile-bottom-nav-item ${activeTab === 'explore' ? 'active' : ''}`}
        >
          <span className="icon">explore</span>
          <span>الدورات</span>
        </button>
        
        <button
          onClick={() => handleTabClick('my-courses')}
          className={`mobile-bottom-nav-item ${activeTab === 'my-courses' ? 'active' : ''}`}
        >
          <span className="icon">school</span>
          <span>مقرراتي</span>
        </button>

        <button
          onClick={() => handleTabClick('exams')}
          className={`mobile-bottom-nav-item ${activeTab === 'exams' ? 'active' : ''}`}
        >
          <span className="icon">assignment</span>
          <span>الامتحانات</span>
        </button>

        <button
          onClick={() => {
            window.dispatchEvent(new Event('toggle-explain-tasks'));
          }}
          className="mobile-bottom-nav-item"
        >
          <span className="icon">task_alt</span>
          <span>مهام الشرح</span>
        </button>
        
        <button
          onClick={() => handleTabClick('qa')}
          className={`mobile-bottom-nav-item ${activeTab === 'qa' ? 'active' : ''}`}
        >
          <span className="icon">question_answer</span>
          <span>الاستفسارات</span>
        </button>
        
        <button
          onClick={() => handleTabClick('profile')}
          className={`mobile-bottom-nav-item ${activeTab === 'profile' ? 'active' : ''}`}
        >
          <span className="icon">person</span>
          <span>ملفي</span>
        </button>
      </nav>
    </div>
  );
};

export default Home;

