import React, { useState, useEffect } from 'react';

export const ExplainTasks: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'student' | 'teacher'>('student');
  
  const [studentTasks, setStudentTasks] = useState([
    { id: 's1', text: 'تسجيل الدخول وتصفح الكورسات المتاحة', checked: false },
    { id: 's2', text: 'تفعيل الكورس باستخدام رمز تفعيل الطالب', checked: false },
    { id: 's3', text: 'تشغيل المحاضرات وتجربة تغيير الجودة والسرعة', checked: false },
    { id: 's4', text: 'التبديل إلى الوضع السينمائي (Theater Mode)', checked: false },
    { id: 's5', text: 'عرض المرفقات والكتب بصيغة PDF مع العلامة المائية', checked: false },
    { id: 's6', text: 'حل الاختبارات التفاعلية وعرض نموذج الإجابة الفوري', checked: false },
    { id: 's7', text: 'طرح سؤال في لوحة الاستفسارات وتصويت الطلاب', checked: false },
  ]);

  const [teacherTasks, setTeacherTasks] = useState([
    { id: 't1', text: 'تسجيل الدخول للوحة التحكم وقراءة الإحصائيات', checked: false },
    { id: 't2', text: 'إدارة وتفعيل طلبات فك أجهزة الطلاب المعلقة', checked: false },
    { id: 't3', text: 'بث تنبيه وإشعار فوري لجميع هواتف الطلاب', checked: false },
    { id: 't4', text: 'رفع كورس ومحاضرة جديدة وملفات الـ PDF الملحقة', checked: false },
    { id: 't5', text: 'بناء اختبار تفاعلي جديد وتحديد أسئلته ودرجاته', checked: false },
    { id: 't6', text: 'توليد دفعات الأكواد للطباعة عبر معالج الخطوات', checked: false },
  ]);

  // Load from localStorage
  useEffect(() => {
    const savedStudent = localStorage.getItem('explain_student_tasks');
    const savedTeacher = localStorage.getItem('explain_teacher_tasks');
    const savedOpen = localStorage.getItem('explain_widget_open');
    
    if (savedStudent) {
      try {
        const parsed = JSON.parse(savedStudent);
        setStudentTasks(prev => prev.map(t => ({ ...t, checked: !!parsed[t.id] })));
      } catch {}
    }
    if (savedTeacher) {
      try {
        const parsed = JSON.parse(savedTeacher);
        setTeacherTasks(prev => prev.map(t => ({ ...t, checked: !!parsed[t.id] })));
      } catch {}
    }
    if (savedOpen) {
      setIsOpen(savedOpen === 'true');
    }
  }, []);

  const saveTasks = (type: 'student' | 'teacher', updatedList: any[]) => {
    const map: Record<string, boolean> = {};
    updatedList.forEach(t => {
      map[t.id] = t.checked;
    });
    localStorage.setItem(`explain_${type}_tasks`, JSON.stringify(map));
  };

  const toggleStudentTask = (id: string) => {
    const updated = studentTasks.map(t => t.id === id ? { ...t, checked: !t.checked } : t);
    setStudentTasks(updated);
    saveTasks('student', updated);
  };

  const toggleTeacherTask = (id: string) => {
    const updated = teacherTasks.map(t => t.id === id ? { ...t, checked: !t.checked } : t);
    setTeacherTasks(updated);
    saveTasks('teacher', updated);
  };

  const handleToggleOpen = () => {
    const nextState = !isOpen;
    setIsOpen(nextState);
    localStorage.setItem('explain_widget_open', String(nextState));
  };

  const completedStudentCount = studentTasks.filter(t => t.checked).length;
  const completedTeacherCount = teacherTasks.filter(t => t.checked).length;
  const totalCompleted = completedStudentCount + completedTeacherCount;
  const totalTasks = studentTasks.length + teacherTasks.length;

  // Add event listener for custom toggling (e.g. from mobile bottom nav)
  useEffect(() => {
    const handleToggle = () => {
      setIsOpen(prev => !prev);
    };
    window.addEventListener('toggle-explain-tasks', handleToggle);
    return () => {
      window.removeEventListener('toggle-explain-tasks', handleToggle);
    };
  }, []);

  return (
    <div className="explain-widget-container select-none">
      {isOpen ? (
        <div 
          style={{
            width: '320px',
            background: 'rgba(30, 30, 35, 0.85)',
            backdropFilter: 'blur(12px)',
            border: '1px solid rgba(255, 255, 255, 0.1)',
            borderRadius: '16px',
            boxShadow: '0 8px 32px rgba(0, 0, 0, 0.5)',
            color: '#fff',
            overflow: 'hidden',
            transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
          }}
        >
          {/* Header */}
          <div 
            style={{
              padding: '12px 16px',
              background: 'rgba(255, 255, 255, 0.03)',
              borderBottom: '1px solid rgba(255, 255, 255, 0.08)',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span className="material-symbols-outlined" style={{ color: 'rgb(var(--primary))', fontSize: '18px' }}>fact_check</span>
              <span style={{ fontSize: '12px', fontWeight: 'bold' }}>مهام شرح المنصة ({totalCompleted}/{totalTasks})</span>
            </div>
            <button 
              onClick={handleToggleOpen}
              style={{
                background: 'none',
                border: 'none',
                color: '#aaa',
                cursor: 'pointer',
                padding: '2px',
                display: 'flex',
                alignItems: 'center',
              }}
              title="تصغير"
            >
              <span className="material-symbols-outlined" style={{ fontSize: '18px' }}>close_fullscreen</span>
            </button>
          </div>

          {/* Tabs */}
          <div 
            style={{
              display: 'flex',
              borderBottom: '1px solid rgba(255, 255, 255, 0.08)',
              fontSize: '11px',
            }}
          >
            <button
              onClick={() => setActiveTab('student')}
              style={{
                flex: 1,
                padding: '10px 0',
                background: activeTab === 'student' ? 'rgba(255, 255, 255, 0.05)' : 'none',
                border: 'none',
                color: activeTab === 'student' ? '#fff' : '#aaa',
                fontWeight: activeTab === 'student' ? 'bold' : 'normal',
                borderBottom: activeTab === 'student' ? '2px solid rgb(var(--primary))' : 'none',
                cursor: 'pointer',
              }}
            >
              شرح الطالب ({completedStudentCount}/{studentTasks.length})
            </button>
            <button
              onClick={() => setActiveTab('teacher')}
              style={{
                flex: 1,
                padding: '10px 0',
                background: activeTab === 'teacher' ? 'rgba(255, 255, 255, 0.05)' : 'none',
                border: 'none',
                color: activeTab === 'teacher' ? '#fff' : '#aaa',
                fontWeight: activeTab === 'teacher' ? 'bold' : 'normal',
                borderBottom: activeTab === 'teacher' ? '2px solid rgb(var(--primary))' : 'none',
                cursor: 'pointer',
              }}
            >
              شرح المدرس ({completedTeacherCount}/{teacherTasks.length})
            </button>
          </div>

          {/* List Area */}
          <div 
            style={{
              maxHeight: '260px',
              overflowY: 'auto',
              padding: '12px',
            }}
          >
            {activeTab === 'student' ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {studentTasks.map(t => (
                  <label 
                    key={t.id}
                    style={{
                      display: 'flex',
                      alignItems: 'flex-start',
                      gap: '8px',
                      fontSize: '11px',
                      cursor: 'pointer',
                      opacity: t.checked ? 0.5 : 1,
                      textDecoration: t.checked ? 'line-through' : 'none',
                      transition: 'opacity 0.2s',
                    }}
                  >
                    <input 
                      type="checkbox"
                      checked={t.checked}
                      onChange={() => toggleStudentTask(t.id)}
                      style={{ marginTop: '2px', cursor: 'pointer' }}
                    />
                    <span>{t.text}</span>
                  </label>
                ))}
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {teacherTasks.map(t => (
                  <label 
                    key={t.id}
                    style={{
                      display: 'flex',
                      alignItems: 'flex-start',
                      gap: '8px',
                      fontSize: '11px',
                      cursor: 'pointer',
                      opacity: t.checked ? 0.5 : 1,
                      textDecoration: t.checked ? 'line-through' : 'none',
                      transition: 'opacity 0.2s',
                    }}
                  >
                    <input 
                      type="checkbox"
                      checked={t.checked}
                      onChange={() => toggleTeacherTask(t.id)}
                      style={{ marginTop: '2px', cursor: 'pointer' }}
                    />
                    <span>{t.text}</span>
                  </label>
                ))}
              </div>
            )}
          </div>
          
          {/* Progress bar */}
          <div style={{ padding: '8px 12px', background: 'rgba(0,0,0,0.2)' }}>
            <div style={{ height: '4px', background: 'rgba(255,255,255,0.1)', borderRadius: '2px', overflow: 'hidden' }}>
              <div 
                style={{ 
                  height: '100%', 
                  width: `${(totalCompleted / totalTasks) * 100}%`, 
                  background: 'linear-gradient(90deg, rgb(var(--primary)), rgb(52, 211, 153))',
                  transition: 'width 0.4s ease',
                }}
              />
            </div>
          </div>
        </div>
      ) : (
        <button
          onClick={handleToggleOpen}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            padding: '10px 16px',
            background: 'rgba(30, 30, 35, 0.85)',
            backdropFilter: 'blur(12px)',
            border: '1px solid rgba(255, 255, 255, 0.15)',
            borderRadius: '50px',
            boxShadow: '0 4px 20px rgba(0, 0, 0, 0.3)',
            color: '#fff',
            cursor: 'pointer',
            fontSize: '12px',
            fontWeight: 'bold',
            transition: 'all 0.2s',
          }}
          className="explain-widget-trigger hover:scale-105 active:scale-95"
        >
          <span className="material-symbols-outlined" style={{ color: 'rgb(var(--primary))', fontSize: '18px' }}>task_alt</span>
          <span>مهام الشرح ({totalCompleted}/{totalTasks})</span>
        </button>
      )}
    </div>
  );
};

