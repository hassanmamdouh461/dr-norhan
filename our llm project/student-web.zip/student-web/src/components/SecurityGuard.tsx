import React, { useEffect, useState } from 'react';

interface SecurityGuardProps {
  children: React.ReactNode;
  enabled?: boolean;
  onFocusLost?: (blurred: boolean) => void;
}

export const SecurityGuard: React.FC<SecurityGuardProps> = ({
  children,
  enabled = true,
  onFocusLost,
}) => {
  const [isBlurred, setIsBlurred] = useState(false);
  const [devToolsOpen, setDevToolsOpen] = useState(false);

  useEffect(() => {
    if (!enabled) return;

    // ── Prevent Right-Click ──
    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
    };

    // ── Prevent Shortcuts for Inspect Element ──
    const handleKeyDown = (e: KeyboardEvent) => {
      // F12
      if (e.key === 'F12') {
        e.preventDefault();
        return;
      }
      // Ctrl+Shift+I / Cmd+Alt+I (Inspect)
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'I') {
        e.preventDefault();
        return;
      }
      // Ctrl+Shift+J / Cmd+Alt+J (Console)
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'J') {
        e.preventDefault();
        return;
      }
      // Ctrl+Shift+C / Cmd+Alt+C (Inspect elements selector)
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'C') {
        e.preventDefault();
        return;
      }
      // Ctrl+U (Source code viewer)
      if ((e.ctrlKey || e.metaKey) && e.key === 'u') {
        e.preventDefault();
        return;
      }
    };

    // ── Blur Content on Lost Focus ──
    const handleBlur = () => {
      setIsBlurred(true);
      if (onFocusLost) onFocusLost(true);
    };

    const handleFocus = () => {
      setIsBlurred(false);
      if (onFocusLost) onFocusLost(false);
    };

    const handleVisibilityChange = () => {
      if (document.hidden) {
        setIsBlurred(true);
        if (onFocusLost) onFocusLost(true);
      } else {
        setIsBlurred(false);
        if (onFocusLost) onFocusLost(false);
      }
    };

    // ── DevTools Detection ──
    // Checks if the window bounds differ significantly (docked DevTools check)
    const checkDevTools = () => {
      const threshold = 160;
      const widthDiff = window.outerWidth - window.innerWidth > threshold;
      const heightDiff = window.outerHeight - window.innerHeight > threshold;
      
      // Simple devtools console opening detector
      // by stringifying an object with a getter
      let element = new Image();
      Object.defineProperty(element, 'id', {
        get: () => {
          setDevToolsOpen(true);
        }
      });
      console.log('%c', element);

      if (widthDiff || heightDiff) {
        setDevToolsOpen(true);
      } else {
        setDevToolsOpen(false);
      }
    };

    window.addEventListener('contextmenu', handleContextMenu);
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('blur', handleBlur);
    window.addEventListener('focus', handleFocus);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    const devtoolsInterval = setInterval(checkDevTools, 2000);

    return () => {
      window.removeEventListener('contextmenu', handleContextMenu);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('blur', handleBlur);
      window.removeEventListener('focus', handleFocus);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      clearInterval(devtoolsInterval);
    };
  }, [enabled, onFocusLost]);

  if (!enabled) return <>{children}</>;

  return (
    <div style={{ position: 'relative', width: '100%', height: '100%' }}>
      {/* Blurred overlay if focus lost */}
      {isBlurred && (
        <div
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(15, 17, 26, 0.95)',
            zIndex: 9999,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#fff',
            fontFamily: 'Cairo, sans-serif',
            textAlign: 'center',
            padding: '20px',
          }}
        >
          <span className="icon" style={{ fontSize: '48px', color: '#f87171', marginBottom: '16px' }}>lock</span>
          <h3 style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '8px' }}>تم إيقاف العرض مؤقتاً</h3>
          <p style={{ fontSize: '13px', color: '#9ca3af' }}>يرجى البقاء في نافذة المحاضرة وعدم الانتقال لنافذة أخرى لحماية محتوى الفيديو.</p>
        </div>
      )}

      {/* Warning overlay if DevTools open */}
      {devToolsOpen && (
        <div
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(15, 17, 26, 0.98)',
            zIndex: 10000,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#fff',
            fontFamily: 'Cairo, sans-serif',
            textAlign: 'center',
            padding: '20px',
          }}
        >
          <span className="icon" style={{ fontSize: '48px', color: '#ef4444', marginBottom: '16px' }}>security</span>
          <h3 style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '8px', color: '#ef4444' }}>تم اكتشاف محاولة تصوير أو فحص!</h3>
          <p style={{ fontSize: '13px', color: '#fca5a5', maxWidth: '400px', lineHeight: '1.6' }}>
            لقد تم كشف تشغيل أدوات فحص العناصر أو فك تشفير الصفحة. تم حجب المحتوى تلقائياً وسيتم إرسال بلاغ للأمن المالي لحظر حسابك تماماً ومطالبتك قانونياً.
          </p>
        </div>
      )}

      <div
        style={{
          filter: isBlurred || devToolsOpen ? 'blur(15px)' : 'none',
          pointerEvents: isBlurred || devToolsOpen ? 'none' : 'auto',
          width: '100%',
          height: '100%',
          transition: 'filter 0.2s ease',
        }}
      >
        {children}
      </div>
    </div>
  );
};

export default SecurityGuard;
