import React, { createContext, useContext, useEffect, useState } from 'react';
import type { User } from '@supabase/supabase-js';
import supabase from '../services/supabase';
import { ApiService, getDeviceId } from '../services/api';

interface AuthContextType {
  user: User | null;
  profile: any | null;
  loading: boolean;
  needsProfileSetup: boolean;
  login: (phoneOrEmail: string, password: string) => Promise<void>;
  register: (data: {
    phone: string;
    fullName: string;
    parentPhone: string;
    grade: string;
    governorate: string;
    password: string;
  }) => Promise<void>;
  completeProfileSetup: (data: {
    fullName: string;
    phone: string;
    parentPhone: string;
    grade: string;
    governorate: string;
  }) => Promise<void>;
  logout: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  clearError: () => void;
  error: string | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [needsProfileSetup, setNeedsProfileSetup] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Clear error
  const clearError = () => setError(null);

  // Fetch student profile from Worker backend
  const fetchProfileAndRegisterDevice = async (_currentUser: User) => {
    try {
      // 1. Get profile from D1 backend
      const profileData = await ApiService.getProfile();
      setProfile(profileData);
      setNeedsProfileSetup(false);

      // 2. Register current browser as a device
      try {
        await ApiService.registerDevice({
          device_id: getDeviceId(),
          platform: 'web',
          model: navigator.userAgent.substring(0, 50),
        });
      } catch (deviceErr: any) {
        console.error('Failed to register device:', deviceErr);
        // If device registration fails due to limit, throw it to notify the user
        if (deviceErr.code === 'DEVICE_LIMIT_EXCEEDED' || (deviceErr.message && deviceErr.message.includes('الأجهزة'))) {
          throw deviceErr;
        }
      }
    } catch (err: any) {
      console.error('Failed to fetch profile:', err);
      if (err.status === 404 || err.code === 'NOT_FOUND') {
        // User authenticated in Supabase but doesn't exist in Worker D1
        setNeedsProfileSetup(true);
      } else {
        setError(err.message || 'فشل مزامنة الملف الشخصي مع الخادم الرئيسي');
      }
    }
  };

  useEffect(() => {
    // Check active session on mount
    const initAuth = async () => {
      setLoading(true);
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        setUser(session.user);
        await fetchProfileAndRegisterDevice(session.user);
      }
      setLoading(false);
    };

    initAuth();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
      setLoading(true);
      if (session?.user) {
        setUser(session.user);
        await fetchProfileAndRegisterDevice(session.user);
      } else {
        setUser(null);
        setProfile(null);
        setNeedsProfileSetup(false);
      }
      setLoading(false);
    });

    // Custom listener for api-driven signout events
    const handleAuthStatusChange = () => {
      setUser(null);
      setProfile(null);
      setNeedsProfileSetup(false);
    };
    window.addEventListener('auth-status-change', handleAuthStatusChange);

    return () => {
      subscription.unsubscribe();
      window.removeEventListener('auth-status-change', handleAuthStatusChange);
    };
  }, []);

  const login = async (phoneOrEmail: string, password: string) => {
    setLoading(true);
    setError(null);
    try {
      // Map numeric input (phone number) to email format
      const isPhone = /^[0-9]+$/.test(phoneOrEmail.trim());
      const email = isPhone ? `${phoneOrEmail.trim()}@alhadaba-chemistry.com` : phoneOrEmail.trim();

      const { data, error: authErr } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (authErr) throw authErr;
      if (data.user) {
        setUser(data.user);
        await fetchProfileAndRegisterDevice(data.user);
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'فشل تسجيل الدخول. يرجى التحقق من البيانات.');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const register = async (data: {
    phone: string;
    fullName: string;
    parentPhone: string;
    grade: string;
    governorate: string;
    password: string;
  }) => {
    setLoading(true);
    setError(null);
    try {
      const email = `${data.phone.trim()}@alhadaba-chemistry.com`;
      
      // 1. Sign up user in Supabase
      const { data: authData, error: authErr } = await supabase.auth.signUp({
        email,
        password: data.password,
      });

      if (authErr) throw authErr;
      if (!authData.user) throw new Error('فشلت عملية إنشاء الحساب');

      setUser(authData.user);

      // 2. Sync profile details with Worker D1 immediately using sync-first endpoint
      const syncResult = await ApiService.syncProfile({
        full_name: data.fullName,
        phone: data.phone,
        parent_phone: data.parentPhone,
        grade: data.grade,
        governorate: data.governorate,
      });

      if (syncResult.profile) {
        setProfile(syncResult.profile);
        setNeedsProfileSetup(false);

        // 3. Register device
        await ApiService.registerDevice({
          device_id: getDeviceId(),
          platform: 'web',
          model: navigator.userAgent.substring(0, 50),
        });
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'فشل إنشاء الحساب. يرجى المحاولة مرة أخرى.');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const completeProfileSetup = async (data: {
    fullName: string;
    phone: string;
    parentPhone: string;
    grade: string;
    governorate: string;
  }) => {
    setLoading(true);
    setError(null);
    try {
      const syncResult = await ApiService.syncProfile({
        full_name: data.fullName,
        phone: data.phone,
        parent_phone: data.parentPhone,
        grade: data.grade,
        governorate: data.governorate,
      });

      if (syncResult.profile) {
        setProfile(syncResult.profile);
        setNeedsProfileSetup(false);

        // Register device
        await ApiService.registerDevice({
          device_id: getDeviceId(),
          platform: 'web',
          model: navigator.userAgent.substring(0, 50),
        });
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'فشل إكمال إعداد الحساب.');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    setLoading(true);
    try {
      await supabase.auth.signOut();
      setUser(null);
      setProfile(null);
      setNeedsProfileSetup(false);
      localStorage.removeItem('student_profile');
    } catch (err: any) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const refreshProfile = async () => {
    if (user) {
      await fetchProfileAndRegisterDevice(user);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        loading,
        needsProfileSetup,
        login,
        register,
        completeProfileSetup,
        logout,
        refreshProfile,
        clearError,
        error,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
